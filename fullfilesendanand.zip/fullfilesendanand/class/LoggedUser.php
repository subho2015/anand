<?php

class LoggedUser {
    /**
     * @return mixed
     */
    public function getStaffId() {
        return $this->getParleG("staffId");
    }

    /**

     * @param mixed $staffId

     */

    public function setStaffId($staffId): void {
        $this->setParleG("staffId",$staffId);
        $_SESSION["staffId"] = $staffId;
    }
    /**

     * @return mixed

     */

    public function getName() {
        return $this->getParleG("name");

    }

    /**
     * @param mixed $name
     */

    public function setName($name): void {
        $this->setParleG("name",$name);
    }
    /**
     * @return mixed
     */

    public function getEmail() {
        return $this->getParleG("email");
    }
    /**
     * @param mixed $email
     */

    public function setEmail($email): void {
        $this->setParleG("email",$email);
    }
    /**
     * @return mixed
     */

    public function getRole() {
        return $this->getParleG("role");
    }
    /**
     * @param mixed $role
     */

    public function setRole($role): void {
        $this->setParleG("role",$role);
    }
    /**
     * @return mixed
     */

    public function getTypeUser() {
        return $this->getParleG("type_user");
    }
    /**
     * @param mixed $type_user
     */

    public function setTypeUser($type_user): void {
        $this->setParleG("type_user",$type_user);
    }

    /*public function setUser(array $result): void {
        $this->setStaffId($result['staffId']);
        $this->setName($result['name']);
        $this->setEmail($result['email']);
        $this->setRole($result['role']);
        $this->setTypeUser($result['type_user']);
    }*/
	public function setUser(array $result): void {
    $this->setStaffId(isset($result['staffId']) ? $result['staffId'] : null);
    $this->setName(isset($result['name']) ? $result['name'] : null);
    $this->setEmail(isset($result['email']) ? $result['email'] : null);
    $this->setRole(isset($result['role']) ? $result['role'] : null);
    $this->setTypeUser(isset($result['type_user']) ? $result['type_user'] : null);
}
    protected function setParleG($cookie_name, $cookie_value){
        setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day
    }
    protected function getParleG($cookie_name){
        return $_COOKIE[$cookie_name];
    }

    public function logoutUser(){
        $result = ["staffId"=>null, "name"=>null, "email"=>null, "role"=>null, "type_user"=>null];
        $_SESSION["staffId"] = null;
        $this->setUser($result);
    }
}