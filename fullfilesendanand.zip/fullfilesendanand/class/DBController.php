<?php

$b = "../";

if (!empty($base) && $base === "./") $b = ""; else $b = $base;



include($b . 'datatableUtils/config.php');



class DBController {



    private $host = HOST;

    private $user = USERNAME;

    private $password = PASSWORD;

    private $database = DB;

    private $conn;



    function __construct() {

        $this->conn = $this->connectDB();

    }



    private function connectDB() {

        $conn = mysqli_connect($this->host, $this->user, $this->password, $this->database);

        return $conn;

    }



    function getCount($query) {

        $result = $this->conn->query($query);

        return $result[0];

    }



    /*function runQuery($query, $param_type, $param_value_array) {

        $stmt = $this->conn->prepare($query);

        $this->bindQueryParams($stmt, $param_type, $param_value_array);

        $stmt->execute();



        if ($stmt) {



            if ($stmt->affected_rows > 0) {

                return true;

            }



            if ($stmt->affected_rows === 0) {

                return false;

            }



            $result = $stmt->get_result();



            if ($result->num_rows > 0) {

                while ($row = $result->fetch_assoc()) {

                    $resultset[] = $row;

                }

            } else {



                error_log("SQL Result : " . json_encode($stmt->get_result()));

                error_log("SQL Result : " . json_encode($stmt->error));

            }



            if (!empty($resultset)) {

                return $resultset;

            }

        } else {

            error_log("SQL Error : " . $stmt->error);

        }

        return $stmt->error;

    }*/
	
	public function runQuery($query, $param_type, $param_value_array) {
    // Prepare the statement
    $stmt = $this->conn->prepare($query);
    if ($stmt === false) {
        error_log("SQL Prepare Failed: " . $this->conn->error);
        return false;
    }

    // Bind parameters if any
    if (!empty($param_type) && !empty($param_value_array)) {
        $bind = $this->bindQueryParams($stmt, $param_type, $param_value_array);
        if ($bind === false) {
            error_log("Parameter Binding Failed: " . $stmt->error);
            $stmt->close();
            return false;
        }
    }

    // Execute the statement
    if (!$stmt->execute()) {
        error_log("SQL Execute Failed: " . $stmt->error);
        $stmt->close();
        return false;
    }

    // Determine the type of query (SELECT or Non-SELECT)
    $queryType = strtoupper(substr(trim($query), 0, 6));

    if ($queryType === 'SELECT') {
        $result = $stmt->get_result();
        if ($result === false) {
            error_log("get_result() Failed: " . $stmt->error);
            $stmt->close();
            return false;
        }

        $resultset = [];
        while ($row = $result->fetch_assoc()) {
            $resultset[] = $row;
        }

        $stmt->close();
        return $resultset;
    } else {
        // For INSERT, UPDATE, DELETE queries
        $affected_rows = $stmt->affected_rows;
        $stmt->close();
        return $affected_rows;
    }
}




    private function bindQueryParams($stmt, $param_type, $param_value_array) {

        $param_value_reference[] = &$param_type;



        foreach ($param_value_array as $i => $_) {

            $param_value_reference[] = &$param_value_array[$i];

        }

        call_user_func_array([

            $stmt,

            'bind_param'

        ], $param_value_reference);

    }



    function insert($query, $param_type, $param_value_array) {

        $stmt = $this->conn->prepare($query);

        if ($stmt) {

            $this->bindQueryParams($stmt, $param_type, $param_value_array);

            $stmt->execute();



            $insertId = $stmt->insert_id;

        }

        error_log($stmt->error);

        $stmt->close();

        return $insertId;

    }



    function update($query, $param_type, $param_value_array) {

        $stmt = $this->conn->prepare($query);

        $this->bindQueryParams($stmt, $param_type, $param_value_array);

        $stmt->execute();

        error_log("STMT Error = Base Update = ".$stmt->error);



        return $stmt->affected_rows;

    }



    function baseUpdate($table, array $updatingValues, array $wheresArray) {

        $setStatementColumns = [];

        $paramValues = [];

        $paramType = "";

        $whereAllColumns = [];



        foreach ($updatingValues as $updatingColumns => $updateToValue) {

            $setStatementColumns[] = "`$updatingColumns` = ?";

            $paramType .= gettype($updateToValue)[0];

            $paramValues[] = $updateToValue;

        }



        foreach ($wheresArray as $whereColumns => $whereValue) {

            $whereAllColumns[] = "`$whereColumns` = ?";

            $paramType .= gettype($whereValue)[0];

            $paramValues[] = htmlspecialchars($whereValue);

        }



        $where = implode(",", $whereAllColumns);

        $setStatement = implode(",", $setStatementColumns);



        $query = "UPDATE {$table} SET {$setStatement} WHERE {$where}";



        error_log(" Query = [".$query."]");

        error_log(" Param Type = ".$paramType);

        error_log(" Param Value = ".json_encode($paramValues));



        return $this->update($query, $paramType, $paramValues);

    }



    function runBaseQuery($query) {

        $result = $this->conn->query($query);



        if ($result) {

            error_log(json_encode($result));



            error_log(__LINE__." | Result is true | " . $this->conn->error);



            if ($result->num_rows > 0) {

                while ($row = $result->fetch_assoc()) {

                    $resultset[] = $row;

                }

                return $resultset;

            }

        } else {

            error_log(__LINE__." | Result is null | " . $this->conn->error);

        }



        return $result;

    }



    function runBulkUpload($query) {

        $anyThing = $this->conn->query($query);

        error_log("[ERROR]  runBulkUpload | DBController.php | ".__LINE__." | ".json_encode($this->conn->error));

        error_log("[INFO]   runBulkUpload | DBController.php | ".__LINE__." | ".json_encode($this->conn->affected_rows));

        error_log("[INFO]   runBulkUpload | DBController.php | ".__LINE__." | ".json_encode($anyThing));

        return ($this->conn);

    }



    public function baseInsert(string $query) {

        $this->conn->query($query);

        return $this->conn->affected_rows;

    }

}

