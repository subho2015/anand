<?php

$base = '../';

$uploadInPage = true;

$formInPage = true;



$title = 'New | Orders' ?>
<?php include '../header.php'?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 

  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <ol class="breadcrumb p-0">
          <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
          <li class="breadcrumb-item active"><a href="#">Orders</a></li>
        </ol>
        
        <!-- END BREADCRUMB -->
        
        <h3 class="page-title text-primary"><i data-feather="box"></i>New Orders</h3>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container-fluid"> 
      
      <!-- START card -->
      
      <div class="card card-default p-t-20">
        <table class="table table-hover nowrap" id="newOrdersTable" cellspacing="0" width="100%">
          <thead class="card-body">
            <tr>
              <th></th>
              <th class="text-dark" style="letter-spacing: 0">Order Date</th>
              <th class="text-dark" style="letter-spacing: 0">Business</th>
              <th class="text-dark" style="letter-spacing: 0">Contact Person</th>
              <th class="text-dark" style="letter-spacing: 0">Billing Address</th>
              <th class="text-dark" style="letter-spacing: 0">Shipping Address</th>
              <th class="text-dark" style="letter-spacing: 0">Net Amount</th>
              <th class="text-dark" style="letter-spacing: 0">Request /Remark</th>
            </tr>
          </thead>
        </table>
      </div>
      
      <!-- END card --> 
      
    </div>
    
    <!-- END CONTAINER FLUID -->
    
    <div class="modal fade slide-right" id="orderDetails" tabindex="-1" role="dialog" aria-labelledby="orderDetails" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i></button>
            <div class="modal-body v-align-top">
              <div id="orderItemsList"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-right" id="additionCustomerInfoModel" tabindex="-1" role="dialog" aria-labelledby="additionCustomerInfo"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="additionCustomer"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-up" id="uploadCSVModal" tabindex="-1" role="dialog" aria-labelledby="uploadCSV"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="uploadCSVForm"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
  </div>
  
  <!-- END PAGE CONTENT --> 
  
</div>

<!-- END PAGE CONTENT WRAPPER -->

<?php include '../footer.php' ?>
<script src="js/orders.js" type="text/javascript"></script> 
<script>



    //todo Need auth.

    $(document).ready(function() {

        $('#newOrdersTable').DataTable( {

            processing: true,

            serverSide: true,

            deferRender: true,

            scrollX: true,

            ajax: {

                url :"./datatable/newOrders.php",

                type :"POST"

            },

            columns: [

                {

                    "orderable": false,

                    "data": "actions",

                    "defaultContent": ""

                },

                { "data": "created_at"},

                { "data": "business"},

                { "data": "customer"},

                { "data": "bill_to"},

                { "data": "ship_to"},

                { "data": "net_amt"},

                { "data": "cust_comment"}



            ]

        });

        $.fn.dataTable.ext.errMode = 'throw';





    });

</script> 
