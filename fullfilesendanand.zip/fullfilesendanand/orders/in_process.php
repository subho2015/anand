<?php $base = '../'; $title = 'In-Process | Orders' ?>
<?php include '../header.php' ?>

<!-- START PAGE CONTENT WRAPPER -->


<div class="page-content-wrapper"> 
  <?php
$success = $_GET['success'];
$message = $_GET['message'];
if (isset($_GET['orderUpdates']['message'])) {
	//echo "Test";
    $orderMessage = $_GET['orderUpdates']['message'];
    $orderMessage = str_replace('+', ' ', $orderMessage); // Replace '+' with space
    echo $orderMessage; // Outputs: Order Packed
} else {
    echo "Order message not found.";
}
if($success == 1 )
{
	//$ordermessage;
   //   $order2 = str_replace(['(', ')'], '', $order1);
?>
  
  <!-- START PAGE CONTENT -->
  <div class="pgn-wrapper" data-position="top" style="top: 59px; margin:0 0 20px 0;"><div class="pgn push-on-sidebar-open pgn-bar"><div class="alert alert-success"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button><?php echo $orderMessage;?>&nbsp;Successfully</div></div></div>
    <?php
    }
   ?>
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <ol class="breadcrumb p-0">
          <li class="breadcrumb-item"><a href="#">Hawk</a></li>
          <li class="breadcrumb-item active"><a href="#">Orders</a></li>
        </ol>
        
        <!-- END BREADCRUMB -->
        
        <h3 class="page-title text-primary"><i data-feather="box"></i>Processing</h3>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container-fluid"> 
      
      <!-- START card -->
      
      <div class="card card-default">
        <table class="table table-hover nowrap" id="processingOrdersTable" cellspacing="0" width="100%">
          <thead class="card-body">
            <tr>
              <th></th>
              <th class="text-dark" style="letter-spacing: 0">Order Date</th>
              <th class="text-dark" style="letter-spacing: 0">Business</th>
              <th class="text-dark" style="letter-spacing: 0">Contact Person</th>
              <th class="text-dark" style="letter-spacing: 0">Net Amount</th>
              <th class="text-dark" style="letter-spacing: 0">Billing Address</th>
              <th class="text-dark" style="letter-spacing: 0">Shipping Address</th>
              <th class="text-dark" style="letter-spacing: 0">Request /Remark</th>
            </tr>
          </thead>
        </table>
      </div>
      
      <!-- END card --> 
      
    </div>
    
    <!-- END CONTAINER FLUID -->
    
    <div class="modal fade slide-right" id="orderDetails" tabindex="-1" role="dialog" aria-labelledby="orderDetails" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="pg-close fs-14"></i></button>
            <div class="modal-body v-align-top">
              <div id="orderItemsList"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-right" id="additionCustomerInfoModel" tabindex="-1" role="dialog" aria-labelledby="additionCustomerInfo"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="additionCustomer"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-up" id="uploadCSVModal" tabindex="-1" role="dialog" aria-labelledby="uploadCSV"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="uploadCSVForm"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
  </div>
  
  <!-- END PAGE CONTENT --> 
  
</div>

<!-- END PAGE CONTENT WRAPPER -->

<?php include '../footer.php' ?>
<script src="js/orders.js" type="text/javascript"></script> 
<script>



    //todo Need auth.

    $(document).ready(function() {



        $('#processingOrdersTable').DataTable( {

            processing: true,

            serverSide: true,

            deferRender: true,

            scrollX: true,

            ajax: {

                url :"./datatable/processingOrders.php",

                type :"POST"

            },

            columns: [

                {

                    "orderable": false,

                    "data": "actions",

                    "defaultContent": ""

                },

                { "data": "created_at"},

                { "data": "business"},

                { "data": "customer"},

                { "data": "net_amt"},

                { "data": "bill_to"},

                { "data": "ship_to"},

                { "data": "cust_comment"}

            ]

        });

        $.fn.dataTable.ext.errMode = 'throw';

    });

</script> 
