<?php



require('../class/DBController.php');



class Reports {



    private $db_handle;



    function __construct() {

        $this->db_handle = new DBController();

    }



    public function getCustomersNeverLogged() {

        /*$query = "SELECT provisional_cus_id `Account Made`, hawk_customer_id, (CONCAT(first_name, ' ', last_name)) `Customer Name`, email, telephone, (cus_fax_number) `Fax Number`, business_name, resale_no, created, if(logins.login_time, login_time, 'Yet To Login') `didLogged` 
FROM list_customers LEFT JOIN (SELECT max(id), max(login_time) `login_time`, user_id FROM user_login_timetracker GROUP BY user_id) logins ON logins.user_id = list_customers.user_id WHERE list_customers.status = 'Approved' AND logins.login_time IS NULL ORDER BY didLogged DESC;";*/
       $query = "SELECT 
    provisional_cus_id AS `Account Made`, 
    hawk_customer_id, 
    CONCAT(first_name, ' ', last_name) AS `Customer Name`, 
    email, 
    telephone, 
    cus_fax_number AS `Fax Number`, 
    business_name, 
    resale_no, 
    list_customers.created, 
    IF(logins.last_login_date IS NOT NULL, logins.last_login_date, 'Yet To Login') AS `didLogged`,
    logins.no_of_time_logged_in,
    purchases.last_purchase_date
FROM 
    list_customers
LEFT JOIN (
    SELECT 
        user_id, 
        MAX(login_time) AS last_login_date, 
        COUNT(*) AS no_of_time_logged_in
    FROM 
        user_login_timetracker
    GROUP BY 
        user_id
) logins 
    ON logins.user_id = list_customers.user_id
LEFT JOIN (
    SELECT 
        cust_id, 
        MAX(created_at) AS last_purchase_date
    FROM 
        trn_ord_hd
    GROUP BY 
        cust_id
) purchases 
    ON purchases.cust_id = list_customers.id
WHERE 
    list_customers.status = 'Approved' 
    AND logins.last_login_date IS NULL
ORDER BY 
    list_customers.created DESC";


        return $this->db_handle->runBaseQuery($query);
    }



    public function getCustomersLoggedButNeverOrders() {

        /*$query = "SELECT provisional_cus_id `Account Made`, hawk_customer_id, (CONCAT(first_name, ' ', last_name)) `Customer Name`, email, telephone, (cus_fax_number) `Fax Number`, business_name, resale_no, created, if(logins.login_time, login_time, 'Yet To Login') `didLogged` FROM list_customers LEFT JOIN (SELECT max(id), max(login_time) `login_time`, user_id FROM user_login_timetracker GROUP BY user_id) logins ON logins.user_id = list_customers.user_id LEFT JOIN (SELECT SUM(net_amt)'sum', cust_id FROM trn_ord_hd GROUP BY cust_id) yo ON yo.cust_id = list_customers.id WHERE list_customers.status = 'Approved' AND logins.login_time IS NOT NULL AND yo.sum IS NULL ORDER BY didLogged DESC";*/
		
		$query = "SELECT 
    provisional_cus_id AS `Account Made`, 
    hawk_customer_id, 
    CONCAT(first_name, ' ', last_name) AS `Customer Name`, 
    email, 
    telephone, 
    cus_fax_number AS `Fax Number`, 
    business_name, 
    resale_no, 
    list_customers.created AS created, 
    IF(logins.last_login_date IS NOT NULL, logins.last_login_date, 'Yet To Login') AS `didLogged`,
    logins.no_of_time_logged_in,
    purchases.last_purchase_date,
    yo.sum
FROM 
    list_customers
LEFT JOIN (
    SELECT 
        user_id, 
        MAX(login_time) AS last_login_date, 
        COUNT(*) AS no_of_time_logged_in
    FROM 
        user_login_timetracker
    GROUP BY 
        user_id
) logins 
    ON logins.user_id = list_customers.user_id
LEFT JOIN (
    SELECT 
        cust_id, 
        MAX(created_at) AS last_purchase_date
    FROM 
        trn_ord_hd
    GROUP BY 
        cust_id
) purchases 
    ON purchases.cust_id = list_customers.id
LEFT JOIN (
    SELECT 
        SUM(net_amt) AS sum, 
        cust_id 
    FROM 
        trn_ord_hd 
    GROUP BY 
        cust_id
) yo 
    ON yo.cust_id = list_customers.id
WHERE 
    list_customers.status = 'Approved' 
    AND logins.last_login_date IS NOT NULL 
    AND yo.sum IS NULL
ORDER BY 
    list_customers.created DESC";
        return $this->db_handle->runBaseQuery($query);

    }



    public function getCustomersDidntOrderedInLast3Months() {

        $today = new DateTime();

        $three_months_ago = $today->modify('-3 months')->format('Y-m-d H:i:s');
        error_log("three_months_ago " . $three_months_ago);
/*$query = "SELECT cust.created, hawk_customer_id, first_name, last_name, email, telephone, cus_fax_number, business_name, business_type, business_category, user_type, lastOrder.created as `Last Order On`, resale_no, logins.login_time FROM `list_customers` cust LEFT JOIN `addt_cust_info` add_cust ON cust.id = add_cust.cust_id LEFT JOIN (SELECT cust_id, max(created_at) `created` FROM `trn_ord_hd` GROUP BY cust_id) lastOrder ON cust.id = lastOrder.cust_id LEFT JOIN (SELECT max(id), max(login_time) `login_time`, user_id FROM user_login_timetracker GROUP BY user_id) logins ON logins.user_id = cust.user_id 
WHERE cust.status = 4 AND lastOrder.created < " . $three_months_ago . " ORDER BY lastOrder.created";*/
        $query = "SELECT 
        cust.created, 
        hawk_customer_id, 
        first_name, 
        last_name, 
        email, 
        telephone, 
        cus_fax_number, 
        business_name, 
        business_type, 
        business_category, 
        user_type, 
        lastOrder.created AS `Last Order On`, 
        resale_no,         
        logins.last_login_date, 
        logins.no_of_time_logged_in, 
        lastOrder.created AS last_purchase_date         
    FROM 
        `list_customers` cust 
    LEFT JOIN 
        `addt_cust_info` add_cust 
        ON cust.id = add_cust.cust_id 
    LEFT JOIN (
        SELECT 
            cust_id, 
            MAX(created_at) AS `created` 
        FROM 
            `trn_ord_hd` 
        GROUP BY 
            cust_id
    ) lastOrder 
        ON cust.id = lastOrder.cust_id 
    LEFT JOIN (
        SELECT 
            user_id, 
            MAX(login_time) AS last_login_date, 
            COUNT(*) AS no_of_time_logged_in 
        FROM 
            `user_login_timetracker` 
        GROUP BY 
            user_id
    ) logins 
        ON logins.user_id = cust.user_id 
    WHERE 
        cust.status = 4 
        AND (lastOrder.created IS NULL OR lastOrder.created < " . $three_months_ago . ") 
    ORDER BY 
        lastOrder.created";
         
        return $this->db_handle->runBaseQuery($query);
		
		

    }



    public function generateOutOfStocksProducts() {

$query = "SELECT (product_name) 'Hawk Product Name', IF(stock_quan > products.min_stock_req, CONCAT(stock_quan, ' ', 'Qty'), 'Out Of Stock') 'Stock Status', IF(products.active, 'Active', 'Discontinued') as 'Product Status', (product_categories.category_name)'Category',(product_subcategories.subCategory_name)'Sub-Category', (product_subsubcategories.subSubCategory_name) 'Sub-Sub-Category', (inr_bronze_price) 'INNER BRNZ ($)', (inr_silver_price) 'INNER SLVR ($)', (inr_gold_price) 'INNER GOLD ($)', (inr_platinum_price) 'INNER PLTM ($)', (case_bronze_price) 'CS BRNZ ($)', (case_silver_price) 'CS SLVR ($)', (case_gold_price) 'CS GOLD ($)', (case_platinum_price) 'CS PLTM ($)' 

FROM products LEFT JOIN product_categories on product_categories.id = products.category_id LEFT JOIN product_subcategories on product_subcategories.id = products.subCategory_id LEFT JOIN product_subsubcategories on product_subsubcategories.id = products.subSubCategory_id WHERE products.stock_quan <= products.min_stock_req AND products.active = true ORDER BY product_subcategories.cat_sub_order, product_subsubcategories.cat_sub_sub_order, products.listing_order";

        return $this->db_handle->runBaseQuery($query);

    }



    public function bestSellingCategory() {
		
		$startdate = $_POST['start_date'];
		$enddate = $_POST['end_date'];

        /*$query = "SELECT category_name FROM (SELECT sum(qty) as totalQty, product_name, category_id FROM (SELECT IFNULL(fullfilled_qty, ordered_qty)as qty, prod_id FROM trn_ord_dt) as ordered LEFT JOIN products ON products.id = ordered.prod_id GROUP BY ordered.prod_id ORDER BY totalQty DESC) as products_ordered LEFT JOIN product_categories ON product_categories.id = products_ordered.category_id GROUP BY category_id ORDER BY sum(totalQty) DESC";*/
		
		/*$query = "SELECT 
    pc.category_name, 
    SUM(hd.final_amt) AS totalAmount
FROM 
    trn_ord_hd hd
LEFT JOIN 
    trn_ord_dt tod ON hd.id = tod.hd_id
LEFT JOIN 
    products p ON tod.prod_id = p.id
LEFT JOIN 
    product_categories pc ON p.category_id = pc.id
WHERE 
    pc.category_name IS NOT NULL
	hd.delivered_at between $startdate $enddate
GROUP BY 
    pc.category_name
ORDER BY 
    totalAmount DESC";*/
	
	$query = "SELECT 
        pc.category_name, 
        SUM(hd.final_amt) AS totalAmount,
		hd.delivered_at
    FROM 
        trn_ord_hd hd
    LEFT JOIN 
        trn_ord_dt tod ON hd.id = tod.hd_id
    LEFT JOIN 
        products p ON tod.prod_id = p.id
    LEFT JOIN 
        product_categories pc ON p.category_id = pc.id
    WHERE 
        pc.category_name IS NOT NULL
        AND hd.delivered_at BETWEEN '$startdate' AND '$enddate'
    GROUP BY 
        pc.category_name
    ORDER BY 
        totalAmount DESC";

        return $this->db_handle->runBaseQuery($query);

    }



    public function bestSellingSubCategory() {

        /*$query = "SELECT ps.subCategory_name FROM (SELECT sum(qty) as totalQty, product_name, category_id, subCategory_id FROM (SELECT COALESCE(fullfilled_qty, ordered_qty)as qty, prod_id FROM trn_ord_dt WHERE ) as ordered LEFT JOIN products ON products.id = ordered.prod_id GROUP BY ordered.prod_id ORDER BY totalQty DESC) as products_ordered LEFT JOIN product_subcategories ps on products_ordered.subCategory_id = ps.id GROUP BY products_ordered.subCategory_id ORDER BY sum(totalQty) DESC";*/
		
		$startdate = $_POST['start_date'];
		$enddate = $_POST['end_date'];
		
		$query = "SELECT ps.subCategory_name, SUM(hd.final_amt) AS totalAmount, hd.delivered_at FROM trn_ord_hd hd
LEFT JOIN 
    trn_ord_dt tod ON hd.id = tod.hd_id
LEFT JOIN 
    products p ON tod.prod_id = p.id
LEFT JOIN 
    product_subcategories ps ON p.subCategory_id = ps.id
WHERE 
    ps.subCategory_name IS NOT NULL
	AND hd.delivered_at BETWEEN '$startdate' AND '$enddate'
GROUP BY 
    ps.subCategory_name
ORDER BY 
    totalAmount DESC";

        return $this->db_handle->runBaseQuery($query);

    }



    public function usersLoggedToday() {
		
		$timePeriod = $_POST['time_period'] ?? '';

// Define the time range filter based on the selected time period
$dateCondition = '';
if (!empty($timePeriod)) {
    switch ($timePeriod) {
        case 'today':
            $dateCondition = "DATE(logins.last_login_date) = CURDATE()";
            break;
        case 'last_5_days':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 5 DAY)";
            break;
        case 'last_10_days':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 10 DAY)";
            break;
        case 'last_30_days':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
            break;
        case 'last_3_months':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)";
            break;
        case 'last_6_months':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)";
            break;
        default:
            $dateCondition = ''; // No filtering if time period is not valid
            break;
    }
}


        /*$query = "SELECT first_name, last_name, email, business_name, login_time FROM user_login_timetracker ult 
		LEFT JOIN list_customers on list_customers.user_id = ult.user_id WHERE ult.login_time ";*/
		
		// Base query
$query = "
    SELECT 
        lc.provisional_cus_id AS `Account Made`, 
        lc.hawk_customer_id, 
        CONCAT(lc.first_name, ' ', lc.last_name) AS `Customer Name`, 
        lc.email, 
        lc.telephone, 
        lc.cus_fax_number AS `Fax Number`, 
        lc.business_name, 
        lc.resale_no, 
        lc.created AS `Created Date`, 
        IF(logins.last_login_date IS NOT NULL, logins.last_login_date, 'Yet To Login') AS `Last Login Date`, 
        logins.no_of_time_logged_in AS `Number of Logins`, 
        IF(purchases.last_purchase_date IS NOT NULL, purchases.last_purchase_date, 'N/A') AS `Last Purchase Date`, 
        IF(yo.sum IS NOT NULL, yo.sum, 0) AS `Total Purchases`
    FROM 
        list_customers lc
    LEFT JOIN (
        SELECT 
            user_id, 
            MAX(login_time) AS last_login_date, 
            COUNT(*) AS no_of_time_logged_in
        FROM 
            user_login_timetracker
        GROUP BY 
            user_id
    ) logins 
        ON logins.user_id = lc.user_id
    LEFT JOIN (
        SELECT 
            cust_id, 
            MAX(created_at) AS last_purchase_date
        FROM 
            trn_ord_hd
        GROUP BY 
            cust_id
    ) purchases 
        ON purchases.cust_id = lc.id
    LEFT JOIN (
        SELECT 
            SUM(net_amt) AS sum, 
            cust_id 
        FROM 
            trn_ord_hd 
        GROUP BY 
            cust_id
    ) yo 
        ON yo.cust_id = lc.id
    WHERE 
        lc.status = 'Approved'";

// Add the time period filter to the WHERE clause if applicable
if (!empty($dateCondition)) {
    $query .= " AND $dateCondition";
}

// Final ORDER BY clause
$query .= " ORDER BY lc.created DESC";


        return $this->db_handle->runBaseQuery($query);

    }
	
	public function itemssold() {
		
		$timePeriod = $_POST['time_period'] ?? '';

// Define the time range filter based on the selected time period
$dateCondition = '';
if (!empty($timePeriod)) {
    switch ($timePeriod) {
        case 'today':
            $dateCondition = "DATE(logins.last_login_date) = CURDATE()";
            break;
        case 'last_5_days':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 5 DAY)";
            break;
        case 'last_10_days':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 10 DAY)";
            break;
        case 'last_30_days':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
            break;
        case 'last_3_months':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)";
            break;
        case 'last_6_months':
            $dateCondition = "logins.last_login_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)";
            break;
        default:
            $dateCondition = ''; // No filtering if time period is not valid
            break;
    }
}


        /*$query = "SELECT first_name, last_name, email, business_name, login_time FROM user_login_timetracker ult 
		LEFT JOIN list_customers on list_customers.user_id = ult.user_id WHERE ult.login_time ";*/
		
		// Base query
$query = "
    SELECT 
        lc.provisional_cus_id AS `Account Made`, 
        lc.hawk_customer_id, 
        CONCAT(lc.first_name, ' ', lc.last_name) AS `Customer Name`, 
        lc.email, 
        lc.telephone, 
        lc.cus_fax_number AS `Fax Number`, 
        lc.business_name, 
        lc.resale_no, 
        lc.created AS `Created Date`, 
        IF(logins.last_login_date IS NOT NULL, logins.last_login_date, 'Yet To Login') AS `Last Login Date`, 
        logins.no_of_time_logged_in AS `Number of Logins`, 
        IF(purchases.last_purchase_date IS NOT NULL, purchases.last_purchase_date, 'N/A') AS `Last Purchase Date`, 
        IF(yo.sum IS NOT NULL, yo.sum, 0) AS `Total Purchases`
    FROM 
        list_customers lc
    LEFT JOIN (
        SELECT 
            user_id, 
            MAX(login_time) AS last_login_date, 
            COUNT(*) AS no_of_time_logged_in
        FROM 
            user_login_timetracker
        GROUP BY 
            user_id
    ) logins 
        ON logins.user_id = lc.user_id
    LEFT JOIN (
        SELECT 
            cust_id, 
            MAX(created_at) AS last_purchase_date
        FROM 
            trn_ord_hd
        GROUP BY 
            cust_id
    ) purchases 
        ON purchases.cust_id = lc.id
    LEFT JOIN (
        SELECT 
            SUM(net_amt) AS sum, 
            cust_id 
        FROM 
            trn_ord_hd 
        GROUP BY 
            cust_id
    ) yo 
        ON yo.cust_id = lc.id
    WHERE 
        lc.status = 'Approved'";

// Add the time period filter to the WHERE clause if applicable
if (!empty($dateCondition)) {
    $query .= " AND $dateCondition";
}

// Final ORDER BY clause
$query .= " ORDER BY lc.created DESC";


        return $this->db_handle->runBaseQuery($query);

    }
	
	public function getactivecartitems() {

       $query = "
        SELECT 
            id, 
            usr_id, 
            pr_id, 
            pr_type, 
            pr_qty, 
            created_on 
        FROM list_addtocart 
        WHERE status = 1
        ORDER BY created_on DESC;
    ";



        return $this->db_handle->runBaseQuery($query);
    }



    public function exportReportsToXLS($reportOf) {



        $timestamp = date("jS_M");



        switch ($reportOf) {

            case "never_logged":

                $queryResult = $this->getCustomersNeverLogged();

                break;

            case "never_ordered":

                $queryResult = $this->getCustomersLoggedButNeverOrders();

                break;

            case "no_order_in_three_months":

                $queryResult = $this->getCustomersDidntOrderedInLast3Months();

                break;

            case "out_of_stocks":

                $queryResult = $this->generateOutOfStocksProducts();

                break;

            case "most_sold_category":

                $queryResult = $this->bestSellingCategory();

                break;

            case "most_sold_sub_category":

                $queryResult = $this->bestSellingSubCategory();

                break;

            case "users_logged_today":

                $queryResult = $this->usersLoggedToday();

                break;
				
			case "items_sold":

                $queryResult = $this->itemssold();

                break;
				
			case "active_cart_items":

                $queryResult = $this->getactivecartitems();

                break;

        }





        $filename = 'report_' . $timestamp . '_' . $reportOf . '.csv';



        header("Content-Type: text/csv");

        header("Content-Disposition: attachment; filename=\"$filename\"");

        header("Content-Transfer-Encoding: UTF-8");



        $isPrintHeader = false;

        foreach ($queryResult as $row) {

            if (!$isPrintHeader) {

                echo "\"" . implode("\",\"", array_keys($row)) . "\"\r\n";

                $isPrintHeader = true;

            }

            echo "\"" . implode("\",\"", array_values($row)) . "\"\r\n";

        }

        exit();

    }

}