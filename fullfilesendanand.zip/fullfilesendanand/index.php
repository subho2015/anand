<?php $base = './';

$title = 'Dashboard' ?>
<?php include 'header.php';



require_once 'class/Dashboard.php';



$dashboard = new Dashboard();



$reports = [

  "never_ordered" => "Customer Logged but hasn't ordered yet",

  "never_logged" => "Customer Approved, but hasn't logged yet",

  "no_order_in_three_months" => "Customer didn't ordered in last 3 months",

  "out_of_stocks" => "Out Of Stock Products",

  "most_sold_category" => "Best selling Categories",

  "most_sold_sub_category" => "Best selling Sub-Categories",

  "users_logged_today" => "Users Logged Today",
  
  "items_sold" => "Items sold",
  
  "active_cart_items" => "Active cart items",

]

?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper">   
  <!-- START PAGE CONTENT -->  
  <div class="content">     
    <!-- START JUMBOTRON -->    
    <div class="jumbotron" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg sm-p-l-0 sm-p-r-0">
        <div class="inner">           
          <!-- START BREADCRUMB -->          
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Hawk</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>          
          <!-- END BREADCRUMB -->           
        </div>
      </div>
    </div>    
    <!-- END JUMBOTRON -->     
    <!-- START CONTAINER FLUID -->    
    <div class="container-fluid container-fixed-lg">       
      <!-- BEGIN PlACE PAGE CONTENT HERE -->      
      <div class="row">
        <div class="col-lg-6 col-sm-12  d-flex flex-column p-r-0 ">
          <div class="row">
            <div class="col-lg-6 col-sm-12 d-flex flex-column p-r-0 ">              
              <!-- START WIDGET widget_new_orders_card-->              
              <div class="card no-border widget-loader-bar m-b-10">
                <div class="container-xs-height full-height">
                  <div class="row-xs-height">
                    <div class="col-xs-height col-top">
                      <div class="card-header  top-left top-right">
                        <div class="card-title"> <span class="font-montserrat all-caps d-flex align-items-center text-info"> <i data-feather="box" aria-hidden="true"></i> <strong class="p-l-5">New Orders</strong> </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="row-xs-height">
                    <div class="col-xs-height col-top">
                      <div class="p-l-20 p-t-50 p-b-30 p-r-20">
                        <h2 class="no-margin p-b-10">
                          <?= $dashboard->getNewOrderCount() ?>
                        </h2>
                        <span class="pull-left small d-flex align-items-center"> <a href="<?= $base ?>orders/" class="text-black-50">View Details</a> <i class="pg-icon" aria-hidden="true">chevron_right</i> </span> </div>
                    </div>
                  </div>
                  <div class="row-xs-height">
                    <div class="col-xs-height col-bottom">
                      <div class="progress progress-small m-b-0">                        
                        <!-- START BOOTSTRAP PROGRESS (http://getbootstrap.com/components/#progress) -->                        
                        <div class="progress-bar progress-bar-info" style="width:100%"></div>                        
                        <!-- END BOOTSTRAP PROGRESS -->                         
                      </div>
                    </div>
                  </div>
                </div>
              </div>              
              <!-- END WIDGET -->               
            </div>
            <div class="col-lg-6 col-sm-12  d-flex flex-column p-r-0">               
              <!-- START WIDGET widget_new_customers_card-->              
              <div class="card no-border widget-loader-bar m-b-10">
                <div class="container-xs-height full-height">
                  <div class="row-xs-height">
                    <div class="col-xs-height col-top">
                      <div class="card-header  top-left top-right">
                        <div class="card-title"> <span class="font-montserrat all-caps d-flex align-items-center text-warning"> <i data-feather="user-plus" aria-hidden="true"></i> <strong class="p-l-5">New Customers</strong> </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="row-xs-height">
                    <div class="col-xs-height col-top">
                      <div class="p-l-20 p-t-50 p-b-30 p-r-20">
                        <h2 class="no-margin p-b-10">
                          <?= $dashboard->getNewCustomerCount() ?>
                        </h2>
                        <span class="pull-left small d-flex align-items-center"> <a href="<?= $base ?>customers/" class="text-black-50">Approve them</a> <i class="pg-icon" aria-hidden="true">chevron_right</i> </span> </div>
                    </div>
                  </div>
                  <div class="row-xs-height">
                    <div class="col-xs-height col-bottom">
                      <div class="progress progress-small m-b-0">
                        <!-- START BOOTSTRAP PROGRESS (http://getbootstrap.com/components/#progress) -->                        
                        <div class="progress-bar progress-bar-warning" style="width:100%"></div>                        
                        <!-- END BOOTSTRAP PROGRESS -->                         
                      </div>
                    </div>
                  </div>
                </div>
              </div>              
              <!-- END WIDGET -->               
            </div>
            <div class="col-lg-6 col-sm-12  d-flex flex-column p-r-0">               
              <!-- START WIDGET widget_product_inquiries_card-->              
              <div class="card no-border widget-loader-bar m-b-10">
                <div class="container-xs-height full-height">
                  <div class="row-xs-height">
                    <div class="col-xs-height col-top">
                      <div class="card-header  top-left top-right">
                        <div class="card-title"> <span class="font-montserrat all-caps d-flex align-items-center text-complete"> <i data-feather="paperclip" aria-hidden="true"></i> <strong class="p-l-5">Product Inquiries</strong> </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="row-xs-height">
                    <div class="col-xs-height col-top">
                      <div class="p-l-20 p-t-50 p-b-30 p-r-20">
                        <h2 class="no-margin p-b-10">
                          <?= $dashboard->getNewProductInquiryCount() ?>
                        </h2>
                        <span class="pull-left small d-flex align-items-center"> <a href="<?= $base ?>/productInquiry" class="text-black-50">Check Inquires </a> <i class="pg-icon" aria-hidden="true">chevron_right</i> </span> </div>
                    </div>
                  </div>
                  <div class="row-xs-height">
                    <div class="col-xs-height col-bottom">
                      <div class="progress progress-small m-b-0"> 
                        <!-- START BOOTSTRAP PROGRESS (http://getbootstrap.com/components/#progress) -->                        
                        <div class="progress-bar progress-bar-complete" style="width:100%"></div>                        
                        <!-- END BOOTSTRAP PROGRESS -->                         
                      </div>
                    </div>
                  </div>
                </div>
              </div>              
              <!-- END WIDGET -->               
            </div>
            <div class="col-lg-6 col-sm-12  d-flex flex-column p-r-0">               
              <!-- START WIDGET widget_weekly_sales_card-->              
              <div class="card no-border widget-loader-bar m-b-10">
                <div class="container-xs-height full-height">
                  <div class="row-xs-height">
                    <div class="col-xs-height col-top">
                      <div class="card-header top-left top-right">
                        <div class="card-title"> <span class="font-montserrat all-caps d-flex align-items-center text-success"> <i data-feather="truck" aria-hidden="true"></i> <strong class="p-l-5">Orders Shipped</strong> </span> </div>
                      </div>
                    </div>
                  </div>
                  <div class="row-xs-height">
                    <div class="col-xs-height col-top">
                      <div class="p-l-20 p-t-50 p-b-30 p-r-20">
                        <h2 class="no-margin p-b-10">
                          <?= $dashboard->getShippedOrderCount() ?>
                        </h2>
                        <span class="pull-left small d-flex align-items-center"> <a href="<?= $base ?>orders/shipped.php" class="text-black-50">Mark them Delivered</a> <i class="pg-icon" aria-hidden="true">chevron_right</i> </span> </div>
                    </div>
                  </div>
                  <div class="row-xs-height">
                    <div class="col-xs-height col-bottom">
                      <div class="progress progress-small m-b-0">                        
                        <!-- START BOOTSTRAP PROGRESS (http://getbootstrap.com/components/#progress) -->                        
                        <div class="progress-bar progress-bar-success" style="width:100%"></div>                        
                        <!-- END BOOTSTRAP PROGRESS -->                         
                      </div>
                    </div>
                  </div>
                </div>
              </div>              
              <!-- END WIDGET -->               
            </div>
          </div>
        </div>
        <div class="col-lg-6 col-sm-12  d-flex flex-column">           
          <!-- BEGIN PlACE PAGE CONTENT HERE -->          
          <div class="row">
            <div class="col-lg-12 col-sm-12  d-flex flex-column m-l-10">
              <div class="card card-default">
                <div class="card-header">
                  <div class="card-title">Reports </div>
                </div>
                <div class="card-block scrollable">
                  <table id="myDataTable" class="table" cellspacing="0" width="100%">
                    <thead>
                      <tr>
                        <th style="width:1%" >#</th>
                        <th style="width:90%">Title/Description</th>
                        <th style="width:9%"></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
					  //print_r($reports);
                    $count = 1;
                    foreach ($reports as $key => $value) { ?>
                      <tr>
                        <td><?= $count  ?></td>
                        <td><?= $value ?></td>
                        <td>
                            <form action="reports/downloadReport.php" method="post">
                            <!-- Add date range inputs -->
      <?php if ($key == 'most_sold_category' || $key == 'most_sold_sub_category') { ?>
        <div style="margin-top: 10px;">
          <label for="start_date">Start Date:</label>
          <input type="date" name="start_date" class="form-control" required>
          
          <label for="end_date" style="margin-top: 5px;">End Date:</label>
          <input type="date" name="end_date" class="form-control" required>
        </div>
      <?php } ?>
                            <?php
							
							//echo $key;
							if($key == 'users_logged_today')
							{
							?>
                            <select name="time_period" class="form-select">
                            
                            <option value="">Select Time-period</option>
              <option value="today">Today</option>
              <option value="last_5_days">Last 5 Days</option>
              <option value="last_10_days">Last 10 Days</option>
              <option value="last_30_days">Last 30 Days</option>
              <option value="last_3_months">Last 3 Months</option>
              <option value="last_6_months">Last 6 Months</option>
            </select>
                        <?php
							}
							elseif($key == 'items_sold')
							{
								?>
                                <select name="time_period" class="form-select">
                            
                            <option value="">Select Time-period</option>
              <option value="today">Today</option>
              <option value="last_5_days">Last 5 Days</option>
              <option value="last_10_days">Last 10 Days</option>
              <option value="last_30_days">Last 30 Days</option>
              <option value="last_3_months">Last 3 Months</option>
              <option value="last_6_months">Last 6 Months</option>
            </select>
                                <?php
							}
							?>
                            <button class="btn btn-primary btn-cons btn-animated from-top" name="report_type" value="<?= $key ?>" type="submit"> <span>Download</span> <span class="hidden-block"> <i class="pg-icon">download_alt</i> </button>
                          </form></td>
                      </tr>
                      <?php
                      $count++;
                    }
                    ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>          
          <!-- END PLACE PAGE CONTENT HERE -->           
        </div>
      </div>      
      <!-- END PLACE PAGE CONTENT HERE -->       
    </div>    
    <!-- END CONTAINER FLUID -->     
    <!-- START CONTAINER FLUID -->     
    <!-- END CONTAINER FLUID -->     
  </div>  
  <!-- END PAGE CONTENT -->   
</div>
<!-- END PAGE CONTENT WRAPPER -->
<?php include 'footer.php' ?>