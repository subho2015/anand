<?php

$base = "../";

$title = "Brands";

include $base . 'header.php' ?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper">
  <?php
	 if (isset($_GET['result'])) {
		 
		 //echo $_GET['result'];

            if ($_GET['result'] === "success") {
	?>
  <div class="pgn-wrapper" data-position="top" style="top: 59px; margin:0 0 20px 0;">
    <div class="pgn push-on-sidebar-open pgn-bar">
      <div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
        Brand Added</div>
    </div>
  </div>
  <?php 
		   }
        }
        ?>
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <div class="pull-left">
          <ol class="breadcrumb p-0">
            <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
          </ol>          
          <!-- END BREADCRUMB -->          
          <h3 class="page-title text-primary"><i data-feather="box" aria-hidden="true"></i> Brands</h3>
        </div>
        <button class="btn btn-complete btn-lg pull-right px-5" data-target="#addBrandNameModel" data-toggle="modal"> <i class="fa fa-plus-square p-r-10" aria-hidden="true"></i> Add New Brand </button>
      </div>
    </div>    
    <!-- END JUMBOTRON -->     
    <!-- START CONTAINER FLUID -->    
    <div class="container-fluid">       
      <!-- START card -->      
      <div class="card card-default p-t-20">
        <table class="table table-hover" id="brandsTable" cellspacing="0" width="100%">
          <thead class="card-body">
            <tr>
              <th scope="col" class="text-dark">Brands</th>
              <th scope="col"></th>
              <th scope="col"></th>
            </tr>
          </thead>
        </table>
      </div>      
      <!-- END card -->       
    </div>    
    <!-- END CONTAINER FLUID -->    
    <div class="modal fade slide-up" id="addBrandNameModel" tabindex="-1" role="dialog" aria-labelledby="addBrandName" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="addBrandName">
                <div class="card shadow-none no-margin no-padding">
                  <div class="card-body p-l-0 p-r-0">
                    <h3> Add Brand Name </h3>
                  </div>
                </div>
                <form role="form" method="post" action="BrandsAPI.php">
                  <div class="form-group form-group-default">
                    <label class="label-sm">Brand Name</label>
                    <input type="text" class="form-control" name="brands_name">
                  </div>
                  <div class="form-group input-group">
                    <div class="input-group-prepend"> <span class="input-group-text info"> <i class="pg-icon p-r-10" aria-hidden="true">picture</i> Brand Image </span> </div>
                    <input type="text" class="form-control" id="addBrandImageURL" placeholder="image-file-name.jpg/png/*any" name="brand_img" required>
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button" onclick="loadAddBrandImage()"> <i class="pg-icon" aria-hidden="true">refresh</i> Load </button>
                    </div>
                  </div>
                  <div id="loadAddBrandImage"> </div>
                  <input value="addNewBrand" name="function" hidden>
                  <button type="submit" class="btn btn-lg btn-block btn-complete">Add Brand</button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- /.modal-content --> 
      </div>
      <!-- /.modal-dialog --> 
    </div>
    <div class="modal fade slide-top" id="updateBrandNameModel" tabindex="-1" role="dialog" aria-labelledby="updateBrandName" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="updateBrandName"> </div>
            </div>
          </div>
        </div>        
        <!-- /.modal-content -->         
      </div>      
      <!-- /.modal-dialog -->       
    </div>
  </div>  
  <!-- END PAGE CONTENT -->   
</div>
<!-- END PAGE CONTENT WRAPPER --> 
<script src="js/brands.js"></script> 
<script>
    //todo Need auth.
    $(document).ready(function () {
        loadBrandList();
        $.fn.dataTable.ext.errMode = 'throw';
    });
    /*Brands Image*/
    const brandsImageAddDiv = document.getElementById('loadAddBrandImage');
    const brandsImageAddInputURL = document.getElementById('addBrandImageURL');

    function loadAddBrandImage() {
        loadImage(brandsImageAddDiv, brandsImageAddInputURL);
    }
</script>
<?php include '../footer.php' ?>