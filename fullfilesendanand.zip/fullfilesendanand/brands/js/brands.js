function loadBrandList() {

    $('#brandsTable').DataTable( {

        processing: true,

        serverSide: true,

        deferRender: true,

        ajax: {

            url :"./datatable/brands.php",

            type :"POST"

        },

        columns: [

            { "data": "brand_img"},

            { "data": "brands_name"},

            {

                "orderable": false,

                "data": "actions",

                "defaultContent": ""

            }

        ],

        "initComplete": function () {

            enableBrands();

            disableBrands();

            updateBrandName();

        }

    });

}



function enableBrands() {

    $('button.enable-brand').click(function () {

        changeStatus('activateBrand',$(this).data("id"));

    });

}



function disableBrands(){

    $('button.disable-brand').click(function () {

        changeStatus('deactivateBrand',$(this).data("id"));

    });

}



/*function updateBrandName(){

    $('button.update-brand').click(function () {

        loadUpdateBrandModel($(this).data("id"));

    });

}



function loadUpdateBrandModel(id){

    $.ajax({

        url: "modal/updateBrand.php?brandId=" + id, success: function (result) {

            $("#updateBrandName").html(result);

        }

    });

}*/

function updateBrandName(){
    $('button.update-brand').click(function () {
        loadUpdateBrandModel($(this).data("id"));
    });
}

function loadUpdateBrandModel(id){
    $.ajax({
        url: "modal/updateBrand.php?brandId=" + id,
        success: function (result) {
            $("#updateBrandName").html(result);
        }
    });
}



function changeStatus(functionName, id) {

    let params = {

        function: functionName,

        brandId: id

    };

    //console.log(functionName);

    callAPI(params);

}



function callAPI(params) {

    /*$.ajax({

        type: "POST",

        url: 'BrandsAPI.php',

        dataType: 'json',

        data: params,

        success: function (response) {
			alert(response.result);

            console.log(response.result);

            loadBrandList();

        }

    });*/
	
	$.ajax({
        type: "POST",
        url: 'BrandsAPI.php',
        dataType: 'json',
        data: params,
        success: function (response) {
			//alert(response.result);
            // Check if response has the expected structure
            if (response.result && response.message) {
                // Show success or failure message
                $('.page-content-wrapper').pgNotification({
                    style: 'bar',
                    message: response.message,
                    position: 'top',
                    timeout: 3000,
                    type: response.result.toLowerCase() === "success" ? "success" : "error"
                }).show();

                // Reload brand list if status change was successful
                if (response.result.toLowerCase() === "success") {
					window.loaction="";
					//alert(response.message);
					//alert(response.result);
                    loadBrandList();
					//window.loaction="/brands";
                }
            } else {
                // Fallback message for unexpected response
                $('.page-content-wrapper').pgNotification({
                    style: 'bar',
                    message: "Unexpected response. Please try again.",
                    position: 'top',
                    timeout: 3000,
                    type: "error"
                }).show();
            }
        },
        error: function () {
            // Handle AJAX error
            $('.page-content-wrapper').pgNotification({
                style: 'bar',
                message: "An error occurred. Please try again.",
                position: 'top',
                timeout: 3000,
                type: "error"
            }).show();
        }
    });

}



function loadImage(imageDiv, imageURL) {

    if (imageURL.value != "") {

        let img;

        if (imageDiv.childNodes.length > 1) {

            imageDiv.removeChild(imageDiv.childNodes[1]);

        }



        img = new Image();

        img.className = "img-thumbnail m-b-10";

        img.width = 200;

        img.src = "https://ewr1.vultrobjects.com/brands/" + imageURL.value;

        imageDiv.appendChild(img);

    } else {

        return false;

    }

}