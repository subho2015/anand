<?php

$base = "../";



// required headers

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

header("Access-Control-Allow-Methods: GET,POST,PUT");



require_once('class/Brands.php');



$brands = new Brands;



$method = $_SERVER['REQUEST_METHOD'];



if (isset($_REQUEST['function'])) {

    $functionName = $_REQUEST['function'];

}



if (isset($_REQUEST['brandId'])) {

    $brandId = $_REQUEST['brandId'];

}



/**

 * addNewBrand

 * activateBrand

 * deactivateBrand

 * updateBrandName

 */



if ($method === 'POST') {



    switch ($functionName) {

        case "addNewBrand" :

            $brandsName = htmlspecialchars($_POST['brands_name']);

            $brandsImage = htmlspecialchars($_POST['brand_img']);

            $brandId = $brands->addNewBrand($brandsName, $brandsImage);



            if (!empty($brandId)) {

                header('Location: ' . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=success");

            } else {

                header('Location: ' . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=failed&message=" . urlencode("Brand not added properly"));

            }

            break;

        case "activateBrand":

            $response = $brands->activateBrand($brandId);

            if ($response >= 1) {

                /*$result = "Success";

                $message = "Brands (".$_POST['brands_name'].") Activated";

                http_response_code(200);

                echo $result;*/
				$result = "Success";
        		$message = "Brand Activated";
        		http_response_code(200);

            } elseif ($response == 0) {

                /*$result = "Warning";

                $message = "Nothing to change";

                http_response_code(304);

                echo $result;*/
				$result = "Warning";
        		$message = "Nothing to change";
       			http_response_code(304);

            } else {

                /*$result = "Failed";

                $message = "Error while activating brand";

                http_response_code(409);

                echo $result;*/
				$result = "Failed";
        		$message = "Error while activating brand";
        		http_response_code(409);

            }

            //header('Location:' . strtok($_SERVER["REQUEST_URI"], '?') . "?result=" . $result . "&message=" . urlencode($message));
			echo json_encode(["result" => $result, "message" => $message]);
    		exit;

            break;

        case "deactivateBrand":

            $response = $brands->deactivateBrand($brandId);

            if ($response >= 1) {
                /*$result = "Success";
                $message = "Brands (".$_POST['brands_name'].") Deactivated";
                http_response_code(200);
                echo $result;*/
				$result = "Success";
        		$message = "Brands Deactivated";
        		http_response_code(200);

            } elseif ($response == 0) {
                /*$result = "Warning";
                $message = "Nothing to change";
                http_response_code(304);
                echo $result;*/
				$result = "Warning";
        		$message = "Nothing to change";
       			http_response_code(304);

            } else {

                /*$result = "Failed";
                $message = "Error while deactivating brand";
                http_response_code(409);
                echo $result;*/
				$result = "Failed";
        		$message = "Error while activating brand";
        		http_response_code(409);

            }
            echo json_encode(["result" => $result, "message" => $message]);
            exit;
            //header('Location:' . strtok($_SERVER["REQUEST_URI"], '?') . "?result=" . $result . "&message=" . urlencode($message));

            break;

        case "updateBrandName":

            $brandsName = htmlspecialchars($_POST['brands_name']);

            $brandsImage = htmlspecialchars($_POST['brand_img']);



            $response = $brands->updateBrandName($brandId, $brandsName, $brandsImage);

            if ($response >= 1) {

                $result = "Success";

                $message = "Brands (".$_POST['brands_name'].") Updated";

                http_response_code(200);
				

                //echo $result;

            } elseif ($response == 0) {

                $result = "Warning";

                $message = "Nothing to change";

                http_response_code(304);

               // echo $result;
			  

            } else {

                $result = "Failed";

                $message = "Error while updating brand";

                http_response_code(409);
				

                //echo $result;

            }

            //header('Location:' . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=" . $result . "&message=" . urlencode($message));
			
			// Return JSON response
   header('Content-Type: application/json');
echo json_encode([
    "status" => $result,
    "message" => $message,
    "redirect_url" => strtok($_SERVER["HTTP_REFERER"], '?') . "?result=" . $result . "&message=" . urlencode($message)
]);

            break;

        default:

            throw new Exception('Unexpected value');

    }

}