<?php

$base = "../../";

require_once("../class/Brands.php");

$brandId = $_REQUEST['brandId'];



$brand = new Brands();

$brand = $brand->getBrandById($brandId);

$brandName = $brand['brands_name'];

$brandImg = $brand['brand_img'];

?>

<div class="card shadow-none no-margin no-padding">
  <div class="card-body p-l-0 p-r-0">
    <h3> Update Brand Name </h3>
  </div>
</div>
<form id="updateBrandForm" role="form" method="post" action="">
  <div class="form-group form-group-default">
    <label class="label-sm">Brand Name</label>
    <input type="text" class="form-control" name="brands_name" value="<?= $brandName ?>">
  </div>
  <input value="<?= $brandId ?>" name="brandId" hidden>
  <input value="updateBrandName" name="function" hidden>
  <div class="form-group input-group">
    <div class="input-group-prepend"> <span class="input-group-text info"> <i class="pg-icon p-r-10" aria-hidden="true">picture</i> Brand Image </span> </div>
    <input type="text" class="form-control" id="updateBrandImageURL" placeholder="image-file-name.jpg/png/*any" name="brand_img" value="<?=$brandImg?>" required>
    <div class="input-group-append">
      <button class="btn btn-primary loadBrandImage" type="button"> <i class="pg-icon" aria-hidden="true">refresh</i> Load </button>
    </div>
  </div>
  <div id="updateLoadBrandImage"> </div>
  <button type="submit" class="btn btn-lg btn-block btn-complete">Update</button>
</form>
<script>

    /*Brands Image*/

    $(document).ready(function () {
    // Submit form via AJAX
    $("#updateBrandForm").on("submit", function (e) {
        e.preventDefault(); // Prevent default form submission

        $.ajax({
            type: "POST",
            url: "./BrandsAPI.php",
            data: $(this).serialize(),
            success: function(response) {
    console.log("Raw response:", response); // Log raw response to check its format

    try {
        let data = JSON.parse(response); // Attempt to parse response as JSON
        alert(data.message); // Display message
        if (data.status === "Success") {
            window.location.href = data.redirect_url;
        }
    } catch (error) {
        console.error("JSON parse error:", error, response); // Log error with raw response
		console.log("JSON parse error:", error, response);
        alert("Brand Updated!");
		$('#updateBrandForm').hide();
		$('#updateBrandNameModel').hide();
		window.location = "";
    }
},
            error: function(xhr, status, error) {
                console.error("AJAX Error:", error);
                alert("An error occurred while updating the brand.");
            }
        });
    });

    // Load brand image
    $(".loadBrandImage").click(function () {
        loadImage($('#updateLoadBrandImage')[0], $('#updateBrandImageURL')[0]);
    });
});



            /*$.post($(this).attr("action"), $(this).serialize(), function (response) {
                try {
                    // Parse JSON response
                    let data = JSON.parse(response);
                    alert(data.message); // Show message in alert

                    // Redirect if successful
                    if (data.status === "Success") {
                        window.location.href = data.redirect_url;
                    }
                } catch (error) {
                    console.error("JSON parse error:", error);
                    alert("An error occurred while updating the brand.");
                }
            });*/
        /*});

        $(".loadBrandImage").click(function () {

            loadImage($('#updateLoadBrandImage')[0], $('#updateBrandImageURL')[0]);

        });

    });*/



</script>