function newCustomersTableInit() {



    $('#newCustomersTable').DataTable({

        processing: true,

        serverSide: true,

        scrollX: true,

        ajax: "./datatable/newCustomers.php",

        columns: [

            {

                "orderable": false,

                "data": "status",

                "defaultContent": ""

            },

            {"data": "created"},

            {"data": "business"},

            {"data": "customer"},

            {"data": "billing_address"},

            {"data": "resale_no"}

        ],

        "initComplete": function () {

            approveUserAction();

        }

    });



    $.fn.dataTable.ext.errMode = 'throw';

}



function activeCustomersTable() {

    $('#activeCustomersTable').DataTable({

        processing: true,

        serverSide: true,

        scrollX: true,

        deferRender: true,

        //https://stackoverflow.com/questions/32640246/jquery-datatables-add-class-to-tr

        // createdRow: function( row, data, dataIndex ) {

        //     // Set the data-status attribute, and add a class

        //     $( row ).find('td:eq(0)')

        //         .attr('data-status', data.status ? 'locked' : 'unlocked');

        // },

        ajax: {

            url: "./datatable/activeCustomers.php",

            type: "POST"

        },

        columns: [

            {

                "orderable": false,

                "data": "actions",

                "defaultContent": ""

            },

            {

                "orderable": false,

                "data": "activated_on"

            },

            {"data": "business"},

            {"data": "customer"},

            {"data": "last_login"},

            {"data": "user_type"},

            {"data": "special_note"},

            {"data": "last_invoice"},
			
			



        ],

        "initComplete": function () {

            moreUserInfoAction('#activeCustomersTable');

            // moreUserInfoAction();

        }

    });
	
	/*$.fn.dataTableExt.afnFiltering.push(
  function(oSettings, aData, iDataIndex) {
      var keywords = $(".dataTables_filter input").val().split(' ');  
      var matches = 0;
      for (var k=0; k<keywords.length; k++) {
          var keyword = keywords[k];
          for (var col=0; col<aData.length; col++) {
              if (aData[col].indexOf(keyword)>-1) {
                  matches++;
                  break;
              }
          }
      }
      return matches == keywords.length;
   }
);*/

    $.fn.dataTable.ext.errMode = 'throw';

}



function disableUserTable() {
   //customerDataTableInit("#disabledCustomersTable", "./datatable/disabledCustomers.php");
   
    /*const table = customerDataTableInit("#disabledCustomersTable", "./datatable/disabledCustomers.php");
    console.log("DataTable instance:", table);
    return table;*/
	
	return customerDataTableInit("#disabledCustomersTable", "./datatable/disabledCustomers.php");
  
}



function inactiveCustomersTable() {

    customerDataTableInit("#inactiveCustomersTable", "./datatable/inactiveCustomers.php");

}



function rejectedCustomersTableInit() {



    $('#rejectedCustomersTable').DataTable({

        processing: true,

        serverSide: true,

        scrollX: true,

        ajax: "./datatable/rejectedCustomers.php",

        columns: [

            {

                "orderable": false,

                "data": "status",

                "defaultContent": ""

            },

            {"data": "created"},

            {"data": "business"},

            {"data": "customer"},

            {"data": "billing_address"},

            {"data": "resale_no"},

            {"data": "rejected_disabled_reason"}

        ],

        "initComplete": function () {

            approveUserAction();

        }

    });



    $.fn.dataTable.ext.errMode = 'throw';

}



function unverifiedCustomersTableInit() {



    $('#disabledCustomersTable').DataTable({

        processing: true,

        serverSide: true,

        scrollX: true,

        ajax: "./datatable/unverifiedCustomers.php",

        columns: [

            {

                "orderable": false,

                "data": "status",

                "defaultContent": ""

            },

            {"data": "created"},

            {"data": "business"},

            {"data": "customer"},

            {"data": "resale_no"},

        ]

        // "initComplete": function () {

        //     verifyCustomerEmail();

        // }

    });



    $.fn.dataTable.ext.errMode = 'throw';

}



function customerDataTableInit(tableId, dataURL) {

    /*$(tableId).DataTable(approvedCustomersInfoProvider(tableId, dataURL));
	$.fn.dataTable.ext.errMode = 'throw';*/
	
	/*let table = $(tableId).DataTable(approvedCustomersInfoProvider(tableId, dataURL));
    $.fn.dataTable.ext.errMode = 'throw';
    return table; // Return table instance for further use*/
	
	 const table = $(tableId).DataTable(approvedCustomersInfoProvider(tableId, dataURL));
    $.fn.dataTable.ext.errMode = 'throw';

    // Return the table instance so it can be used elsewhere
    return table;

    // Log to confirm if DataTable is initialized correctly
    if (table) {
        console.log("DataTable successfully initialized on", tableId);
    } else {
        console.error("Failed to initialize DataTable on", tableId);
    }
	
	/*let table = $(tableId).DataTable(
	    { select: true,}
		approvedCustomersInfoProvider(tableId, dataURL)
	);
    $.fn.dataTable.ext.errMode = 'throw';
    return table; // Return table instance for further use*/
	

}



function approvedCustomersInfoProvider(tableId, dataURL) {

   /* return {
        searching: true,
        processing: true,
        serverSide: true,
        scrollX: true,
        deferRender: true,
        ajax: {

            url: dataURL,
            type: "POST",
			let customerTypes = [];
            $('.customer_type:checked').each(function () {
                customerTypes.push($(this).val());
            });
			url: dataURL,
            type: "POST",
            data: function (d) {
                let customerTypes = [];
                $('.customer_type:checked').each(function () {
                    customerTypes.push($(this).val());
                });

                return $.extend({}, d, {
                    "search_keywords": $("#searchInput").val().toLowerCase(),
                    "filter_option": $("#sortBy").val().toLowerCase(),
                    "filter_country": $("#filtercountry").val().toLowerCase(),
                    "start_date": $("#start_date").val(),
                    "end_date": $("#end_date").val(),
                    "customer_type": customerTypes // Pass array of selected customer types
                });
            }

        },

        columns: [
            {
                "orderable": false,
                "data": "actions",
                "defaultContent": ""
            },
            {
                "orderable": false,
                "data": "activated_on"
            },
            {"data": "business"},
            {"data": "customer"},
            {"data": "user_type"},
            {"data": "last_invoice"},
            {"data": "last_login"},
            {"data": "rejected_disabled_reason"}
        ],

        "initComplete": function () {
            moreUserInfoAction(tableId);
        },
		
		"dom": 'Blfrtip', // Filter input, table, info, pagination, then buttons
    "buttons": [
        {
            extend: 'copyHtml5', text: 'Copy'
        },
        {
            extend: 'excelHtml5', text: 'Excel'
        },
        {
            extend: 'csvHtml5', text: 'CSV'
        },
        {
            extend: 'pdfHtml5', text: 'PDF'
        }
    ]

    }*/
	
	return {
        searching: true,
        processing: true,
        serverSide: true,
        scrollX: true,
        deferRender: true,
        ajax: {
            url: dataURL,
            type: "POST",
            data: function (d) {
                let customerTypes = [];
                $('.customer_type:checked').each(function () {
                    customerTypes.push($(this).val());
                });
                return $.extend({}, d, {
                    "customer_type": customerTypes // Pass array of selected customer types
                });
            }
        },
        columns: [
            { "orderable": false, "data": "actions", "defaultContent": "" },
            { "orderable": false, "data": "activated_on" },
            { "data": "business" },
            { "data": "customer" },
            { "data": "user_type" },
            { "data": "last_invoice" },
            { "data": "last_login" },
            { "data": "rejected_disabled_reason" }
        ],
        "initComplete": function () {
            moreUserInfoAction(tableId);
        },
        /*"dom": 'Blfrtip',
        "buttons": [
           // { extend: 'copyHtml5', text: 'Copy' },
           // { extend: 'excelHtml5', text: 'Excel' },
            { extend: 'csvHtml5', text: 'CSV' },
           // { extend: 'pdfHtml5', text: 'PDF' }
        ]*/
    };

}



function approveUserAction() {

    $('button.approve-user').click(function () {

        loadCustomerApprovalModel($(this).data("id"));

    });

}



/*function moreUserInfoAction(tableId) {

    $(tableId).on('click', 'button.more-user', function () {

        loadCustomersAdditionalInfo($(this).data("id")); //custId

    });

}*/

function moreUserInfoAction() {
    $('button.more-user').click(function () {
		//alert("Test666");
        loadCustomersAdditionalInfo($(this).data("id"));
    });
}



function loadCustomersAdditionalInfo(custId) {

    $.ajax({

        url: "modal/customerInfos.php?customerId=" + custId, success: function (result) {

            console.log(result);
			//alert(result);

            $("#additionCustomer").html(result);

        }

    });

}



function loadCustomerApprovalModel(id) {

    $.ajax({

        url: "modal/approveCustomer.php?customerId=" + id, success: function (result) {

            $("#approveCustomer").html(result);

        }

    });

}



function disableCustomer(clickedCustomer) {

    var customerId = $(clickedCustomer).data("id");

    var currentPage = $(clickedCustomer).data("label");

    const params = {

        function: 'disableApprovedCustomerWithReason',

        customerId: customerId,

        disableReason: "NA"

    };



    callAPI(params, "active", currentPage);

}



function rejectCustomer(clickedCustomer) {

    var customerId = $(clickedCustomer).data("id");

    const params = {

        function: 'rejectNewCustomerWithReason',

        customerId: customerId,

        rejectedReason: 'Rejected'

    };

    callAPI(params, "rejected", clickedCustomer);

}



function deleteCustomer(clickedCustomer) {

    similarCallAPIActions(clickedCustomer, "deleteCustomer", "disabled")

}



function verifyCustomerEmail(clickedCustomer) {

    similarCallAPIActions(clickedCustomer, "verifyCustomerEmail", "disabled")

}



function reactivateCustomer(clickedCustomer) {

    similarCallAPIActions(clickedCustomer,"enableDisabledCustomer", "disabled")



}



function similarCallAPIActions(clickedCustomer, functionName, currentPage) {

    var customerId = $(clickedCustomer).data("id");



    const params = {

        function: functionName,

        customerId: customerId

    };



    callAPI(params, currentPage, clickedCustomer);

}



function callAPI(params, currentPage, clickedCustomer) {

    // console.log(params);

    $.ajax({

        type: "POST",

        url: 'CustomersAPI.php',

        dataType: 'json',

        data: params

    }).done(function (result) {

        console.log(result);

        if (result.result === 'Success') {



            var table1 = $('#' + currentPage + 'CustomersTable').DataTable();



            table1.row($(clickedCustomer).parents('tr')).remove().draw();



            $('.page-content-wrapper').pgNotification({

                style: 'bar',

                message: result.message,

                position: 'top',

                timeout: 0,

                type: 'success'

            }).show();

        } else {

            $('.page-content-wrapper').pgNotification({

                style: 'bar',

                message: result.message,

                position: 'top',

                timeout: 0,

                type: 'danger'

            }).show();

        }

    });

}