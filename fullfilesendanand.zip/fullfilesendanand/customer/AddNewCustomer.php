<?php 
$base = '../';

$title = '+ New Customer';

$formInPage = true 

//echo "Test";


//$message = isset($_GET['message']) ? addslashes($_GET['message']) : ''; // Escape any special characters
//echo $result = $_GET['result'];
?>
<?php 
include '../header.php'; 


//echo $message;
?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <div class="pull-left">
          <ol class="breadcrumb p-0">
            <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
            <li class="breadcrumb-item active"><a href="activeCustomers.php">Customer</a></li>
          </ol>
          
          <!-- END BREADCRUMB -->
          
          <h3 class="page-title text-primary"> <i class="fa fa-plus-square p-r-10" aria-hidden="true"></i> Add New Customer </h3>
        </div>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container"> 
      
      <!-- START card -->
      
      <div class="row">
        <div class="col-md-9 offset-1 m-t-25 m-b-50">
          <form id="addNewCustomer" role="form" action="CustomersAPI.php" method="post">
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Hawk Customer Id</label>
                        <input type="text" class="form-control" name="hawk_customer_id" required>
                      </div>
                    </div>
                    <div class="col-md-5">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">First Name</label>
                        <input type="text" class="form-control" name="first_name" required>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Last Name</label>
                        <input type="text" class="form-control" name="last_name" required>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">User Type</label>
                        <select class="full-width" data-init-plugin="select2" name="user_type" required>
                          <option value="bronze">Bronze</option>
                          <option value="silver">Silver</option>
                          <option value="gold">Gold</option>
                          <option value="platinum">Platinum</option>
                          <option value="corporate">Corporate</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-5">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Primary Email</label>
                        <input type="text" class="form-control" name="email" required>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Phone No</label>
                        <input type="number" class="form-control" name="telephone" minlength="10" maxlength="10" required>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group-attached">
                  <h6 class="p-t-10 text-primary">Business Details</h6>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Business Name</label>
                        <input type="text" class="form-control" name="business_name" required>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Fax No</label>
                        <input type="number" class="form-control" name="cus_fax_number">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Business Type</label>
                        <select class="full-width" data-init-plugin="select2" name="business_type" required>
                          <option>Catalog</option>
                          <option>Multi-Stores</option>
                          <option>Flea Market</option>
                          <option>Online</option>
                          <option>Closeout Company</option>
                          <option>Whole-seller</option>
                          <option>Others</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Business Category</label>
                        <select class="full-width" data-init-plugin="select2" name="business_category" required>
                          <option>Jewelry and Craft Tools</option>
                          <option>Safety / Gloves / Rainwear</option>
                          <option>Automotive</option>
                          <option>General Merchandise</option>
                          <option>Government</option>
                          <option>Promotional Products</option>
                          <option>Others</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Resale Number</label>
                        <input type="text" class="form-control" name="resale_no">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Company Website</label>
                        <input type="text" class="form-control" name="company_website">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group-attached">
                  <h6 class="p-t-10 text-primary">Create Password</h6>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Password</label>
                        <input type="password" class="form-control" name="password" autocomplete="new-password" required>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Confirm Password</label>
                        <input type="text" class="form-control" name="confirm password" autocomplete="new-password" required>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <h4 class="p-t-10 text-black-50 hint-text">Billing Address</h4>
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <input name="function" value="addCustomerViaWebsite" hidden>
                  <div class="form-group form-group-default required">
                    <label class="label-sm">Name</label>
                    <input type="text" class="form-control" name="name" required>
                  </div>
                  <div class="form-group form-group-default required">
                    <label class="label-sm">Address Line 1</label>
                    <input type="text" class="form-control" name="usr_address1" required>
                  </div>
                  <div class="form-group form-group-default">
                    <label class="label-sm">Address Line 2</label>
                    <input type="text" class="form-control" name="usr_address2">
                  </div>
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">City</label>
                        <input type="text" class="form-control" name="city" required>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">State</label>
                        <input type="text" class="form-control" name="state" required>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Country</label>
                        <input type="text" class="form-control" name="country" autocomplete="country" required>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Zipcode</label>
                        <input type="text" class="form-control" name="zipcode" required>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <h4 class="p-t-10 text-black-50 hint-text">Additional Customer Info</h4>
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <div class="row">
                    <div class="col-md-5">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Primary Owner Id</label>
                        <input type="text" class="form-control" name="primary_owner_id">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Sales Rep Id</label>
                        <input type="text" class="form-control" name="sales_rep_id">
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Temp Id</label>
                        <input type="text" class="form-control" name="temp_id">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default p-b-10" style="height: fit-content">
                        <label class="label-sm ">Special Note</label>
                        <textarea form="addNewCustomer" type="text" class="form-control" name="special_note" style="height: fit-content" rows="3"></textarea>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default p-b-10">
                        <label class="label-sm">Sales Rep Note</label>
                        <textarea form="addNewCustomer" type="text" name="sales_rep_note" rows="3" style="height: fit-content" class="form-control"></textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default p-b-10">
                        <label class="label-sm ">Credit Ref.</label>
                        <textarea form="addNewCustomer" type="text" class="form-control" name="credit_ref" rows="3" style="height: fit-content"></textarea>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default p-b-10">
                        <label class="label-sm">Shipping Note</label>
                        <textarea form="addNewCustomer" type="text" name="ship_note" rows="3" style="height: fit-content" class="form-control"></textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Monthly Flyer</label>
                        <input type="text" class="form-control" name="monthly_flyer">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Freight Policy</label>
                        <textarea form="addNewCustomer" type="text" class="form-control" name="freight_policy"></textarea>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Freight Paid</label>
                        <input type="text" class="form-control" name="freight_paid">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <h4 class="p-t-10 text-black-50 hint-text">Follow Up</h4>
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <div class="form-group form-group-default">
                    <label class="label-sm">Follow Up 1</label>
                    <textarea form="addNewCustomer" type="text" name="follow_up_1" rows="3" style="height: fit-content" class="form-control"></textarea>
                  </div>
                  <div class="form-group form-group-default">
                    <label class="label-sm">Follow Up 2</label>
                    <textarea form="addNewCustomer" type="text" name="follow_up_2" rows="3" style="height: fit-content" class="form-control"></textarea>
                  </div>
                  <div class="form-group form-group-default">
                    <label class="label-sm">Follow Up 3</label>
                    <textarea form="addNewCustomer" type="text" name="follow_up_3" rows="3" style="height: fit-content" class="form-control"></textarea>
                  </div>
                  <div class="form-group form-group-default">
                    <label class="label-sm">Follow Up 4</label>
                    <textarea form="addNewCustomer" type="text" name="follow_up_4" rows="3" style="height: fit-content" class="form-control"></textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="pull-right col-md-6 col-sm-12">
              <button class="btn btn-lg btn-block btn-complete" type="submit">Add Customer</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../footer.php' ?>
<script>
    $(document).ready(function () {
        $('.autonumeric').autoNumeric('init');
        <?php
        $message = isset($_GET['message']) ? addslashes($_GET['message']) : ''; // Escape any special characters

        if (isset($_GET['result'])) {
            if ($_GET['result'] == "success") {
                ?>
                $('.page-content-wrapper').pgNotification({
                    style: 'bar',
                    message: "Customer Added",
                    position: 'top',
                    timeout: 0,
                    type: "success",
                }).show();
                <?php 
            } elseif ($_GET['result'] == "failed") {
                ?>
                $('.page-content-wrapper').pgNotification({
                    style: 'bar',
                    message: "<?php echo $message; ?>", // PHP will insert the sanitized message here
                    position: 'top',
                    timeout: 0,
                    type: "error", // Use 'error' or another appropriate type
                }).show();
                <?php 
            }
        }
        ?>
    });
</script>