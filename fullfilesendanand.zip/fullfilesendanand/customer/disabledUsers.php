<?php $base = '../';

$title = 'Disabled | Customers' ?>
<?php include $base.'header.php' ?>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.6/css/buttons.dataTables.min.css">
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <ol class="breadcrumb p-0">
          <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
          <li class="breadcrumb-item active"><a href="activeCustomers.php">Customers</a></li>
        </ol>
        
        <!-- END BREADCRUMB -->
        
        <h3 class="page-title text-primary"><i data-feather="box"></i> Disabled Customers</h3>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container-fluid"> 
      
      <!-- START card -->
      <div class="form-group">
            <label>Customer Type:</label><br>
            <input type="checkbox" name="customer_type" value="Gold" class="customer_type"> Gold
            <input type="checkbox" name="customer_type" value="Silver" class="customer_type"> Silver
            <input type="checkbox" name="customer_type" value="Bronze" class="customer_type"> Bronze
        </div>
        <div class="form-group" align="center">
      <button type="button" name="filter" id="filter" class="btn btn-info">Filter</button>
     </div>
      <div class="card card-default p-t-20">
       <div class="dt-buttons1">
    <button class="dt-button1 buttons-csv1 buttons-html51" 
            tabindex="0" 
            aria-controls="disabledCustomersTable" 
            type="button" 
            onclick="downloadCSV()">
        <span>CSV</span>
    </button>
</div>
        <table class="table table-hover nowrap" id="disabledCustomersTable" cellspacing="0" width="100%">
          <thead class="card-body">
            <tr>
              <th></th>
              <th class="text-dark" style="letter-spacing: 0">Customer Id</th>
              <th class="text-dark" style="letter-spacing: 0">Business</th>
              <th class="text-dark" style="letter-spacing: 0">Contact Person</th>
              <th class="text-dark" style="letter-spacing: 0">Customer Type</th>
              <th class="text-dark" style="letter-spacing: 0">Last Invoice</th>
              <th class="text-dark" style="letter-spacing: 0">Last Login</th>
              <th class="text-dark" style="letter-spacing: 0">Disable Reason</th>
            </tr>
          </thead>
        </table>
      </div>
      
      <!-- END card --> 
      
    </div>
    
    <!-- END CONTAINER FLUID -->
    
    <div class="modal fade slide-right" id="additionCustomerInfoModel" tabindex="-1" role="dialog" aria-labelledby="additionCustomerInfo"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="additionCustomer"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-up" id="additionCustomerEmailModel" tabindex="-1" role="dialog" aria-labelledby="additionCustomerEmail"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="additionalEmail"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
  </div>
  
  <!-- END PAGE CONTENT --> 
  
</div>

<!-- END PAGE CONTENT WRAPPER -->

<?php include '../footer.php' ?>
<script src="js/customers.js" type="text/javascript"></script> 
<script>
    function downloadCSV() {
        // Redirect to the PHP script to trigger the download
        window.location.href = 'disableduserdownload_csv.php';
    }
</script>
<script>

   /* $(document).ready(function () {
		var table = disableUserTable();
         $('#filter').on('click', function () {
    table.draw();
});
       
		

    });*/
	
	$(document).ready(function () {
        // Initialize the DataTable and assign it to the table variable
        var table = disableUserTable();

        // Filter data based on selected customer types
        $('#filter').on('click', function () {
            table.draw();
        });

        // Trigger a redraw when any checkbox is changed
        $('.customer_type').on('change', function () {
            table.draw();
        });
    });

</script>