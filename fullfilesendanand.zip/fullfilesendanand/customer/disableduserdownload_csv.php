<?php
// Database connection
$host = "localhost";
$username = "fourtune_hawk";
$password = "7-CUb=J&8{84";
$dbname = "fourtune_hawk";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//require_once 'datatableUtils/DBTablesConst.php';

// Define the query
/*$table = "
    `list_customers` cust
    LEFT JOIN `addt_cust_info` add_cust ON cust.id = add_cust.cust_id
    LEFT JOIN (
        SELECT ord1.cust_id, ord1.invoice_no, ord1.final_amt, ord1.updated_at, ord1.ord_status
        FROM `trn_ord_hd` ord1
        INNER JOIN (
            SELECT cust_id, MAX(updated_at) as latest_updated
            FROM `trn_ord_hd`
            WHERE ord_status > 4
            GROUP BY cust_id
        ) ord2 ON ord1.cust_id = ord2.cust_id AND ord1.updated_at = ord2.latest_updated
        WHERE ord1.ord_status > 4
    ) lastOrder ON cust.id = lastOrder.cust_id
    LEFT JOIN (
        SELECT login.user_id, login.login_time, login.login_ip
        FROM `user_login_timetracker` login
        INNER JOIN (
            SELECT user_id, MAX(login_time) as latest_login
            FROM `user_login_timetracker`
            GROUP BY user_id
        ) latestLogin ON login.user_id = latestLogin.user_id AND login.login_time = latestLogin.latest_login
    ) login ON cust.user_id = login.user_id
";*/

$table = "`list_customers` cust
    LEFT JOIN `addt_cust_info` add_cust ON cust.id = add_cust.cust_id
    LEFT JOIN (
        SELECT ord1.cust_id, ord1.invoice_no, ord1.final_amt, ord1.updated_at, ord1.ord_status
        FROM `trn_ord_hd` ord1
        INNER JOIN (
            SELECT cust_id, MAX(updated_at) as latest_updated
            FROM `trn_ord_hd`
            WHERE ord_status > 4
            GROUP BY cust_id
        ) ord2 ON ord1.cust_id = ord2.cust_id AND ord1.updated_at = ord2.latest_updated
        WHERE ord1.ord_status > 4
    ) lastOrder ON cust.id = lastOrder.cust_id
    LEFT JOIN (
        SELECT login.user_id, login.login_time, login.login_ip
        FROM `user_login_timetracker` login
        INNER JOIN (
            SELECT user_id, MAX(login_time) as latest_login
            FROM `user_login_timetracker`
            GROUP BY user_id
        ) latestLogin ON login.user_id = latestLogin.user_id AND login.login_time = latestLogin.latest_login
    ) login ON cust.user_id = login.user_id";

//$primaryKey = 'cust.id';


$primaryKey = 'cust.id';

$whereAll = array('cust.status = 5'); // Condition array
$whereClause = implode(' AND ', $whereAll); // Convert to string

$query = "SELECT * FROM $table";
if (!empty($whereClause)) {
    $query .= " WHERE $whereClause";
}

//echo $query;

$result = $conn->query($query);

// Check query result
if ($result->num_rows > 0) {
    // Open output stream
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename="disabledcustomers_data.csv"');

    $output = fopen('php://output', 'w');

    // Fetch and write the header row
    $header = array_keys($result->fetch_assoc());
    fputcsv($output, $header);

    // Write data rows
    $result->data_seek(0); // Reset result pointer
    while ($row = $result->fetch_assoc()) {
        fputcsv($output, $row);
    }

    fclose($output);
} else {
    echo "No data found.";
}

$conn->close();
?>
