<?php

require_once($base.'class/DBController.php');



class AdditionalCustomerInfo {



    private $db_handle;



    function __construct() {

        $this->db_handle = new DBController();

    }



    function addCustInfo($insertValues) {

        error_log("addCustInfo => ".json_encode($insertValues));

        $query = "INSERT INTO addt_cust_info

                            (cust_id, primary_owner_id, sales_rep_id,

                             temp_id, special_note, sales_rep_note,

                             company_website, credit_ref, monthly_flyer,

                             freight_policy, ship_note, freight_paid,

                             follow_up_1, follow_up_2, follow_up_3, follow_up_4)

                      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        $paramTypes = "isssssssssssssss";



        return $this->db_handle->insert($query, $paramTypes, $insertValues);

//        return $this->db_handle->runBaseQuery($query);

    }
	
	/*function addCustInfo($insertValues) {
    $fields = []; // To store field names
    $placeholders = []; // To store placeholders
    $paramTypes = ''; // To store parameter types
    $values = []; // To store values

    // Define the mapping of fields and their data
    $fieldMapping = [
        "cust_id" => "i",
        "primary_owner_id" => "s",
        "sales_rep_id" => "s",
        "temp_id" => "s",
        "special_note" => "s",
        "sales_rep_note" => "s",
        "company_website" => "s",
        "credit_ref" => "s",
        "monthly_flyer" => "s",
        "freight_policy" => "s",
        "ship_note" => "s",
        "freight_paid" => "s",
        "follow_up_1" => "s",
        "follow_up_2" => "s",
        "follow_up_3" => "s",
        "follow_up_4" => "s"
    ];

    // Dynamically build the query
    foreach ($fieldMapping as $field => $type) {
        if (!empty($insertValues[$field])) { // Include only non-empty fields
            $fields[] = $field;
            $placeholders[] = '?';
            $paramTypes .= $type;
            $values[] = $insertValues[$field];
        }
    }

    // Build the final query
    $query = "INSERT INTO addt_cust_info (" . implode(", ", $fields) . ") ";
    $query .= "VALUES (" . implode(", ", $placeholders) . ")";

    // Execute the query
    return $this->db_handle->insert($query, $paramTypes, $values);
}
*/



    function upsertCustInfo($custId, array $updatingDetails){

        $wheres = ["cust_id" =>(int) $custId];

        error_log("upsertCustInfo => ".json_encode($updatingDetails));

        error_log("upsertCustInfo = custId => ".$this->hasAlreadyAddtCustInfo($custId));

        if($this->hasAlreadyAddtCustInfo($custId)){

            return $this->baseUpdate($updatingDetails, $wheres);

        }



        $insertValue = array();

        $insertValue[0] = $custId;

        

        foreach ($updatingDetails as $insertToValue) {

            $insertToValue = $insertToValue == '' ? null : $insertToValue;

            $insertValue[] = $insertToValue;

        }

        

        return $this->addCustInfo($insertValue);

        

    }



    function getLastLoginDetails($userId){

        $query  = "SELECT inet_ntoa(login_ip)ip, login_time  FROM user_login_timetracker WHERE user_id = ? ORDER BY login_time DESC LIMIT 1";

        $paramType = "s";

        $paramValue = [$userId];



        return $this->db_handle->runQuery($query, $paramType, $paramValue);

    }

    

    function hasAlreadyAddtCustInfo($custId){

        $query  = "SELECT id FROM addt_cust_info WHERE cust_id = ? ";

        $paramType = "i";

        $paramValue = [$custId];

        

        return $this->db_handle->runQuery($query, $paramType, $paramValue);

    }



    /*public function getAdditionInfosByCustId($custId) {

        $query = "SELECT * FROM addt_cust_info WHERE cust_id = ?";

        $paramType = "i";

        $paramValue = [$custId];



        return $this->db_handle->runQuery($query, $paramType, $paramValue);

    }*/
	
	public function getAdditionInfosByCustId($custId) { 
    $query = "SELECT * FROM addt_cust_info WHERE cust_id = ?";
    $paramType = "s";
    $paramValue = [$custId];

    return $this->db_handle->runQuery($query, $paramType, $paramValue);
}



    public function addNotes($id, $note, $noteTypeColName){

        $addNotes = [$noteTypeColName=>$note];

        $this->editBasicCustomerInfo($id, $addNotes);

    }



    function editBasicCustomerInfo($whichCustomerId, array $editedInfo){

        $whichCustomer_Array = ["id" => $whichCustomerId];

        $this->baseUpdate($editedInfo, $whichCustomer_Array);

    }



    private function baseUpdate(array $updatingValues, array $wheres){

        return $this->db_handle->baseUpdate(ADDT_CUST_INFO,$updatingValues, $wheres);

    }

}