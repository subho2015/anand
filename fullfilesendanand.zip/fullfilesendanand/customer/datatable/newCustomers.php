<?php



// DB table to use

require_once '../../datatableUtils/DBTablesConst.php';



$table = "`" . CUSTOMERS . "` cust

    LEFT JOIN `" . BILLING_ADDS . "` billAdd ON cust.user_id = billAdd.user_id";



$primaryKey = 'cust.id';



require '../../datatableUtils/config.php';



$columns = [

    ['db' => 'cust.user_id', 'dt' => 'DT_RowId'],

    ['db' => '(cust.id)cust_id'],

    ['db' => 'provisional_cus_id'],

    ['db' => 'last_name'],

    ['db' => 'email'],

    ['db' => 'telephone'],

    ['db' => 'cus_fax_number'],

    [

        'db' => 'first_name',

        'dt' => 'customer',

        'formatter' => function ($d, $row) {

            return "<h6 class='bold text-dark no-margin'>" . $d . " " . $row['last_name'] . "</h6><i class='fa fa-at p-r-5 p-l-5'></i><a href='mailto:" . $row['email'] . "' class='text-black-50'>" . $row['email'] . "</a><br><i class='fa fa-phone p-l-5 p-r-5'></i><a href='tel:" . $row['telephone'] . "' class='text-black-50'>" . $row['telephone'] . "</a><br><i class='fa fa-fax p-l-5 p-r-5'></i><a href='fax:" . $row['cus_fax_number'] . "' class='text-black-50'>" . $row['cus_fax_number'] . "</a>";

        }

    ],

    [

        'db' => 'business_name',

        'dt' => 'business',

        'formatter' => function ($d, $row) {

            return "<h6 class='bold text-dark no-margin'>" . $d . "</h6><span class='text-black-50'>(" . $row['business_type'] . ")</span>";

        }

    ],

    ['db' => 'business_type'],

    ['db' => 'billAdd.*',

        'dt' => 'billing_address',

        'formatter' => function ($d, $row) {

            return $row['usr_address1'] . "," . $row['usr_address2'] . "<br>" . $row['city'] . "&nbsp;" . $row['zipcode'] . "<br>" . $row['state'] . ", " . $row['country'];

        }

    ],

    ['db' => 'resale_no', 'dt' => 'resale_no'],

    [

        'db' => 'created',

        'dt' => 'created',

        'formatter' => function ($d, $row) {

            return date('M j, Y, g:i a', strtotime($d)) . "<br><h6 class='bold hint-text'>" . $row['provisional_cus_id'] . "</h6>";

        }

    ],

    [

        'db' => 'cust.status',

        'dt' => 'status',

        'formatter' => function ($d, $row) {

            $approvedCust = '<button class="btn btn-primary approve-user" data-toggle="modal" data-target="#approveCustomerModel" data-id="' . $row['cust_id'] . '"><i data-feather="user-check"></i>Approve</button>';

            $rejectCust = '<button class="m-t-10 btn btn-link text-primary reject-user" data-id="' . $row['cust_id'] . '" onclick="rejectCustomer(this);"><i data-feather="user-x"></i>Reject It</button>';

            return $approvedCust . '<br>' . $rejectCust;

        }

    ]

];



$whereAll = array('cust.status = 3');



// Include SQL query processing class

require '../../datatableUtils/ssp.class.php';



// Output data as json format

echo json_encode(SSP::complex($_GET, $sql_details, $table, $primaryKey, $columns, $whereAll));