<?php



/**

 * activated_on [+ hawk_customer_id] ©

 * user_id [DT_RowId] ©

 * user_type ©

 * customer [first_name + last_name] + contact details [email + phone + fax] ©

 * business [name + type + resale no] ©

 * special_note ©

 * last_invoice [ date + amount + download link] ©

 * last_login [login_ip + moments(login_time)]

 * actions1

 *      1. more infos

 * actions2

 *      2. reset password

 *      3. disable

 */

// DB table to use

//if($_SERVER['REQUEST_METHOD'] === 'POST') {



require_once '../../datatableUtils/DBTablesConst.php';



/*$table = "`" . CUSTOMERS . "` cust

    LEFT JOIN `" . ADDT_CUST_INFO . "` add_cust ON cust.id = add_cust.cust_id

    LEFT JOIN (SELECT cust_id, invoice_no, final_amt,updated_at, ord_status FROM`" . ORDER_DETAILS . "` WHERE ord_status > 4 ORDER BY updated_at DESC LIMIT 1) lastOrder ON cust.id = lastOrder.cust_id 

    LEFT JOIN (SELECT * FROM`" . LOGIN_TRACKER . "` ORDER BY login_time DESC LIMIT 1) login ON cust.user_id = login.user_id";*/

/*$table = "`" . CUSTOMERS . "` cust
    LEFT JOIN `" . ADDT_CUST_INFO . "` add_cust ON cust.id = add_cust.cust_id
    LEFT JOIN (
    SELECT cust_id, invoice_no, final_amt, updated_at, ord_status
    FROM `trn_ord_hd`
    WHERE ord_status > 4
    AND (cust_id, updated_at) IN (
        SELECT cust_id, MAX(updated_at)
        FROM `trn_ord_hd`
        WHERE ord_status > 4
        GROUP BY cust_id
    )
) lastOrder ON cust.id = lastOrder.cust_id
	
    LEFT JOIN (
        SELECT login.user_id, login.login_time, login.login_ip
        FROM `" . LOGIN_TRACKER . "` login
        INNER JOIN (
            SELECT user_id, MAX(login_time) as latest_login
            FROM `" . LOGIN_TRACKER . "` 
            GROUP BY user_id
        ) latestLogin ON login.user_id = latestLogin.user_id AND login.login_time = latestLogin.latest_login
    ) login ON cust.user_id = login.user_id";

$primaryKey = 'cust.id';*/

$table = "`" . CUSTOMERS . "` cust
    LEFT JOIN `" . ADDT_CUST_INFO . "` add_cust ON cust.id = add_cust.cust_id
    LEFT JOIN (
        SELECT ord1.cust_id, ord1.invoice_no, ord1.final_amt, ord1.updated_at, ord1.ord_status
        FROM `trn_ord_hd` ord1
        INNER JOIN (
            SELECT cust_id, MAX(updated_at) as latest_updated
            FROM `trn_ord_hd`
            WHERE ord_status > 4
            GROUP BY cust_id
        ) ord2 ON ord1.cust_id = ord2.cust_id AND ord1.updated_at = ord2.latest_updated
        WHERE ord1.ord_status > 4
    ) lastOrder ON cust.id = lastOrder.cust_id
    LEFT JOIN (
        SELECT login.user_id, login.login_time, login.login_ip
        FROM `" . LOGIN_TRACKER . "` login
        INNER JOIN (
            SELECT user_id, MAX(login_time) as latest_login
            FROM `" . LOGIN_TRACKER . "`
            GROUP BY user_id
        ) latestLogin ON login.user_id = latestLogin.user_id AND login.login_time = latestLogin.latest_login
    ) login ON cust.user_id = login.user_id";

$primaryKey = 'cust.id';





require '../../datatableUtils/config.php';



$columns = [

    ['db' => 'cust.user_id', 'dt' => 'DT_RowId'],

    ['db' => $primaryKey],
    [
        'db' => 'activated_on',
        'dt' => 'activated_on',
        'formatter' => function ($d, $row) {
            $customerId = empty($row['hawk_customer_id']) ? $row['provisional_cus_id'] : $row['hawk_customer_id'];
            return date('M j, Y, g:i a', strtotime($d)) . "<br><h5 class='text-monospace bold text-black-50'>" . $customerId . "</h5>";
        }
    ],
    [
        'db' => 'user_type',
        'dt' => 'user_type',
        'formatter' => function ($d, $row) {
            return "<h6 class='text-" . $d . " text-uppercase'>" . $d . "</h6>";
        }
    ],
    ['db' => 'rejected_disabled_reason', 'dt' => 'rejected_disabled_reason'],
    ['db' => 'provisional_cus_id'],
    ['db' => 'last_name'],
    ['db' => 'email'],
    ['db' => 'telephone'],
    ['db' => 'cus_fax_number'],
    [
        'db' => 'first_name',
        'dt' => 'customer',
        'formatter' => function ($d, $row) {
            return "<h6 class='bold text-dark no-margin'>" . $d . " " . $row['last_name'] . "</h6><i class='fa fa-at p-r-5 p-l-5'></i><a href='mailto:" . $row['email'] . "' class='text-black-50'>" . $row['email'] . "</a><br><i class='fa fa-phone p-l-5 p-r-5'></i><a href='tel:" . $row['telephone'] . "' class='text-black-50'>" . $row['telephone'] . "</a><br><i class='fa fa-fax p-l-5 p-r-5'></i><a href='fax:" . $row['cus_fax_number'] . "' class='text-black-50'>" . $row['cus_fax_number'] . "</a>";
        }
    ],
    [
        'db' => 'business_name',
        'dt' => 'business',
        'formatter' => function ($d, $row) {
            return "<h6 class='bold text-dark no-margin'>" . $d . "</h6><span class='text-black-50'>(" . $row['business_type'] . ")</span><br>" . $row['resale_no'];
        }
    ],

    ['db' => 'lastOrder.invoice_no'],
    ['db' => 'lastOrder.updated_at'],
    ['db' => 'lastOrder.final_amt'],
    [
        'db' => 'resale_no',
        'dt' => 'last_invoice',
        'formatter' => function ($d, $row) {
            $invoice_details = !empty($row['invoice_no']) ?
                date('M j, Y, g:i a', strtotime($row['updated_at'])) . "" . $row['invoice_no'] . "</h6><p class='text-monospace hint-text'>$" . $row['final_amt'] . "</p>"
                : 'No Invoice';
            return $invoice_details;
        }
    ],
    ['db' => 'login.login_time'],
    ['db' => 'login.login_ip'],
	[
        'db' => 'business_type',
        'dt' => 'last_login',
        'formatter' => function ($d, $row) {
            $loginIp = $row['login_ip'];
            $loginMessage = empty($row['login_time']) ? 'Yet to Login' : inet_ntop($loginIp) . "<br><span><i class='fa fa-clock-o'></i>" . date('M j, Y, g:i a', strtotime($row['login_time'])) . "</span>";
            return $loginMessage;
        }
    ],
    [

        'db' => 'hawk_customer_id',
        'dt' => 'actions',
        'formatter' => function ($d, $row) {
            $custMoreInfo = "<button class='btn btn-info more-user' data-toggle='modal' data-target='#additionCustomerInfoModel' data-id='" . $row['id'] . "'><i class='fa fa-info-circle p-r-5'></i>More</button>";
            $reactivateCustomer = "<button class='m-t-10 btn btn-link text-success reactivate-user'  data-id='" . $row['id'] . "' onclick='reactivateCustomer(this);'><i class='fa fa-user-md p-r-5'></i>Reactivate</button>";
            $deleteCustomer = "<button class='m-t-10 btn btn-link text-danger delete-user'  data-id='" . $row['id'] . "' onclick='deleteCustomer(this);'><i class='fa fa-user-times p-r-5'></i>Delete</button>";
            return "$custMoreInfo<br>$reactivateCustomer<br>$deleteCustomer";
        }
    ]
];
$whereAll = array('cust.status = 5');
// Include SQL query processing class
require '../../datatableUtils/ssp.class.php';
// Output data as json format
echo json_encode(SSP::complex($_POST, $sql_details, $table, $primaryKey, $columns, $whereAll));
//} else die("No Place for this request");