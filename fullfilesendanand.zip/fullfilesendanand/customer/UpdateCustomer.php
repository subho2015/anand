<?php $base = '../';

$title = 'Update Customer';

$formInPage = true ?>
<?php include '../header.php'; ?>
<?php if (isset($_REQUEST['user_id'])) {

	$customerUserId = urldecode($_REQUEST['user_id']);



	require_once('class/Customer.php');

	require_once('class/AdditionalCustomerInfo.php');



	$customers = new Customer;

	$addCustomers = new AdditionalCustomerInfo;



	$myCustomer = ($customers->getCustomerInfoByUserId($customerUserId))[0];

	$custId = $myCustomer['id'];

	$userId = $myCustomer['user_id'];



	$billingAddress = ($customers->generateCustomersBillingAddress($userId))[0];

	$myCustomerAddtInfos = ($addCustomers->getAdditionInfosByCustId($custId))[0];

	?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <div class="pull-left">
          <ol class="breadcrumb p-0">
            <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
            <li class="breadcrumb-item"><a href="activeCustomers.php">Customer</a></li>
            <li class="breadcrumb-item active"><a

                                        href="#">
              <?= $myCustomer['first_name'] . " " . $myCustomer['last_name'] ?>
              </a> </li>
          </ol>
          
          <!-- END BREADCRUMB -->
          
          <h3 class="page-title text-primary"> <i class="fa fa-plus-square p-r-10" aria-hidden="true"></i> Update Customer </h3>
        </div>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container"> 
      <!-- START card -->
      
      <div class="row">
        <div class="col-md-9 offset-1 m-t-25 m-b-50">
          <form id="updateCustomer" role="form" action="CustomersAPI.php" method="post">
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Hawk Customer Id</label>
                        <input type="text" class="form-control" name="hawk_customer_id"

                                                           value="<?= $myCustomer['hawk_customer_id'] ?>">
                      </div>
                    </div>
                    <input type="hidden" name="customerId" value="<?= $myCustomer['id'] ?>">
                    <div class="col-md-5">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">First Name</label>
                        <input type="text" class="form-control" name="first_name"

                                                           value="<?= $myCustomer['first_name'] ?>" required>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Last Name</label>
                        <input type="text" class="form-control" name="last_name"

                                                           value="<?= $myCustomer['last_name'] ?>" required>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="label-sm">User Type</label>
                        <select class="full-width" data-init-plugin="select2"

                                                            name="user_type" required>
                          <?php

														$_userType = $myCustomer['user_type'];



														function selectedUserType($optionType, $userType) {

															return ($userType === $optionType) ? "selected" : "";

														} ?>
                          <option value="bronze" <?= selectedUserType("bronze", $_userType) ?> > Bronze </option>
                          <option value="silver" <?= selectedUserType("silver", $_userType) ?> > Silver </option>
                          <option value="gold" <?= selectedUserType("gold", $_userType) ?>> Gold </option>
                          <option value="platinum" <?= selectedUserType("platinum", $_userType) ?>> Platinum </option>
                          <option value="corporate" <?= selectedUserType("corporate", $_userType) ?>> Corporate </option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-5">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Primary Email</label>
                        <input type="text" class="form-control" name="email"

                                                           value="<?= $myCustomer['email'] ?>">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Phone No</label>
                        <input type="number" class="form-control" name="telephone"

                                                           value="<?= $myCustomer['telephone'] ?>">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group-attached">
                  <h6 class="p-t-10 text-primary">Business Details</h6>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Business Name</label>
                        <input type="text" class="form-control" name="business_name"

                                                           value="<?= $myCustomer['business_name'] ?>">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Fax No</label>
                        <input type="number" class="form-control" name="cus_fax_number"

                                                           value="<?= $myCustomer['cus_fax_number'] ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Business Type</label>
                        <select class="full-width" data-init-plugin="select2" name="business_type"

                                                            required>
                          <option>Catalog</option>
                          <option>Multi-Stores</option>
                          <option>Flea Market</option>
                          <option>Online</option>
                          <option>Closeout Company</option>
                          <option>Whole-seller</option>
                          <option>Others</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Business Category</label>
                        <select class="full-width" data-init-plugin="select2" name="business_category"

                                                            required>
                          <option>Jewelry and Craft Tools</option>
                          <option>Safety / Gloves / Rainwear</option>
                          <option>Automotive</option>
                          <option>General Merchandise</option>
                          <option>Government</option>
                          <option>Promotional Products</option>
                          <option>Others</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Resale Number</label>
                        <input type="text" class="form-control" name="resale_no"

                                                           value="<?= $myCustomer['resale_no'] ?>">
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Company Website</label>
                        <input type="text" class="form-control" name="company_website"

                                                           value="<?= $myCustomerAddtInfos['company_website'] ?>">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <h4 class="p-t-10 text-black-50 hint-text">Billing Address</h4>
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <input name="function" value="updateCustomerViaWebsite" hidden>
                  <div class="form-group form-group-default required">
                    <label class="label-sm">Billing Name</label>
                    <input type="text" class="form-control" name="name"

                                                   value="<?= $billingAddress['name'] ?>" required>
                  </div>
                  <input type="hidden" name="billingId" value="<?= $billingAddress['id'] ?>">
                  <div class="form-group form-group-default required">
                    <label class="label-sm">Address Line 1</label>
                    <input type="text" class="form-control" name="usr_address1"

                                                   value="<?= $billingAddress['usr_address1'] ?>" required>
                  </div>
                  <div class="form-group form-group-default">
                    <label class="label-sm">Address Line 2</label>
                    <input type="text" class="form-control" name="usr_address2"

                                                   value="<?= $billingAddress['usr_address2'] ?>">
                  </div>
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">City</label>
                        <input type="text" class="form-control" name="city"

                                                           value="<?= $billingAddress['city'] ?>" required>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">State</label>
                        <input type="text" class="form-control" name="state"

                                                           value="<?= $billingAddress['state'] ?>" required>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Country</label>
                        <input type="text" class="form-control" name="country"

                                                           value="<?= $billingAddress['country'] ?>" required>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Zipcode</label>
                        <input type="text" class="form-control" name="zipcode"

                                                           value="<?= $billingAddress['zipcode'] ?>" required>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <h4 class="p-t-10 text-black-50 hint-text">Additional Customer Info</h4>
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Primary Owner</label>
                        <input type="text" class="form-control" name="primary_owner_id"

                                                           value="<?= $myCustomerAddtInfos['primary_owner_id'] ?>">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Sales Rep</label>
                        <input type="text" class="form-control" name="sales_rep_id"

                                                           value="<?= $myCustomerAddtInfos['sales_rep_id'] ?>">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Temp</label>
                        <input type="text" class="form-control" name="temp_id"

                                                           value="<?= $myCustomerAddtInfos['temp_id'] ?>">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default p-b-10"

                                                     style="height: fit-content">
                        <label class="label-sm ">Special Note</label>
                        <textarea form="updateCustomer" type="text" class="form-control"

                                                              name="special_note" style="height: fit-content"

                                                              rows="3"><?= $myCustomerAddtInfos['special_note'] ?>
</textarea>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default p-b-10">
                        <label class="label-sm">Sales Rep Note</label>
                        <textarea form="updateCustomer" type="text" name="sales_rep_note"

                                                              rows="3" style="height: fit-content"

                                                              class="form-control"><?= $myCustomerAddtInfos['sales_rep_note'] ?>
</textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group form-group-default p-b-10">
                        <label class="label-sm ">Credit Ref.</label>
                        <textarea form="updateCustomer" type="text" class="form-control"

                                                              name="credit_ref" rows="3"

                                                              style="height: fit-content"><?= $myCustomerAddtInfos['credit_ref'] ?>
</textarea>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group form-group-default p-b-10">
                        <label class="label-sm">Shipping Note</label>
                        <textarea form="updateCustomer" type="text" name="ship_note"

                                                              rows="3" style="height: fit-content"

                                                              class="form-control"><?= $myCustomerAddtInfos['ship_note'] ?>
</textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Monthly Flyer</label>
                        <input type="text" class="form-control" name="monthly_flyer"

                                                           value="<?= $myCustomerAddtInfos['monthly_flyer'] ?>">
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Freight Policy</label>
                        <textarea form="updateCustomer" type="text" class="form-control"

                                                              name="freight_policy"><?= $myCustomerAddtInfos['freight_policy'] ?>
</textarea>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Freight Paid</label>
                        <input type="text" class="form-control" name="freight_paid"

                                                           value="<?= $myCustomerAddtInfos['freight_paid'] ?>">
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <h4 class="p-t-10 text-black-50 hint-text">Follow Up</h4>
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <div class="form-group form-group-default">
                    <label class="label-sm">Follow Up 1</label>
                    <textarea form="updateCustomer" type="text" name="follow_up_1"

                                                      rows="3" style="height: fit-content"

                                                      class="form-control"><?= $myCustomerAddtInfos['follow_up_1'] ?>
</textarea>
                  </div>
                  <div class="form-group form-group-default">
                    <label class="label-sm">Follow Up 2</label>
                    <textarea form="updateCustomer" type="text" name="follow_up_2"

                                                      rows="3" style="height: fit-content"

                                                      class="form-control"><?= $myCustomerAddtInfos['follow_up_2'] ?>
</textarea>
                  </div>
                  <div class="form-group form-group-default">
                    <label class="label-sm">Follow Up 3</label>
                    <textarea form="updateCustomer" type="text" name="follow_up_3"

                                                      rows="3" style="height: fit-content"

                                                      class="form-control"><?= $myCustomerAddtInfos['follow_up_3'] ?>
</textarea>
                  </div>
                  <div class="form-group form-group-default">
                    <label class="label-sm">Follow Up 4</label>
                    <textarea form="updateCustomer" type="text" name="follow_up_4"

                                                      rows="3" style="height: fit-content"

                                                      class="form-control"><?= $myCustomerAddtInfos['follow_up_4'] ?>
</textarea>
                  </div>
                </div>
              </div>
            </div>
            <div class="pull-right col-md-6 col-sm-12">
              <button class="btn btn-lg btn-block btn-complete" id="sumbitCustomerDetails"

                                        type="submit">Update Customer </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php } else { ?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="container">
      <h3 class="text-danger">ERROR : Need Customer Id</h3>
    </div>
  </div>
</div>
<?php } ?>
<?php include '../footer.php' ?>
<script>

        $(document).ready(function() {

            $('.autonumeric').autoNumeric('init');
			
			<?php

        if (isset($_GET['result'])) {

            if ($_GET['result'] === "success") {

        ?>



        $('.page-content-wrapper').pgNotification({

            style: 'bar',

            message: "Customer Updated",

            position: 'top',

            timeout: 0,

            type: "success",

        }).show();



        <?php }

        }

        ?>

        });

</script>