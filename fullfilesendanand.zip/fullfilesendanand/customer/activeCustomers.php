<?php 

$base = '../';

$title = 'Active | Customers' ?>
<?php include '../header.php' ?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
  <!-- START PAGE CONTENT -->
  <div class="content"> 
    <!-- START JUMBOTRON -->
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15">
        <div class="pull-left"> 
          <!-- START BREADCRUMB -->
          <ol class="breadcrumb p-0">
            <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
            <li class="breadcrumb-item active"><a href="activeCustomers.php">Customers</a></li>
          </ol>
          <!-- END BREADCRUMB -->
          <h3 class="page-title text-primary"> <i data-feather="box" aria-hidden="true"></i> Active Customers </h3>
        </div>
        <a href="AddNewCustomer.php" class="text-white pull-right px-5">
        <button class="btn btn-complete btn-lg"> <i class="fa fa-user-plus p-r-10" aria-hidden="true"></i> Add New Customer </button>
        </a> </div>
    </div>
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container-fluid"> 
      
      <!-- START card -->
      
      <div class="card card-default p-t-20">
        <div class="dt-buttons1">
          <button class="btn btn-primary btn-cons btn-animated from-top dt-button1 buttons-csv1 buttons-html51" 
            tabindex="0" 
            aria-controls="disabledCustomersTable" 
            type="button" 
            onclick="downloadCSV()"> <span>DOWNLOAD CSV</span><span class="hidden-block"> <i class="pg-icon">download_alt</i></span></button>
        </div>
        <table class="table table-hover nowrap" id="activeCustomersTable" cellspacing="0" width="100%">
          <thead class="card-body">
            <tr>
              <th scope="col"></th>
              <th scope="col" class="text-dark">Customer Id</th>
              <th scope="col" class="text-dark">Business</th>
              <th scope="col" class="text-dark">Contact Person</th>
              <th scope="col" class="text-dark">Last Login</th>
              <th scope="col" class="text-dark">Customer Type</th>
              <th scope="col" class="text-dark">Special Note</th>
              <th scope="col" class="text-dark">Last Invoice</th>
            </tr>
          </thead>
          <tfoot>
            <!--<tr>
            <th></th> 
            <th></th>
            <th></th> 
            <th></th> 
            <th></th> 
            <th></th> 
            <th></th> 
            <th></th>
        </tr>-->
          </tfoot>
        </table>
      </div>
      
      <!-- END card --> 
      
    </div>
    
    <!-- END CONTAINER FLUID -->
    
    <div class="modal fade slide-right" id="additionCustomerInfoModel" tabindex="-1" role="dialog" aria-labelledby="additionCustomerInfo"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="additionCustomer"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-up" id="additionCustomerEmailModel" tabindex="-1" role="dialog" aria-labelledby="additionCustomerEmail"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="additionalEmail"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
  </div>
  
  <!-- END PAGE CONTENT --> 
  
</div>

<!-- END PAGE CONTENT WRAPPER -->

<?php include '../footer.php' ?>
<script>
    function downloadCSV() {
        // Redirect to the PHP script to trigger the download
        window.location.href = 'activeuserdownload_csv.php';
    }
</script> 
<script src="js/customers.js" type="text/javascript"></script> 
<script>

    $(document).ready(function () {

        activeCustomersTable();

    });

</script> 
