<?php $base = '../'; $title = 'Inactive | Customers' ?>
<?php include '../header.php' ?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <ol class="breadcrumb p-0">
          <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
          <li class="breadcrumb-item active"><a href="activeCustomers.php">Customers</a></li>
        </ol>
        
        <!-- END BREADCRUMB -->
        
        <h3 class="page-title text-primary"><i data-feather="box" aria-hidden="true"></i> Inactive Customers</h3>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container-fluid"> 
      
      <!-- START card -->
      
      <div class="card card-default p-t-20">
        <div class="dt-buttons1">
    <button class="dt-button1 buttons-csv1 buttons-html51" 
            tabindex="0" 
            aria-controls="disabledCustomersTable" 
            type="button" 
            onclick="downloadCSV()">
        <span>CSV</span>
    </button>
</div>
        <table class="table table-hover nowrap" id="inactiveCustomersTable" cellspacing="0" width="100%">
          <thead class="card-body">
            <tr>
              <th></th>
              <th class="text-dark" style="letter-spacing: 0">Customer Id</th>
              <th class="text-dark" style="letter-spacing: 0">Business</th>
              <th class="text-dark" style="letter-spacing: 0">Contact Person</th>
              <th class="text-dark" style="letter-spacing: 0">Customer Type</th>
              <th class="text-dark" style="letter-spacing: 0">Last Invoice</th>
              <th class="text-dark" style="letter-spacing: 0">Last Login</th>
              <th class="text-dark" style="letter-spacing: 0">Disable Reason</th>
            </tr>
          </thead>
        </table>
      </div>
      
      <!-- END card --> 
      
    </div>
    
    <!-- END CONTAINER FLUID -->
    
    <div class="modal fade slide-right" id="additionCustomerInfoModel" tabindex="-1" role="dialog" aria-labelledby="additionCustomerInfo"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="additionCustomer"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-up" id="additionCustomerEmailModel" tabindex="-1" role="dialog" aria-labelledby="additionCustomerEmail"

             aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="additionalEmail"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
  </div>
  
  <!-- END PAGE CONTENT --> 
  
</div>

<!-- END PAGE CONTENT WRAPPER -->

<?php include '../footer.php' ?>
<script>
    function downloadCSV() {
        // Redirect to the PHP script to trigger the download
        window.location.href = 'inactiveuserdownload_csv.php';
    }
</script>
<script src="js/customers.js" type="text/javascript"></script> 
<script>

    $(document).ready(function () {

        inactiveCustomersTable();

    });

</script> 
