<?php $base = '../';

$title = '+ Product Varient';

$formInPage = true ?>
<?php include '../header.php';

//require_once '../categories/class/Category.php';

//require_once '../categories/class/SubSubCategory.php';

//require_once '../brands/class/Brands.php';



require_once 'class/Product.class.php';



$productsResult = new Product;

$products = $productsResult->getProducts();

print_r($productsResult);

/*$categories = new Category;

$subSubCategory = new SubSubCategory;

$brands = new Brands;*/

/*$product_query = "SELECT id, product_name FROM products"; // Adjust table/column names as per your DB
$product_result = mysqli_query($conn, $product_query);*/



?>
<div class="page-content-wrapper"> 
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <div class="pull-left">
          <ol class="breadcrumb p-0">
            <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
            <li class="breadcrumb-item active"><a href="product_varient.php">Products Varient</a></li>
          </ol>
          
          <!-- END BREADCRUMB -->
          
          <h3 class="page-title text-primary"><i class="fa fa-plus-square p-r-10" aria-hidden="true"></i> New Product Varient</h3>
        </div>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container"> 
      
      <!-- START card -->
      
      <div class="row">
        <div class="col-md-10 offset-1 m-t-25 m-b-50">
          <form id="addproductvarient" role="form" action="ProductsAPI.php" method="post">
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="hint-text label-sm">Product:</label>
                        <select name="product_id" required>
        <option value="">Select Product</option>
        <?php
        
        while ($row = $products->fetch_assoc()) { ?>
            <option value="<?php echo htmlspecialchars($row['id']); ?>">
                <?php echo htmlspecialchars($row['product_name']); ?>
            </option>
        <?php } ?>
    </select>
                      </div>
                    </div>
                    <div class="col-md-3">
                     <input type="text" name="size" placeholder="Enter Size (e.g., S, M, L, 32-inch)" required>
                    </div>
                    <div class="col-md-3">
                     <input type="text" name="color" placeholder="Enter Color (e.g., Red, Blue, Black)" required> 
                    </div>
                    <div class="col-md-3">
                      <input type="number" name="price" placeholder="Enter Price" required step="0.01" min="0.01">
                    </div>
                  </div>                 
                </div>                
              </div>
            </div>
            <button class="btn btn-lg btn-block btn-complete" id="addProduct" type="submit">Add Product</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include '../footer.php' ?>
<script>
$(document).ready(function () {
    <?php
    if (isset($_GET['result']) && $_GET['result'] === "success") {
        // Properly encode the message for safe JavaScript output
        $message = isset($_GET['message']) ? htmlspecialchars(str_replace("+", " ", $_GET['message'])) : "Product Varient Added Successfully";
		$formattedMessage1 = str_replace(["(", ")"], "", $message);
    ?>
        $('.page-content-wrapper').pgNotification({
            style: 'bar',
            message: '<?php echo $formattedMessage1; ?>',
            position: 'top',
            timeout: 0,
            type: "success",
        }).show();
    <?php
    }
    ?>
});
</script> 