<?php $base = '../';

$title = 'Edit Product';

$formInPage = true;

include '../header.php';



require_once '../categories/class/Category.php';

require_once '../categories/class/SubCategory.php';

require_once '../categories/class/SubSubCategory.php';

require_once '../brands/class/Brands.php';



require_once '../products/class/Product.class.php';



$productsClass = new Product;

$categories = new Category;

$subCategory = new SubCategory;

$subSubCategory = new SubSubCategory;

$brands = new Brands;



if (isset($_REQUEST['product_id'])) {

    echo $productId = (int)$_GET['product_id'];

    $productMoreInfoArray = ($productsClass->getProductMoreDetails($productId));



    $productMoreInfo = $productMoreInfoArray[0];

    ?>
    
<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
<?php
	 if (isset($_GET['result'])) {
		 
		 //echo $_GET['result'];
		 

            if ($_GET['result'] === "success") {
	?>
<div class="pgn-wrapper" data-position="top" style="top: 59px; margin:0 0 20px 0;"><div class="pgn push-on-sidebar-open pgn-bar"><div class="alert alert-success"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>Product Updated</div></div></div>
    <?php 
		   }
        }
        ?>      
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax" style="padding: 20px 0 0 0;">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
      
        
        <!-- START BREADCRUMB -->
        
        <div class="pull-left">
          <ol class="breadcrumb p-0">
            <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
            <li class="breadcrumb-item active"><a href="index.php">Products</a></li>
          </ol>
          
          <!-- END BREADCRUMB -->
          
          <h3 class="page-title text-primary"> <i class="fa fa-plus-square p-r-10" aria-hidden="true"></i>
            <?= htmlspecialchars($productMoreInfo['product_name']) ?>
          </h3>
        </div>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container-fluid"> 
    
      <!-- START card -->      
      <div class="row">
        <div class="col-md-10 offset-1 m-t-25 m-b-50">
          <form id="addNewProduct" role="form" action="ProductsAPI.php" method="post">
            <div class="card card-default">
              <div class="card-body">
                <div class="form-group-attached">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="hint-text label-sm">Category</label>
                        <select class="full-width" data-init-plugin="select2" name="category_id" id="category_id" required>
                          <optgroup label="Active">
                          <?php
								$categoryActiveList = $categories->getActiveCategoriesByOrder();
                                foreach ($categoryActiveList as $category) { ?>
                                <option value=<?php echo $category['id'];
                                        if ($category['id'] == htmlspecialchars($productMoreInfo['category_id'])) {
												echo " selected";
                                        } ?>>
                          <?= $category['category_name'] ?>
                          </option>
                          <?php } ?>
                          </optgroup>
                          <optgroup label="Inactive">
                          <?php

                                                            $categoryInactiveList = $categories->getInactiveCategoriesByOrder();

                                                            foreach ($categoryInactiveList as $category) { ?>
                          <option value=<?php echo $category['id'];

                                                                if ($category['id'] === htmlspecialchars($productMoreInfo['category_id'])) {

                                                                    echo " selected";

                                                                } ?>>
                          <?= $category['category_name'] ?>
                          </option>
                          <?php } ?>
                          </optgroup>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="hint-text label-sm">Sub-Category</label>
                        <select class="full-width" data-init-plugin="select2"

                                                            name="subCategory_id" id="subCategory_id">
                          <?php if (htmlspecialchars($productMoreInfo['subCategory_id'])) { ?>
                          <option value="<?= htmlspecialchars($productMoreInfo['subCategory_id']) ?>"

                                                                    selected>
                          <?= $subCategory->getSubCategoryNameById(htmlspecialchars($productMoreInfo['subCategory_id'])) ?>
                          </option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="hint-text label-sm">Sub-Sub Category</label>
                        <select class="full-width" data-init-plugin="select2"

                                                            name="subSubCategory_id" id="subSubCategory_id">
                          <?php if (htmlspecialchars($productMoreInfo['subSubCategory_id'])) { ?>
                          <option value="<?= htmlspecialchars($productMoreInfo['subSubCategory_id']) ?>"

                                                                    selected>
                          <?= $subSubCategory->getSubSubCategoryNameById(htmlspecialchars($productMoreInfo['subSubCategory_id'])) ?>
                          </option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="hint-text label-sm">Brand</label>
                        <select class="full-width" data-init-plugin="select2"

                                                            name="brands_id">
                          <option value="0">No Brand</option>
                          <?php

                                                        $brandsList = $brands->generateBrandsList();

                                                        foreach ($brandsList as $brand) {

                                                            ?>
                          <option value="<?= $brand['id'] ?>"

                                                                <?php if (htmlspecialchars($productMoreInfo['brands_id']) === $brand['id']) {

                                                                    echo "selected";

                                                                } ?>>
                          <?= $brand['brands_name'] ?>
                          </option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-8">
                      <input type="hidden" value="<?= $productId ?>" name="productId" hidden>
                      <div class="form-group form-group-default required">
                        <label class="label-lg">Product Name (Item Code)</label>
                        <input type="text" class="form-control input-lg" name="product_name"

                                                           value="<?= htmlspecialchars($productMoreInfo['product_name']) ?>"

                                                           required>
                      </div>
                    </div>
                    <div class="col-md-4">
                      <div class="form-group form-group-default">
                        <label class="label-lg">HSN Code</label>
                        <input type="text" class="form-control input-lg"

                                                           value="<?= htmlspecialchars($productMoreInfo['hsn_code']) ?>"

                                                           name="hsn_code">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Listing Order</label>
                        <input type="number" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['listing_order']) ?>"

                                                           name="listing_order">
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Country</label>
                        <input type="text" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['made_country']) ?>"

                                                           name="made_country">
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">In-Stock Quantity</label>
                        <div class="d-flex">
                          <input type="number" class="form-control"

                                                               value="<?= htmlspecialchars($productMoreInfo['stock_quan']) ?>"

                                                               name="stock_quan" required>
                          <div class="form-check form-check-inline switch complete">
                            <input type="checkbox" id="showQty"

                                                                   name="showQty" <?= $productMoreInfo['showQty'] ? 'checked' : '' ?>

                                                                   aria-invalid="false" value="Show Qty">
                            <label class="p-0" for="showQty"></label>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default required">
                        <label class="label-sm">Min. In-Stock</label>
                        <input type="number" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['min_stock_req']) ?>"

                                                           name="min_stock_req" required>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Group Code</label>
                        <input type="text" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['grp_code']) ?>"

                                                           name="grp_code">
                      </div>
                    </div>
                    <div class="col-md-9">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Short Description</label>
                        <input type="text" class="form-control"

                                                           value='<?= htmlspecialchars_decode($productMoreInfo['short_description']) ?>'

                                                           name="short_description">
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="form-group form-group-default">
                        <label class="label-sm">Product Specification PDF Link</label>
                        <input type="text" class="form-control"

                                                           value='<?= htmlspecialchars_decode($productMoreInfo['specification_link']) ?>'

                                                           name="specification_link">
                      </div>
                    </div>
                  </div>
                  <div class="form-group form-group-default p-b-10 required">
                    <label class="label-sm p-b-10">Full Description</label>
                    <div class="quill-wrapper">
                      <input type="text" name="full_description" id="full_description_input"

                                                       hidden>
                      <div id="editor">
                        <?= htmlspecialchars_decode($productMoreInfo['full_description'], ENT_NOQUOTES) ?>
                      </div>
                    </div>
                  </div>
                </div>
                <h5 class="m-t-20">Weight Table</h5>
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th scope="col"></th>
                      <th scope="col" class="text-center">Qty. in Pieces</th>
                      <th scope="col" class="text-center">Width</th>
                      <th scope="col" class="text-center">Length</th>
                      <th scope="col" class="text-center">Height</th>
                      <th scope="col" class="text-center">Weight</th>
                      <th scope="col" class="text-center">UPC</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row" class="align-middle">Individual</th>
                      <td class="padding-10"><div class="form-group required">
                          <input type="number" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['itm_no_of_pcs']) ?>"

                                                           name="itm_no_of_pcs"

                                                    >
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['itm_width']) ?>"

                                                           name="itm_width">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['itm_length']) ?>"

                                                           name="itm_length">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['itm_height']) ?>"

                                                           name="itm_height">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['itm_weight']) ?>"

                                                           name="itm_weight">
                          <div class="input-group-append "> <span class="input-group-text"> lb.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group">
                          <input type="text" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['itm_upc']) ?>"

                                                           name="itm_upc">
                        </div></td>
                    </tr>
                    <tr>
                      <th scope="row" class="align-middle">Inner</th>
                      <td class="padding-10"><div class="form-group required">
                          <input type="number" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_no_of_pcs']) ?>"

                                                           name="inr_no_of_pcs">
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_width']) ?>"

                                                           name="inr_width">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_height']) ?>"

                                                           name="inr_height">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_length']) ?>"

                                                           name="inr_length">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_weight']) ?>"

                                                           name="inr_weight">
                          <div class="input-group-append "> <span class="input-group-text"> lb.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group">
                          <input type="text" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_upc']) ?>"

                                                           name="inr_upc">
                        </div></td>
                    </tr>
                    <tr>
                      <th scope="row" class="align-middle">Case</th>
                      <td class="padding-10"><div class="form-group required">
                          <input type="number" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_no_of_pcs']) ?>"

                                                           name="case_no_of_pcs">
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_width']) ?>"

                                                           name="case_width">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_height']) ?>"

                                                           name="case_height">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_length']) ?>"

                                                           name="case_length">
                          <div class="input-group-append "> <span class="input-group-text"> In.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_weight']) ?>"

                                                           name="case_weight">
                          <div class="input-group-append "> <span class="input-group-text"> lb.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group">
                          <input type="text" class="form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_upc']) ?>"

                                                           name="case_upc">
                        </div></td>
                    </tr>
                  </tbody>
                </table>
                <h5 class="m-t-20">Internal Notes</h5>
                <div class="card card-default">
                  <div class="card-body">
                    <div class="form-group-attached">
                      <div class="form-group form-group-default">
                        <textarea form="addNewProduct" type="text" name="internal_notes"

                                                          rows="3" style="height: fit-content"

                                                          class="form-control"><?= htmlspecialchars($productMoreInfo['internal_notes']) ?>
</textarea>
                      </div>
                    </div>
                  </div>
                </div>
                <input value="editProduct" name="function" hidden>
                <h5 class="m-t-20">Pricing</h5>
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th scope="col"></th>
                      <th scope="col" class="text-center bg-bronze-lighter">Bronze</th>
                      <th scope="col" class="text-center bg-silver-lighter">Silver</th>
                      <th scope="col" class="text-center bg-gold-lighter">Gold</th>
                      <th scope="col" class="text-center bg-platinum-light">Platinum</th>
                      <th scope="col" class="text-center">Offer Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row" class="align-middle">Inner</th>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_bronze_price']) ?>"

                                                           name="inr_bronze_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_silver_price']) ?>"

                                                           name="inr_silver_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_gold_price']) ?>"

                                                           name="inr_gold_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_platinum_price']) ?>"

                                                           name="inr_platinum_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['inr_offer_price']) ?>"

                                                           name="inr_offer_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                    </tr>
                    <tr>
                      <th scope="row" class="align-middle">Case</th>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_bronze_price']) ?>"

                                                           name="case_bronze_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_silver_price']) ?>"

                                                           name="case_silver_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_gold_price']) ?>"

                                                           name="case_gold_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_platinum_price']) ?>"

                                                           name="case_platinum_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                      <td class="padding-10"><div class="form-group input-group">
                          <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control"

                                                           value="<?= htmlspecialchars($productMoreInfo['case_offer_price']) ?>"

                                                           name="case_offer_price">
                          <div class="input-group-append "> <span class="input-group-text"> per pc.</span> </div>
                        </div></td>
                    </tr>
                  </tbody>
                </table>
                <h5 class="m-t-20">Offers</h5>
                <div class="form-group-attached">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <div class="form-check form-check-inline switch switch-lg complete">
                          <input type="checkbox"

                                                               id="newArrival" <?= $productMoreInfo['offer_new_arrival'] ? 'checked' : '' ?>

                                                               name="offer_new_arrival" aria-invalid="false">
                          <label for="newArrival" class="text-capitalize"> New Arrival </label>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <div class="form-check form-check-inline switch switch-lg complete ">
                          <input type="checkbox"

                                                               id="weeklySpecial" <?= $productMoreInfo['offer_weekly_special'] ? 'checked' : '' ?>

                                                               name="offer_weekly_special" aria-invalid="false">
                          <label for="weeklySpecial" class="text-capitalize"> Weekly Special </label>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <div class="form-check form-check-inline switch switch-lg complete">
                          <input type="checkbox"

                                                               id="monthlyFlyer" <?= $productMoreInfo['offer_monthly_flyer'] ? 'checked' : '' ?>

                                                               name="offer_monthly_flyer" aria-invalid="false">
                          <label for="monthlyFlyer" class="text-capitalize"> Monthly Flyer </label>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="form-group form-group-default">
                        <div class="form-check form-check-inline switch switch-lg complete">
                          <input type="checkbox" id="closeouts"

                                                               name="offer_closeout" <?= $productMoreInfo['offer_closeout'] ? 'checked' : '' ?>

                                                               aria-invalid="false">
                          <label for="closeouts" class="text-capitalize">Closeout</label>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <h5 class="m-t-20">Product Image</h5>
                <div class="form-group input-group">
                  <div class="input-group-prepend"> <span class="input-group-text info"> <i class="pg-icon p-r-10" aria-hidden="true">picture</i> Featured </span> </div>
                  <input type="text" class="form-control"

                                               id="featuredImageURL"

                                               placeholder="image-file-name.jpg/png/*any"

                                               value="<?= htmlspecialchars($productMoreInfo['featured_image']) ?>"

                                               name="featured_image"

                                               required>
                  <div class="input-group-append">
                    <button class="btn btn-primary" type="button" onclick="loadFeaturedImage()"> <i class="pg-icon" aria-hidden="true">refresh</i> Load </button>
                  </div>
                </div>
                <div id="loadfeaturedImage"> </div>
                <div class="row">
                  <div class="col-md-6">
                    <div class="row">
                      <div class="form-group input-group required">
                        <div class="input-group-prepend"> <span class="input-group-text info"> <i class="pg-icon p-r-10" aria-hidden="true">picture</i> 1st </span> </div>
                        <input type="text" id="firstImageURL"

                                                           placeholder="image-file-name.jpg/png/*any"

                                                           value="<?= htmlspecialchars($productMoreInfo['pr_first_image']) ?>"

                                                           name="pr_first_image"

                                                           class="form-control">
                        <div class="input-group-append">
                          <button class="btn btn-primary" type="button"

                                                                onclick="load1stImage()"> <i class="pg-icon" aria-hidden="true">refresh</i> Load </button>
                        </div>
                      </div>
                      <div id="load1stImage"> </div>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group input-group required">
                      <div class="input-group-prepend"> <span class="input-group-text info"> <i class="pg-icon p-r-10" aria-hidden="true">picture</i> 2nd </span> </div>
                      <input type="text" id="secondImageURL"

                                                       placeholder="image-file-name.jpg/png/*any"

                                                       value="<?= htmlspecialchars($productMoreInfo['pr_second_image']) ?>"

                                                       name="pr_second_image"

                                                       class="form-control">
                      <div class="input-group-append">
                        <button class="btn btn-primary" type="button"

                                                            onclick="load2ndImage()"> <i class="pg-icon" aria-hidden="true">refresh</i> Load </button>
                      </div>
                    </div>
                    <div id="load2ndImage"> </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group input-group required">
                      <div class="input-group-prepend"> <span class="input-group-text info"> <i class="pg-icon p-r-10" aria-hidden="true">picture</i> 3rd </span> </div>
                      <input type="text" id="thirdImageURL"

                                                       placeholder="image-file-name.jpg/png/*any"

                                                       value="<?= htmlspecialchars($productMoreInfo['pr_third_image']) ?>"

                                                       name="pr_third_image"

                                                       class="form-control">
                      <div class="input-group-append">
                        <button class="btn btn-primary" type="button"

                                                            onclick="load3rdImage()"> <i class="pg-icon" aria-hidden="true">refresh</i> Load </button>
                      </div>
                    </div>
                    <div id="load3rdImage"></div>
                  </div>
                  <div class="col-md-6">
                    <div>
                      <div class="form-group form-group-default input-group required">
                        <div class="input-group-prepend"> <span class="input-group-text info"> <i class="pg-icon p-r-10" aria-hidden="true">picture</i> 4th </span> </div>
                        <input type="text" id="forthImageURL"

                                                           placeholder="image-file-name.jpg/png/*any"

                                                           value="<?= htmlspecialchars($productMoreInfo['pr_fourth_image']) ?>"

                                                           name="pr_fourth_image"

                                                           class="form-control">
                        <div class="input-group-append">
                          <button class="btn btn-primary" type="button"

                                                                onclick="load4thImage()"> <i class="pg-icon" aria-hidden="true">refresh</i> Load </button>
                        </div>
                      </div>
                      <div id="load4thImage"> </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <button class="btn btn-lg btn-block btn-complete" type="submit">Update Product</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<script>



        var toolbarOptions = [

            ['bold', 'italic', 'underline', 'strike'],        // toggled buttons

            ['blockquote'],



            [{'size': ['small', false, 'large', 'huge']}],  // custom dropdown

            [{'header': [1, 2, 3, 4, 5, 6, false]}],



            [{'list': 'ordered'}, {'list': 'bullet'}],

            [{'script': 'sub'}, {'script': 'super'}],      // superscript/subscript

            [{'indent': '-1'}, {'indent': '+1'}],          // outdent/indent



            [{'font': []}],

            [{'align': []}],



            ['clean']                                         // remove formatting button

        ];



        var quill = new Quill('#editor', {

            modules: {

                toolbar: toolbarOptions

            },

            placeholder: 'Type description...',

            theme: 'snow'

        });



        function updateHtmlOutput() {

            document.getElementById('full_description_input').value = getQuillHtml();

        }



        // Return the HTML content of the editor

        function getQuillHtml() {

            return quill.root.innerHTML;

        }





        $(document).ready(function () {

            $('.autonumeric').autoNumeric('init');

            $('#addNewProduct').validate();



            quill.on('text-change', function (delta, source) {

                updateHtmlOutput()

            });



            loadSubCategoryDropdown();

            loadSubSubCategoryDropdown();

            updateHtmlOutput();



            $("#category_id").on("change", function () {

                loadSubCategoryDropdown();

            });



            $("#subCategory_id").on("change", function () {

                loadSubSubCategoryDropdown();

            });

        });



        /*Featured Image*/

        const featuredImageDiv = document.getElementById('loadfeaturedImage');

        const featuredImageInputURL = document.getElementById('featuredImageURL');



        /*1st Image*/

        const _1stImageDiv = document.getElementById('load1stImage');

        const _1stImageInputURL = document.getElementById('firstImageURL');



        /*2nd Image*/

        const _2ndImageDiv = document.getElementById('load2ndImage');

        const _2ndImageInputURL = document.getElementById('secondImageURL');



        /*3rd Image*/

        const _3rdImageDiv = document.getElementById('load3rdImage');

        const _3rdImageInputURL = document.getElementById('thirdImageURL');



        /*4th Image*/

        const _4thImageDiv = document.getElementById('load4thImage');

        const _4thImageInputURL = document.getElementById('forthImageURL');



        function loadImage(imageDiv, imageURL) {

            if (imageURL.value != "") {

                let img;

                if (imageDiv.childNodes.length > 1) {

                    imageDiv.removeChild(imageDiv.childNodes[1]);

                }



                img = new Image();

                img.className = "img-thumbnail m-b-10";

                img.width = 200;

                img.src = "https://ewr1.vultrobjects.com/product-image/" + imageURL.value;

                imageDiv.appendChild(img);

            } else {

                return false;

            }

        }



        function load3rdImage() {

            loadImage(_3rdImageDiv, _3rdImageInputURL);

        }



        function load4thImage() {

            loadImage(_4thImageDiv, _4thImageInputURL);

        }



        function load2ndImage() {

            loadImage(_2ndImageDiv, _2ndImageInputURL);

        }



        function load1stImage() {

            loadImage(_1stImageDiv, _1stImageInputURL);

        }



        function loadFeaturedImage() {

            loadImage(featuredImageDiv, featuredImageInputURL);

        }



        function loadSubCategoryDropdown() {

            let categoryId = $('#category_id').val();



            $('#subCategory_id').select2({

                ajax: {

                    url: "formUtils/subCategoryDropdown.php",

                    data: function (params) {

                        var query = {

                            categoryId: categoryId

                        }

                        return query;

                    },

                    dataType: 'json'

                    // Additional AJAX parameters go here; see the end of this chapter for the full code of this example

                }

            });

        }



        function loadSubSubCategoryDropdown() {

            let subCategoryId = $('#subCategory_id').val();



            $('#subSubCategory_id').select2({

                ajax: {

                    url: "formUtils/subSubCategoryDropdown.php",

                    data: function (params) {

                        var query = {

                            subCategoryId: subCategoryId

                        }

                        return query;

                    },

                    dataType: 'json'

                    // Additional AJAX parameters go here; see the end of this chapter for the full code of this example

                }

            });

        }

        

    </script>
<?php }

include '../footer.php' ?>
