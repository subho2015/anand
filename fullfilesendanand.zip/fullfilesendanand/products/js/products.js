

function productsInfoProvider(dataURL, tableId) {

    return {

        processing: true,

        serverSide: true,

        scrollX: true,

        orderMulti: true,

        deferRender: true,

        order: [[2, 'asc'], [3, 'asc'], [4, 'asc'], [1, 'asc']],

        ajax: {

            url: dataURL,

            type: "POST"

        },

        rowGroup: {

            dataSrc: 'category'

        },

        columns: [

            {

                "orderable": false,

                "data": "actions",

                "defaultContent": ""

            },

            {"data": "listing_order", "orderable": true, "visible": false},

            {"data": "cat_order", "orderable": true, "visible": false},

            {"data": "cat_sub_sub_order", "orderable": true, "visible": false},

            {"data": "cat_sub_order", "orderable": true, "visible": false},



            {"data": "grp_code", "visible": false},

            {"data": "product_thumbnail", "orderable": false,},

            {"data": "productName_with_brandName_and_smallDesc"}, /* pr_name */

            {"data": "category", "visible": false},

            {"data": "categories", "orderData": [2, 3, 4]}, //for 0 use [0]

            {"data": "stocks"},

            {"data": "inr_bronze_price"},

            {"data": "inr_silver_price"},

            {"data": "inr_gold_price"},

            {"data": "inr_platinum_price"},

            {"data": "case_bronze_price"},

            {"data": "case_silver_price"},

            {"data": "case_gold_price"},

            {"data": "case_platinum_price"}

        ],

        "initComplete": function () {

            moreProductInfoAction(tableId);

            removeOfferAction();

        }

    };

}



function moreProductInfoAction(tableId) {

    $(tableId).on('click','button.more-details-products', function () {

        loadProductsAdditionalInfo($(this).data("id"));

    });

}



function removeOfferAction() {

    $('button.remove-offer').click(function () {

        removeOffer($(this).data("id"),$(this).data('action'));

    });

}



function loadProductsAdditionalInfo(id) {

    $.ajax({url: "../products/modal/productInfos.php?productId="+id, success: function(result){

            $("#productsMoreInfos").html(result);

        }});

}



function discontinueProduct(clickedProduct) {

    console.log("discontinueProduct called " + clickedProduct);

    var product = $(clickedProduct).data("id");

    //alert("discontinue");

    $.ajax({

        type: "POST",

        url: 'ProductsAPI.php',

        dataType: 'json',

        data: {

            function: 'disableProduct',

            productId: product,

        }

    }).done(function (response) {

        console.log(response);
		
		if (response.result) {
			//alert("deleted");
            // Success: Show notification and remove the row from DataTable
            $('.page-content-wrapper').pgNotification({
                style: 'bar',
                message: response.message || "Product discontinue successfully",  // Default message if none is provided
                position: 'top',
                timeout: 3000,
                type: "success",
            }).show();

            // Remove the deleted product row from DataTable
            var table1 = $("#productInStockTable").DataTable();
            table1.row($(clickedProduct).parents('tr')).remove().draw();
        } else {
            // If there's an issue, show a generic failure message
            $('.page-content-wrapper').pgNotification({
                style: 'bar',
                message: "Failed to delete product. Please try again.",
                position: 'top',
                timeout: 3000,
                type: "error",
            }).show();
        }

        /*var table1 = $("#productInStockTable").DataTable();

        table1.row( $(clickedProduct).parents('tr')).remove().draw();*/

    });

}



function deleteProduct(clickedProduct) {

    console.log("deleteProduct called " + clickedProduct);
    var product = $(clickedProduct).data("id");
     //alert("deleteproduct");	 //alert(product);

    $.ajax({
        type: "POST",
        url: 'ProductsAPI.php',
        dataType: 'json',
        data: {
            function: 'deleteProduct',
            productId: product,
        }
    })
	/*.done(function (response) {

        console.log(response);

        var table1 = $("#productInStockTable").DataTable();

        table1.row( $(clickedProduct).parents('tr')).remove().draw();

    });*/
	
	.done(function (response) {
        console.log(response);
        //alert("test");
		//alert(response.result);
        if (response.result) {
			//alert("deleted");
            // Success: Show notification and remove the row from DataTable
            $('.page-content-wrapper').pgNotification({
                style: 'bar',
                message: response.message || "Product deleted successfully",  // Default message if none is provided
                position: 'top',
                timeout: 3000,
                type: "success",
            }).show();

            // Remove the deleted product row from DataTable
            var table1 = $("#productInStockTable").DataTable();
            table1.row($(clickedProduct).parents('tr')).remove().draw();
        } else {
            // If there's an issue, show a generic failure message
            $('.page-content-wrapper').pgNotification({
                style: 'bar',
                message: "Failed to delete product. Please try again.",
                position: 'top',
                timeout: 3000,
                type: "error",
            }).show();
        }
    })
    .fail(function () {
        // AJAX call failure handling
        $('.page-content-wrapper').pgNotification({
            style: 'bar',
            message: "Error occurred while deleting the product.",
            position: 'top',
            timeout: 3000,
            type: "error",
        }).show();
    });

}



function continueProduct(clickedProduct) {

    var product = $(clickedProduct).data("id");

    //alert("continue product");

    $.ajax({

        type: "POST",

        url: 'ProductsAPI.php',

        dataType: 'json',

        data: {

            function: 'enableProduct',

            productId: product,

        }

    }).done(function (response) {

        console.log(response);

        /*var table1 = $("#productDiscontinueTable").DataTable();
        table1.row( $(clickedProduct).parents('tr')).remove().draw();*/
		if (response.result) {
			//alert("deleted");
            // Success: Show notification and remove the row from DataTable
            $('.page-content-wrapper').pgNotification({
                style: 'bar',
                message: response.message || "Product Continue successfully",  // Default message if none is provided
                position: 'top',
                timeout: 3000,
                type: "success",
            }).show();

            // Remove the deleted product row from DataTable
            var table1 = $("#productDiscontinueTable").DataTable();
            table1.row($(clickedProduct).parents('tr')).remove().draw();
        } else {
            // If there's an issue, show a generic failure message
            $('.page-content-wrapper').pgNotification({
                style: 'bar',
                message: "Failed to delete product. Please try again.",
                position: 'top',
                timeout: 3000,
                type: "error",
            }).show();
        }
		

    });

}