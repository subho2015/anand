<?php

define('PRODUCTS','products');

require_once($base . '/class/DBController.php');



class Product {



    private $db_handle;



    function __construct() {

        $this->db_handle = new DBController;

    }

    

    public function addProduct(array $insertValues) {



        $query = "INSERT INTO products (product_name, category_id, subCategory_id, subSubCategory_id, short_description, full_description, specification_link,

                      featured_image, brands_id, stock_quan, showQty, min_stock_req, itm_no_of_pcs, itm_width,

                      itm_length, itm_height, itm_weight, itm_upc, inr_no_of_pcs, inr_width, inr_height, inr_length,

                      inr_weight, inr_upc, case_no_of_pcs, case_width, case_height, case_length, case_weight, case_upc,

                      inr_bronze_price, inr_silver_price, inr_gold_price, inr_platinum_price, inr_offer_price,

                      case_bronze_price, case_silver_price, case_gold_price, case_platinum_price, case_offer_price,

                      made_country, hsn_code, grp_code, listing_order,

                      offer_monthly_flyer, offer_closeout, offer_weekly_special, offer_new_arrival,

                      pr_first_image, pr_second_image, pr_third_image, pr_fourth_image, internal_notes)

VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,

        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $paramTypes = "siiissssiiiiiddddsiddddsiddddsddddddddddsssiiiiisssss";

        return $this->db_handle->insert($query, $paramTypes, $insertValues);

    }



    public function editProduct(array $updatingValues, int $productId) {

        $where = ["id" => $productId];

        return $this->updateProduct($where, $updatingValues);

    }



    public function disableProduct($productId) {

        return $this->changeStatus($productId, false);

    }



    public function enableProduct($productId) {

        return $this->changeStatus($productId, true);

    }



    public function restockProduct($productId, $updatedQuantity) {

        $restockQuantity = ["stock_quan" => $updatedQuantity];

        $where = ["id" => $productId];

        return $this->updateProduct($where, $restockQuantity);

    }



    public function getProductMoreDetails(int $productId) {

        $query = "SELECT prod.*, brands.brands_name, cat.category_name, subCat.subCategory_name, subSubCat.subSubCategory_name FROM products prod LEFT JOIN product_categories cat on prod.category_id = cat.id LEFT JOIN product_subcategories subCat ON prod.subCategory_id = subCat.id LEFT JOIN product_subsubcategories subSubCat ON prod.subSubCategory_id = subSubCat.id LEFT JOIN product_brands brands on prod.brands_id = brands.id WHERE prod.id = ?";

         $paramType = "i";

         $paramValue = [$productId];

        return $this->db_handle->runQuery($query,$paramType, $paramValue);

    }
	
	// Get All Products
    public function getProducts() {
        return $this->db_handle->runQuery("SELECT id, product_name FROM products ORDER BY product_name ASC");
    }




    public function setFeaturedImage($imageVultrURL, $productId) {

        $restockQuantity = ["featured_image" => $imageVultrURL];

        $where = ["id" => $productId];

        $this->updateProduct($where, $restockQuantity);

    }



    private function changeStatus($productId, bool $changeStatusTo) {

        $query = "UPDATE products SET active = ? WHERE id = ?";

        $paramType = "ii";

        $paramValue = [$changeStatusTo, $productId];



        return $this->db_handle->update($query,  $paramType, $paramValue);

    }



    public function deleteProduct($productId){

        $query = "DELETE FROM products WHERE id = {$productId}";

//        $paramType = "i";

//        $paramValue = [$productId];



        return $this->db_handle->runBaseQuery($query);

    }



    /*public version is getting used in Offers Section*/

    public function updateProduct(array $wheres, array $updatingValues) {

        return $this->db_handle->baseUpdate(PRODUCTS, $updatingValues, $wheres);

    }



}