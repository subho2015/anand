<?php

$base = "../../";

require_once("../class/Product.class.php");

$productId = (int) $_REQUEST['productId'];

$products = new Product();

$productInfo = $products->getProductMoreDetails($productId);

if (!empty($productInfo)) {

    $productInfo = $productInfo[0];



?>

<div class="card">
  <div class="card-body">
    <div class="pull-left"> <span class="no-margin overline">
      <?= $productInfo['category_name'] ?>
      </span>&nbsp;>&nbsp; <span class="no-margin overline">
      <?= $productInfo['subCategory_name'] ?>
      </span>&nbsp;>&nbsp; <span class="no-margin overline">
      <?= $productInfo['subSubCategory_name'] ?>
      </span>
      <h4 class="no-margin">
        <?= $productInfo['product_name'] ?>
      </h4>
    </div>
    <div class="pull-right"> <img src="https://ewr1.vultrobjects.com/product-image/<?= $productInfo['featured_image'] ?>" class="img-thumbnail" width="80"> </div>
  </div>
</div>
<div class="card">
  <div class="card-header">
    <h5 class="card-title"> Product Description </h5>
  </div>
  <div class="card-body">
    <?= $productInfo['full_description'] ?>
  </div>
</div>
<?php if($productInfo['internal_notes']) { ?>
<div class="card bg-warning">
  <div class="card-header">
    <h5 class="card-title"> Internal Notes </h5>
  </div>
  <div class="card-body">
    <?= $productInfo['internal_notes'] ?>
  </div>
</div>
<?php } ?>
<h6 class="text-primary">Details</h6>
<div class="row p-t-0">
  <?php

    $businessFields = [

        "brands_name" => "Brand",

        "short_description" => "Short Description",

        "grp_code" => "Group Code",

        "stock_quan" => "Stock Quantity",

        "min_stock_req" => "Min Stock Qty.",

        "made_country" => "Country",

        "hsn_code" => "HSN Code",

    ];



    foreach ($businessFields as $dbKey => $fieldName) {

        if (!empty($productInfo[$dbKey]))

            echo "<div class='col-md-6'><h6 class='title pull-left overline m-b-0 hint-text'>$fieldName</h6><br><h5 class='pull-left m-b-15 m-t-0 text-dark'>$productInfo[$dbKey]</h5></div></br>";

    }

    ?>
</div>
<h6 class="text-primary">Weight Table</h6>
<div class="row p-t-0">
  <table class="table table-bordered">
    <thead>
      <tr>
        <th scope="col"></th>
        <th scope="col">No. of Pcs</th>
        <th scope="col">Width</th>
        <th scope="col">Length</th>
        <th scope="col">Height</th>
        <th scope="col">Weight</th>
        <th scope="col">UPC</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">Individual</th>
        <td><?= $productInfo['itm_no_of_pcs'] ?></td>
        <td><?= $productInfo['itm_width'] ?>
          in</td>
        <td><?= $productInfo['itm_length'] ?>
          in</td>
        <td><?= $productInfo['itm_height'] ?>
          in</td>
        <td><?= $productInfo['itm_weight'] ?>
          lb</td>
        <td><?= $productInfo['itm_upc'] ?></td>
      </tr>
      <tr>
        <th scope="row">Inner</th>
        <td><?= $productInfo['inr_no_of_pcs'] ?></td>
        <td><?= $productInfo['inr_width'] ?>
          in</td>
        <td><?= $productInfo['inr_height'] ?>
          in</td>
        <td><?= $productInfo['inr_length'] ?>
          in</td>
        <td><?= $productInfo['inr_weight'] ?>
          lb</td>
        <td><?= $productInfo['inr_upc'] ?></td>
      </tr>
      <tr>
        <th scope="row">Case</th>
        <td><?= $productInfo['case_no_of_pcs'] ?></td>
        <td><?= $productInfo['case_width'] ?>
          in</td>
        <td><?= $productInfo['case_height'] ?>
          in</td>
        <td><?= $productInfo['case_length'] ?>
          in</td>
        <td><?= $productInfo['case_weight'] ?>
          lb</td>
        <td><?= $productInfo['case_upc'] ?></td>
      </tr>
    </tbody>
  </table>
</div>
<h6 class="text-primary">Pricing</h6>
<div class="row p-t-0">
  <table class="table table-bordered">
    <thead>
      <tr>
        <th scope="col"></th>
        <th scope="col">Bronze</th>
        <th scope="col">Silver</th>
        <th scope="col">Gold</th>
        <th scope="col">Platinum</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">Inner</th>
        <td>$
          <?= $productInfo['inr_bronze_price'] ?></td>
        <td>$
          <?= $productInfo['inr_silver_price'] ?></td>
        <td>$
          <?= $productInfo['inr_gold_price'] ?></td>
        <td>$
          <?= $productInfo['inr_platinum_price'] ?></td>
      </tr>
      <tr>
        <th scope="row">Case</th>
        <td>$
          <?= $productInfo['case_bronze_price'] ?></td>
        <td>$
          <?= $productInfo['case_silver_price'] ?></td>
        <td>$
          <?= $productInfo['case_gold_price'] ?></td>
        <td>$
          <?= $productInfo['case_platinum_price'] ?></td>
      </tr>
    </tbody>
  </table>
</div>
<?php } else { ?>
<h3>Error in loading product Info.</h3>
<?php } ?>
