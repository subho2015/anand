<?php $base = '../';

$title = 'New | Products' ?>
<?php include '../header.php' ?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
    
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <div class="pull-left">
          <ol class="breadcrumb p-0">
            <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
            <li class="breadcrumb-item active"><a href="#">Products</a></li>
          </ol>
          
          <!-- END BREADCRUMB -->
          
          <h3 class="page-title text-primary"><i data-feather="box" aria-hidden="true"></i>In-Stocks</h3>
        </div>
        <a href="AddNewProduct.php" class="text-white">
        <button class="btn btn-complete btn-lg pull-right px-5"><i class="fa fa-plus-square p-r-10"

                                                                               aria-hidden="true"></i>Add New Product </button>
        </a> </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container-fluid"> 
      
      <!-- START card -->
      
      <div class="card card-transparent">
        <div class="dt-buttons1">
    <button class="dt-button1 buttons-csv1 buttons-html51" 
            tabindex="0" 
            aria-controls="disabledCustomersTable" 
            type="button" 
            onclick="downloadCSV()">
        <span>CSV</span>
    </button>
</div>
        <table class="table table-hover nowrap" id="productInStockTable" cellspacing="0" width="100%">
          <thead class="card-body">
            <tr>
              <th scope="col"></th>
              <th scope="col" colspan="10"></th>
              <th scope="col" colspan="4" class="text-dark text-center border-left border-right">Inner
                
                (Price) </th>
              <th scope="col" colspan="4" class="text-dark text-center border-right">Case (Price)</th>
            </tr>
            <tr>
              <th scope="col"></th>
              <!--More Details | Edit | Disable-->
              
              <th scope="col">Product Order</th>
              <th scope="col"></th>
              <th scope="col"></th>
              <th scope="col"></th>
              <th scope="col">Group Code</th>
              <th scope="col" class="text-dark">Featured Image</th>
              <!--Product Image-->
              
              <th scope="col" class="text-dark">Product Name (Item No.)</th>
              <th scope="col" class="text-dark">Category</th>
              <th scope="col" class="text-dark">Categories</th>
              
              <!--Category | Sub Category | Sub-Sub Category -->
              
              <th scope="col" class="text-dark">Qty (In-Stock)</th>
              <th scope="col" class="text-dark border-left">Bronze</th>
              <th scope="col" class="text-dark">Silver</th>
              <th scope="col" class="text-dark">Gold</th>
              <th scope="col" class="text-dark border-right">Platinum</th>
              <th scope="col" class="text-dark border-left">Bronze</th>
              <th scope="col" class="text-dark">Silver</th>
              <th scope="col" class="text-dark">Gold</th>
              <th scope="col" class="text-dark border-right">Platinum</th>
            </tr>
          </thead>
        </table>
      </div>
      
      <!-- END card --> 
      
    </div>
    
    <!-- END CONTAINER FLUID -->
    
    <div class="modal fade slide-right" id="productsMoreInfosModel" tabindex="-1" role="dialog"

             aria-labelledby="productsMoreInfos"

             aria-hidden="true">
      <div class="modal-dialog modal-lg w-100">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="productsMoreInfos"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
  </div>
  
  <!-- END PAGE CONTENT --> 
  
</div>

<!-- END PAGE CONTENT WRAPPER -->

<?php include '../footer.php' ?>
<script>
    function downloadCSV() {
        // Redirect to the PHP script to trigger the download
        window.location.href = 'instockproductdownload_csv.php';
    }
</script>
<script src="js/products.js"></script> 
<script src="js/productsTable.js"></script> 
<script>
    $(document).ready(function () {
        inStockTable();
    });
</script> 
