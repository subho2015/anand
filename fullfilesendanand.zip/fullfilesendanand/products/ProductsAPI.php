<?php

$base = "../";



// required headers

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

header("Access-Control-Allow-Methods: POST");



require_once('class/Product.class.php');



$products = new Product();



$method = $_SERVER['REQUEST_METHOD'];



if (isset($_REQUEST['function'])) {

    $functionName = $_REQUEST['function'];

}



if (isset($_REQUEST['productId'])) {

    $productId = $_REQUEST['productId'];

}

$result = "Failed";

$message = "Faced an issue, try later";



/**

 * addProduct

 * editProduct

 * disableProduct

 * enableProduct

 * restockProduct

 * getProductMoreDetails

 * setFeaturedImage

 * updateProduct

 * changeStatus

 */



if ($method === 'POST') {

    ob_start();

    $basicRequestData = [];



    $intFields = ['category_id', 'subCategory_id', 'subSubCategory_id' ];



    $doubleFields = ['itm_width', 'itm_length', 'itm_height', 'itm_weight',

        'inr_width', 'inr_height', 'inr_length', 'inr_weight',

        'case_width', 'case_height', 'case_length', 'case_weight',

        'inr_bronze_price', 'inr_silver_price', 'inr_gold_price', 'inr_platinum_price', 'inr_offer_price',

        'case_bronze_price', 'case_silver_price', 'case_gold_price', 'case_platinum_price', 'case_offer_price'];



    $booleanFields = ['showQty', 'offer_monthly_flyer', 'offer_closeout', 'offer_weekly_special', 'offer_new_arrival'];



    $basicFormKey = ['product_name', 'category_id', 'subCategory_id', 'subSubCategory_id',

        'short_description', 'full_description', 'specification_link', 'featured_image', 'brands_id',

        'stock_quan','showQty', 'min_stock_req',

        'itm_no_of_pcs', 'itm_width', 'itm_length', 'itm_height', 'itm_weight', 'itm_upc',

        'inr_no_of_pcs', 'inr_width', 'inr_height', 'inr_length', 'inr_weight', 'inr_upc',

        'case_no_of_pcs', 'case_width', 'case_height', 'case_length', 'case_weight', 'case_upc',

        'inr_bronze_price', 'inr_silver_price', 'inr_gold_price', 'inr_platinum_price', 'inr_offer_price',

        'case_bronze_price', 'case_silver_price', 'case_gold_price', 'case_platinum_price', 'case_offer_price',

        'made_country', 'hsn_code', 'grp_code', 'listing_order',

        'offer_monthly_flyer', 'offer_closeout', 'offer_weekly_special', 'offer_new_arrival',

        'pr_first_image', 'pr_second_image', 'pr_third_image', 'pr_fourth_image','internal_notes'

    ];



    switch ($functionName) {

        case "addProduct" :

            foreach ($basicFormKey as $formField) {
                $postValue = $_POST[$formField] ?? null;
                error_log("PostValue = 1". $postValue);

                if (in_array($formField, $doubleFields)) {
                    $postValue = str_replace(["$ ", ","], "", $postValue);
                    $postValue = (double)$postValue;
                }

                $postValue = empty($postValue) ? null : filter_var($postValue);
                error_log("PostValue = 2". $postValue);
                if (in_array($formField, $booleanFields)) {
                    $postValue = (int)!empty($postValue);
                }
                if (in_array($formField, $intFields)){
                    if(!$postValue){
                        $postValue = null;
                    }  
                }
                error_log("PostValue = 3". $postValue);
                $basicRequestData[$formField] = $postValue;
            }

            $prodId = $products->addProduct($basicRequestData);

            if (!empty($prodId)) {
                $result = "success";
                $message = "Product (" . $_POST['product_name'] . ") Created";
            } else {
                $result = "failed";
                $message = "Product not added properly";
            }

            header('Location:' . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=" . $result . "&message=" . urlencode($message));

            break;

        case "editProduct":

            foreach ($basicFormKey as $formField) {

                $postValue = $_POST[$formField] == '' ? null : ($_POST[$formField]);

                error_log($formField." = ".$postValue);

                if (in_array($formField, $doubleFields)) {

                    $postValue = str_replace(["$ ", ","], "", $postValue);

                    $postValue = (double)$postValue;

                }



                $postValue = filter_var($postValue);



                if (in_array($formField, $booleanFields)) {

                    $postValue = $postValue == '' ? false : 1;

                }



                if (in_array($formField, $intFields)){

                    if(!$postValue){

                        $postValue = 0;

                    }  

                }



                $basicRequestData[$formField] = $postValue;

            }



            $isProductUpdated = $products->editProduct($basicRequestData, $productId);



            if ($isProductUpdated) {

                $result = "success";

                $message = "Product Updated";

            } else {

                $result = "failed";

                $message = "Product not updated properly";

            }



            header('Location:' . $_SERVER["HTTP_REFERER"] . "&result=" . $result . "&message=" . urlencode($message));



            break;

        case "enableProduct":

            $activationResult = $products->enableProduct($productId);

            if ($activationResult >= 1) {

                $result = "Success";

                $message = "Product is live in website";

            } elseif ($activationResult == 0) {

                $result = "Warning";

                $message = "Nothing to change";

            } else {

                $result = "Failed";

                $message = "Error in activation";

            }

            echo json_encode(["result" => $result, "message" => $message]);



            break;

        case "disableProduct":

            $deactivationResult = $products->disableProduct($productId);

            if ($deactivationResult >= 1) {

                $result = "Success";

                $message = "Product has been disabled";

            } elseif ($deactivationResult == 0) {

                $result = "Warning";

                $message = "Nothing to change";

            } else {

                $result = "Failed";

                $message = "Error in deactivation";

            }

            echo json_encode(["result" => $result, "message" => $message]);



            break;

        case "restockProduct":

            $restockResult = $products->restockProduct($productId, $_POST['newQty']);

            if ($restockResult >= 1) {

                $result = "Success";

                $message = "Product has been restocked";

            } elseif ($restockResult == 0) {

                $result = "Warning";

                $message = "Nothing to change in stock";

            } else {

                $result = "Failed";

                $message = "Error in updating stocks";

            }

            echo json_encode(["result" => $result, "message" => $message]);



            break;

        /*case 'deleteProduct':

            $deleteResult = $products->deleteProduct($productId);

            error_log("Delete Result = " . $deleteResult);



            echo json_encode(["result" => true, "message" => $deleteResult]);*/
			
			case 'deleteProduct':
    $deleteResult = $products->deleteProduct($productId);
    //error_log("Delete Result = " . $deleteResult);

    // Return a JSON response with a success message
    echo json_encode(["result" => true, "message" => "Product deleted successfully"]);



        default:

            $result = "Failed";

            $message = "Not a valid function";

            header('Location:' . strtok($_SERVER["REQUEST_URI"], '?') . "?result=" . $result . "&message=" . urlencode($message));



    }

}