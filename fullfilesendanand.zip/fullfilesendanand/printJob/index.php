<?php



$base = "../";

$uploadInPage = true;

$formInPage = true;

$title = "Print";



include $base . 'header.php' ?>



<?php

include "class/PrintJob.class.php";

$printJob = new PrintJob();

?>



<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper">

  <!-- START PAGE CONTENT -->
  <?php
	 if (isset($_GET['result'])) {
		 
		 //echo $_GET['result'];
		 $message = $_GET['message'];

            if ($_GET['result'] === "success") {
				 $subCategory2 = str_replace(['(', ')'], '', $message);
	?>
<div class="pgn-wrapper" data-position="top" style="top: 59px; margin:0 0 20px 0;"><div class="pgn push-on-sidebar-open pgn-bar"><div class="alert alert-success"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button><?php echo $subCategory2; ?> Successfully</div></div></div>
    <?php 
		   }
        }
        ?>  

  <div class="content">

    <!-- START JUMBOTRON -->

    <div class="jumbotron" data-pages="parallax">

      <div class=" container-fluid container-fixed-lg sm-p-l-0 sm-p-r-0">

        <div class="inner">

          <!-- START BREADCRUMB -->

          <ol class="breadcrumb">

            <li class="breadcrumb-item"><a href="#">Hawk</a></li>

            <li class="breadcrumb-item active">Marketing</li>

            <li class="breadcrumb-item active">Print</li>

          </ol>

          <!-- END BREADCRUMB -->

          <h3 class="page-title text-primary">

            <i class="fa fa-plus-square p-r-10"></i>

            Import Print Jobs

          </h3>

        </div>



      </div>

    </div>

    <!-- END JUMBOTRON -->

    <!-- START CONTAINER FLUID -->

    <div class="container-fluid container-fixed-lg">

      <div class="row">

        <div class="col-md-6">

          <button class="btn btn-primary"

                  id="addNewJobTitleAction"

                  data-target='#addJobModal'

                  data-toggle='modal'>

            <i class="pg-icon">add</i>

            Add Job Title

          </button>

          <div class="card m-t-10">

            <div class="card-body">

              <div>

                <ol class="dd-list">

                  <?php $printJobs = $printJob->getJobs();



                  foreach ($printJobs as $jobDetails) {



                    $jobId = $jobDetails['id'];



                    ?>



                    <li class=" dd-item cursor category_li" data-cat="<?= $jobId ?>">

                      <div class="no-border">

                        <div class="d-flex align-items-center justify-content-between">

                          <Button data-job="<?= $jobId ?>" data-hawk="<?= $jobDetails['hawk_internal_title'] ?>"

                                  class="btn btn-danger mr-2 deleteAllItems" onclick="deletedThisPrintJobAction(event)">

                            -

                          </Button>

                          <div class="flex-grow-1">

                            <h6 class="flex-fill text-black" >

                              <?= $jobDetails['hawk_internal_title'] ?>

                            </h6>

                            <p class="flex-fill text-black">

                              <?= $jobDetails['job_title'] ?>

                            </p>

                            <small><?= $jobDetails['hawk_description'] ?></small>

                          </div>



                          <Button data-job="<?= $jobId ?>"

                                  class="btn btn-success ml-2 editJobAction"

                                  data-target='#editJobModal'

                                  data-toggle='modal'>

                            <i class="pg-icon">edit</i> EDIT

                          </Button>

                          <Button data-job="<?= $jobId ?>"



                                  class="btn btn-complete ml-2 printPreviewJob"

                                  data-target='#printPreviewModal'

                                  data-toggle='modal'>

                              <i class="pg-icon">printer</i> PRINT

                          </Button>

                          <form action="downloadPrintDetail.php" method="post">

                            <button class="btn btn-success pull-right"

                                    name="jobId" value="<?= $jobId ?>"

                                    id="editFullfilledQty" type="submit">

                              <i class="fa fa-download" aria-hidden="true"></i>

                              XLS

                            </button>

                          </form>

                          <Button data-job="<?= $jobId ?>"

                                  data-hawk="<?= $jobDetails['hawk_internal_title'] ?>"

                                  class="btn btn-danger ml-2 deleteAllItems" onclick="deleteItemsFromPrintJobAction(event)">

                            <i class="pg-icon">printer</i> Delete Items

                          </Button>

                        </div>

                      </div>

                    </li>

                    <hr style="margin: 0"/>

                  <?php } ?>

                </ol>

              </div>

            </div>

          </div>

        </div>

        <div class="col-md-6">

          <form action="../bulkUpload/file-upload.php" class="dropzone">

            <input name="function" value="printJobToDB" type="hidden" hidden>

            <div class="fallback">

              <input name="file" type="file"/>

            </div>

          </form>

        </div>

      </div>

    </div>

    <!-- END CONTAINER FLUID -->



    <div class="modal fade slide-top" id="editJobModal" tabindex="-1" role="dialog"

         aria-labelledby="updatePrintTitle" aria-hidden="true">

      <div class="modal-dialog modal-lg">

        <div class="modal-content-wrapper">

          <div class="modal-content table-block">

            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">

              <i class="pg-close fs-14" aria-hidden="true"></i>

            </button>

            <div class="modal-body v-align-top">

              <div id="updatePrintJobTitle"></div>

            </div>

          </div>

        </div>

        <!-- /.modal-content -->

      </div>

      <!-- /.modal-dialog -->

    </div>



    <div class="modal fade slide-top" id="addJobModal" tabindex="-1" role="dialog"

         aria-labelledby="addPrintTitle" aria-hidden="true">

      <div class="modal-dialog modal-lg">

        <div class="modal-content-wrapper">

          <div class="modal-content table-block">

            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">

              <i class="pg-close fs-14" aria-hidden="true"></i>

            </button>

            <div class="modal-body v-align-top">

              <div id="addPrintJobTitle"></div>

            </div>

          </div>

        </div>

        <!-- /.modal-content -->

      </div>

      <!-- /.modal-dialog -->

    </div>



    <div class="modal fade slide-top" id="printPreviewModal" tabindex="-1" role="dialog"

         aria-labelledby="previewPrintTitle" aria-hidden="true">

      <div class="modal-dialog modal-lg">

        <div class="modal-content-wrapper">

          <div class="modal-content table-block">

            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">

              <i class="pg-close fs-14" aria-hidden="true"></i>

            </button>

            <div class="modal-body v-align-top">

              <div id="previewPrintJob"></div>

            </div>

          </div>

        </div>

        <!-- /.modal-content -->

      </div>

      <!-- /.modal-dialog -->

    </div>



  </div>

  <!-- END PAGE CONTENT -->

</div>

<!-- END PAGE CONTENT WRAPPER -->

<script>

  $(document).ready(function () {

    updatePrintJobAction();

    addPrintJobTitleAction();

    previewPrintAction();

  });



  function updatePrintJobAction() {

    $('.editJobAction').click(function () {

      loadUpdatePrintJobModal($(this).attr('data-job'));

    });

  }



  function loadUpdatePrintJobModal(id) {

    console.log("loadUpdatePrintJobModal", id);

    $.ajax({

      url: "../printJob/modal/updateJobTitle.php?jobId=" + id, success: function (result) {

        $("#updatePrintJobTitle").html(result);

      }

    });

  }



  function addPrintJobTitleAction() {

    $('#addNewJobTitleAction').click(function () {

      loadAddJobTitleModal();

    })

  }



  function loadAddJobTitleModal() {

    console.log("loadAdd");

    $.ajax({

      url: "../printJob/modal/addJobTitle.php", success: function (result) {

        $("#addPrintJobTitle").html(result);

      }

    });

  }



  function previewPrintAction() {

    $('.printPreviewJob').click(function () {

      loadPreviewModal($(this).attr('data-job'));

    })

  }



  function loadPreviewModal(id) {

    console.log("loadPreviewModal");

    $.ajax({

      url: "../printJob/modal/printPreview.php?jobId=" + id, success: function (result) {

        $("#previewPrintJob").html(result);

      }

    });

  }



  function deletedThisPrintJobAction(event) {

    console.log("deletedThisPrintJobAction, event", event.target.dataset);



    const object =  event.target.dataset;



    const params = {

      function: "deleteThisPrintJob",

      jobId: object.job,

      hawk_internal_title: object.hawk

    };



    callAPI(params);

  }



  function deleteItemsFromPrintJobAction(event) {

    console.log("deleteItemsFromPrintJobAction, event", event.target.dataset);



    const object =  event.target.dataset;



    const params = {

      function: "deleteItemsFromThisJob",

      jobId: object.job,

      hawk_internal_title: object.hawk

    };



    callAPI(params);

  }





  function callAPI(params) {

    // console.log(params);

    $.ajax({

      type: "POST",

      url: 'printJobAPI.php',

      dataType: 'json',

      data: params

    }).done(function (result) {

      console.log(result);

      if (result.result === 'Success') {



        $('.page-content-wrapper').pgNotification({

          style: 'bar',

          message: result.message,

          position: 'top',

          timeout: 0,

          type: 'success'

        }).show();

      } else {

        $('.page-content-wrapper').pgNotification({

          style: 'bar',

          message: result.message,

          position: 'top',

          timeout: 0,

          type: 'danger'

        }).show();

      }



      setTimeout(handler => {

        window.location.reload();

      }, 1000);



    });

  }



</script>



<?php include $base . 'footer.php' ?>

