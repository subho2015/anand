<?php



$base = "../";



// required headers

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

header("Access-Control-Allow-Methods: GET,POST");



require_once('class/PrintJob.class.php');

$printJob = new PrintJob();



$method = $_SERVER['REQUEST_METHOD'];



if (isset($_REQUEST['function'])) {

    $functionName = $_REQUEST['function'];

}



if (isset($_REQUEST['jobId'])) {

    $jobId = $_REQUEST['jobId'];

}



if ($method === 'POST') {

    switch ($functionName) {



        case "addPrintJob":

            $hawkInternalTitle = filter_var($_POST['hawk_internal_title']);

            $jobTitle = filter_var($_POST['job_title']);

            $hawkDescription = filter_var($_POST['hawk_description']);



            $jobId = $printJob->addPrintJob($hawkInternalTitle, $jobTitle, $hawkDescription);



            if (!empty($jobId)) {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=success&message=" . urlencode("Job (" . $_POST['job_title'] . ") Added"));

            } else {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=failed&message=" . urlencode("Issue while adding"));

            }

            break;

        case "updatePrintJob":

            $jobTitle = filter_var($_POST['job_title']);

            $hawkDescription = filter_var($_POST['hawk_description']);



            $updateResult = $printJob->updatePrintJob($jobId, $jobTitle, $hawkDescription);

            if ($updateResult) {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=success&message=" . urlencode("Job (" . $_POST['job_title'] . ") Updated"));

            } else {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=failed&message=" . urlencode("Issue will updating, try again"));

            }

            break;



        case "deleteItemsFromThisJob":

            $hawkInternalTitle = filter_var($_POST['hawk_internal_title']);

            echo json_encode($printJob->deleteItemsFromPrintJob($jobId, $hawkInternalTitle));

            break;



        case "deleteThisPrintJob":

            $hawkInternalTitle = filter_var($_POST['hawk_internal_title']);

            echo json_encode($printJob->deleteThisPrintJob($jobId, $hawkInternalTitle));

            break;



    }

}