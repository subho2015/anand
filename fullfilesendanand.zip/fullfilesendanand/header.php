<?php

if (session_status() === PHP_SESSION_NONE) {

    session_start();

}

//$staffId = $_SESSION['staffId'];

if (isset($_SESSION['staffId'])) {
    $staffId = $_SESSION['staffId'];
}


// if (!$staffId) {

//     header("Location:https://".$_SERVER['HTTP_HOST']."/login.php?redirectUrl=".urlencode($_SERVER['PHP_SELF']));

// } else {

//     error_log("Session is running with " . $staffId);

// }



if (!empty($base)) {

    $base = $base === "./" ? "" : "../";

}



if (empty($formInPage)) {

    $formInPage = false;

}

$pluginPath = $base . "assets/plugins/";

?>

<!DOCTYPE html>

<html>

<head>

    <meta http-equiv="content-type" content="text/html;charset=UTF-8"/>

    <meta charset="utf-8"/>

    <title><?= $title . " | Hawk Importers Inc." ?></title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>

    <link rel="apple-touch-icon" href="<?= $base ?>pages/ico/60.png">

    <link rel="apple-touch-icon" sizes="76x76" href="<?= $base ?>pages/ico/76.png">

    <link rel="apple-touch-icon" sizes="120x120" href="<?= $base ?>pages/ico/120.png">

    <link rel="apple-touch-icon" sizes="152x152" href="<?= $base ?>pages/ico/152.png">

    <meta name="apple-mobile-web-app-capable" content="yes">

    <meta name="apple-touch-fullscreen" content="yes">

    <meta name="apple-mobile-web-app-status-bar-style" content="default">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <link href="<?= $pluginPath ?>pace/pace-theme-flash.css" rel="stylesheet" type="text/css"/>

    <link href="<?= $pluginPath ?>bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

    <link href="<?= $pluginPath ?>font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>

    <link href="<?= $pluginPath ?>jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"

          media="screen"/>

    <link href="<?= $pluginPath ?>jquery-datatable/media/css/dataTables.bootstrap.min.css" rel="stylesheet"

          type="text/css"/>

    <link href="<?= $pluginPath ?>jquery-datatable/extensions/FixedColumns/css/dataTables.fixedColumns.min.css"

          rel="stylesheet" type="text/css"/>

    <link href="<?= $pluginPath ?>datatables-responsive/css/datatables.responsive.css" rel="stylesheet" type="text/css"

          media="screen"/>

    <link href="<?= $pluginPath ?>jquery-nestable/jquery.nestable.css" rel="stylesheet" type="text/css" media="screen"/>

    <link class="main-stylesheet" href="<?= $base ?>pages/css/themes/unlax.css" rel="stylesheet" type="text/css"/>

    <!--<link rel="stylesheet" href="https://cdn.datatables.net/searchpanes/2.3.3/css/searchPanes.dataTables.css" />
<link rel="stylesheet" href="https://cdn.datatables.net/select/2.1.0/css/select.dataTables.css" />-->

    <!-- BEGIN VENDOR JS -->

    <script src="https://unpkg.com/feather-icons" type="text/javascript"></script>

    <!-- BEGIN VENDOR JS -->

    <script src="<?= $pluginPath ?>pace/pace.min.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery/jquery-3.2.1.min.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>modernizr.custom.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery-ui/jquery-ui.min.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>popper/umd/popper.min.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery/jquery-easy.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery-ios-list/jquery.ioslist.min.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery-actual/jquery.actual.min.js"></script>

    <script src="<?= $pluginPath ?>jquery-scrollbar/jquery.scrollbar.min.js"></script>

    <script src="<?= $pluginPath ?>jquery-datatable/media/js/jquery.dataTables.min.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery-datatable/extensions/TableTools/js/dataTables.tableTools.min.js"

            type="text/javascript"></script>

    <script src="https://cdn.datatables.net/rowgroup/1.1.2/js/dataTables.rowGroup.min.js"

            type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery-datatable/media/js/dataTables.bootstrap.js" type="text/javascript"></script>

    <script src="<?= $pluginPath ?>jquery-datatable/extensions/Bootstrap/jquery-datatable-bootstrap.js"

            type="text/javascript"></script>

    <script type="text/javascript" src="<?= $pluginPath ?>datatables-responsive/js/datatables.responsive.js"></script>

    <script type="text/javascript" src="<?= $pluginPath ?>datatables-responsive/js/lodash.min.js"></script>

    <script src="<?= $pluginPath ?>jquery-nestable/jquery.nestable.js" type="text/javascript"></script>
    <!--<script src="https://cdn.datatables.net/select/2.1.0/js/select.dataTables.js"></script>
<script src="https://cdn.datatables.net/select/1.2.0/js/dataTables.select.min.js"></script>
<script src="https://cdn.datatables.net/searchpanes/2.3.3/js/searchPanes.dataTables.js"></script>
<script src="https://cdn.datatables.net/searchpanes/2.3.3/js/dataTables.searchPanes.js"></script>-->

    <!-- END VENDOR JS -->



    <?php if ($formInPage) { ?>

        <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">

        <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>

        <script src="assets/plugins/classie/classie.js" type="text/javascript"></script>

        <script src="<?= $pluginPath ?>jquery-autonumeric/autoNumeric.js" type="text/javascript"></script>

        <script src="<?= $pluginPath ?>jquery-inputmask/jquery.inputmask.min.js" type="text/javascript"></script>

        <link href="<?= $pluginPath ?>select2/css/select2.min.css" rel="stylesheet" type="text/css" media="screen"/>

        <script src="<?= $pluginPath ?>select2/js/select2.min.js" type="text/javascript"></script>

        <script src="<?= $pluginPath ?>jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>

    <?php }

    //if ($uploadInPage) {
		
		if (isset($uploadInPage) && $uploadInPage) {

        ?>

        <link type="text/css" rel="stylesheet" href="<?= $pluginPath ?>dropzone/css/dropzone.css">

        <script src="<?= $pluginPath ?>dropzone/dropzone.min.js" type="text/javascript"></script>

    <?php } ?>

    

</head>

<body class="fixed-header menu-pin">



<?php include 'sidebar.php' ?>



<!-- START PAGE-CONTAINER -->

<div class="page-container">



    <?php include 'sub-navbar.php' ?>

