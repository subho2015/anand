<?php



$base = "../";



// required headers

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

header("Access-Control-Allow-Methods: GET,POST");



require_once('class/Category.php');

require_once('class/SubCategory.php');

require_once('class/SubSubCategory.php');



$category = new Category();

$subCategory = new SubCategory();

$subSubCategory = new SubSubCategory();



$method = $_SERVER['REQUEST_METHOD'];



if (isset($_REQUEST['function'])) {

    $functionName = $_REQUEST['function'];

}else{

    error_log("Fuckers you forget to set which function name");

}



if (isset($_REQUEST['categoryId'])) {

    $categoryId = $_REQUEST['categoryId'];

}



if (isset($_REQUEST['subCategoryId'])) {

    $subCategoryId = $_REQUEST['subCategoryId'];

}



/**

 * SUB-CATEGORY

 *  addSubCategory

 *  updateSubCategory

 *  editSubOrderCategory

 *  activateCategory

 *  deactivateCategory

 */



if ($method === 'POST') {

    switch ($functionName) {

        case "addSubCategory":

            $subCategoryName = filter_var($_POST['subCategory_name']);

            $subCategoryImg = filter_var($_POST['subCategory_img']);



            $subCategoryId = $subCategory->addSubCategory($categoryId, $subCategoryName, $subCategoryImg);



            if (!empty($subCategoryId)) {

                header("Location: " . $_SERVER["HTTP_REFERER"] . "&result=success&message=" . urlencode("Sub Category (" . $_POST['subCategory_name'] . ") added"));

            } else {

                header("Location: " . $_SERVER["HTTP_REFERER"] . "&result=failed&message=" . urlencode("Issue while adding"));

            }

            break;

        case "updateSubCategory":

            $subCategoryName = filter_var($_POST['subCategory_name']);

            $subCategoryImg = filter_var($_POST['subCategory_img']);



            $updateResult = $subCategory->updateSubCategory($subCategoryId, $subCategoryName, $subCategoryImg, $categoryId);



            if ($updateResult) {

                header("Location: " . $_SERVER["HTTP_REFERER"] . "&result=success&message=" . urlencode("Sub Category (" . $_POST['subCategory_name'] . ") Updated"));

            } else {

                header("Location: " . $_SERVER["HTTP_REFERER"] . "&result=failed&message=" . urlencode("Issue while updating, try again"));

            }

            break;

        case "editOrderSubCategory":

            $postSetIds = json_decode($_POST['listing_order']);

            foreach($postSetIds as $key => $value) {

                foreach ($value as $item=>$id){

                    $setIds[] = $id;

                }

            }

            $updateResult = $subCategory->editOrderSubCategory($setIds);

            error_log("Update Result: ".$updateResult);



            if($updateResult){

                header("Location: ". $_SERVER["HTTP_REFERER"]."&result=success&message=".urlencode("Sub Category Listing Order Updated"));

            }else {

                header("Location: ". $_SERVER["HTTP_REFERER"]."&result=failed&message=".urlencode("Issue while updating, try again"));

            }

            break;

        case "editActiveStatusSubCategory":

            $postSetIds = json_decode($_POST['update_status']);



            $updateResult = $subCategory->editActiveStatusSubCategory($postSetIds);

            if($updateResult){

                header("Location: ". strtok($_SERVER["HTTP_REFERER"], '?')."?result=success&message=".urlencode("Category Listing Order Updated"));

            }else {

                header("Location: ". strtok($_SERVER["HTTP_REFERER"], '?')."?result=failed&message=".urlencode("Issue while updating, try again"));

            }

            break;

        default:

            break;

    }

}

