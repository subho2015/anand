<!---->
<?php

$base = "../";

$formInPage = true;

$title = "Categories, Sub Categories & Sub-Sub Categories";

include $base . 'header.php' ?>
<?php

require_once('class/Category.php');

require_once('class/SubCategory.php');

require_once('class/SubSubCategory.php');



$category = new Category;

$subCategory = new SubCategory;

$subSubCategory = new SubSubCategory;



?>

<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper"> 
<?php
$result = $_GET['result'];
$message = $_GET['message'];
?>
  
  <!-- START PAGE CONTENT -->
  
  <div class="content"> 
  <?php
  if($result == 'success')
  {
	  $subCategory1 = $message;
      $subCategory2 = str_replace(['(', ')'], '', $subCategory1);
  ?>
  <div class="pgn-wrapper" data-position="top" style="top: 59px; margin:0 0 20px 0;"><div class="pgn push-on-sidebar-open pgn-bar"><div class="alert alert-success"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button><?php echo $subCategory2;?>&nbsp;Successfully</div></div></div>
    <?php
    }
   ?>
		
    <!-- START JUMBOTRON -->
    
    <div class="jumbotron no-margin test" data-pages="parallax">
      <div class=" container-fluid container-fixed-lg p-t-15"> 
        
        <!-- START BREADCRUMB -->
        
        <ol class="breadcrumb p-0">
          <li class="breadcrumb-item"><a href="../index.php">Hawk</a></li>
          <li class="breadcrumb-item active"><a href="#">Categories</a></li>
        </ol>
        
        <!-- END BREADCRUMB -->
        
        <h3 class="page-title text-primary"><i data-feather="box" aria-hidden="true"></i>Categories</h3>
      </div>
    </div>
    
    <!-- END JUMBOTRON --> 
    
    <!-- START CONTAINER FLUID -->
    
    <div class="container-fluid container-fixed-lg fi">
      <div class="card card-transparent">
        <div class="card-body">
          <div class="row"> 
            
            <!--important CATEGORY-->
            
            <div class="col-md-4">
              <div class="card">
                <div class="card-header bg-contrast-lower">
                  <div class="d-flex align-items-center justify-content-between">
                    <h5 class="semi-bold m-t-0">Category</h5>
                    <div class="card-controls">
                      <div class="btn-group hidden" id="category-actionConfirmations">
                        <button class="btn btn-link text-danger cancel" onclick="window.location.reload()"> Cancel </button>
                        <form role="form" action="CategoryAPI.php" method="post">
                          <input type="text" id="cat_listing_order" name="listing_order" hidden>
                          <input type="text" id="cat_active_status" name="update_status" hidden>
                          <input type="text" name="function" id="category_function" hidden>
                          <button class="btn btn-info" type="submit">Confirm</button>
                        </form>
                      </div>
                      <div class="dropdown more-cat-dropdown-toggle">
                        <button class="btn btn-link" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-label="more categories dropdown"> <i data-feather="more-vertical" aria-hidden=true></i> </button>
                        <ul class="dropdown-menu dropdown-menu-right more-cat-dropdown" role="menu">
                          <li id="addNewCategoryAction" data-target='#addCategoriesModal' data-toggle='modal'>
                            <p class="m-t-5 p-t-5 p-b-5 dropdown-item"> <i data-feather="plus-square" aria-hidden=true class="m-r-10"></i> Add New </p>
                          </li>
                          <li id="reorderCategory">
                            <p class="p-t-5 p-b-5 dropdown-item text-dark"> <i data-feather="move" aria-hidden=true></i> <span class="p-l-10">Reorder List</span> </p>
                          </li>
                          <li id="editCategory">
                            <p class="dropdown-item text-dark"> <i data-feather="edit" aria-hidden=true></i> <span class="p-l-10">Edit</span> </p>
                          </li>
                          <li id="printCategory">
                            <p class="dropdown-item text-dark"> <i data-feather="printer" aria-hidden=true></i> <span class="p-l-10">Print</span> </p>
                          </li>
                          <li id="disableCategory">
                            <p class="m-b-5 p-t-5 p-b-5 dropdown-item text-dark"> <i data-feather="zap-off" aria-hidden=true></i> <span class="p-l-10">Disable Items</span> </p>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-body m-t-10">
                  <div class="dd" id="category_dragger">
                    <ol class="dd-list">
                      <?php $categoryList = $category->getAllCategoriesByOrder();
                      foreach ($categoryList as $categoryRow) {
                        $categoryId = $categoryRow['id'];
                        $catSelect = null;
                        if (isset($_GET["category"]))
                          $catSelect = $categoryId == base64_decode($_GET["category"])
                            ? "bg-primary-lighter" : "";
                        ?>
                      <li class="dd-item cursor category_li" data-cat="<?= $categoryId ?>">
                        <div class="category-handle dd-handle no-border <?= $catSelect ?>">
                          <div class="d-flex align-items-center justify-content-between <?= $catSelect ?>">
                            <div id="drag_handle-<?= $categoryId ?>"
                                   class="dragCategory btn-dragging m-r-10 hidden"><i class="pg-icon" aria-hidden="true">drag_handle</i> </div>
                            <div class="flex-grow-1">
                              <div class="thumbnail-wrapper d48 circular b-white b-a b-white m-r-10"> <img width="48" height="48" src="https://ewr1.vultrobjects.com/categories/<?php echo $categoryRow['cat_img'] ?>" onerror="this.onerror=null; this.src='../assets/img/no-image-found.png'"> </div>
                              <h6 class="flex-fill <?= !$categoryRow['active'] ? "text-black-50 hint-text normal" : "text-black" ?>">
                                <?= $categoryRow['category_name'] ?>
                              </h6>
                            </div>
                            <span data-cat="<?= $categoryId ?>" class="editCategory flex-shrink-1 editCategoryAction" data-target='#updateCategoriesModal' data-toggle='modal'> <i class="pg-icon" aria-hidden="true">edit</i> </span>
                            <div class="printCategory">
 <button class="btn btn-complete  flex-shrink-1 printCategoryAction" data-target='#printPreviewModal' data-toggle='modal' data-catid="<?= $categoryId ?>" onclick="loadPreviewPrintModal(event)"> Print </button>
                              <button class="btn btn-complete flex-shrink-1 printCSVCategoryAction" data-target='#printCSVPreviewModal' data-toggle='modal' data-catid="<?= $categoryId ?>" onclick="loadPreviewPrintCSVModal(event)"> Print CSV </button>
                            </div>
                            <div class="disableToggle hidden">
                              <div class="form-check form-check-inline switch switch-lg primary no-margin">
                                <input type="checkbox" data-cat="<?= $categoryId ?>" class="category-isActive-switch" id="switch-cat-<?= $categoryId ?>" <?= $categoryRow['active'] ? "checked" : "" ?>><label for="switch-cat-<?= $categoryId ?>"></label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <?php } ?>
                    </ol>
                  </div>
                </div>
              </div>
            </div>
            
            <!--important SUB CATEGORY-->
            
            <div class="col-md-4">
              <div class="card">
                <div class="card-header bg-contrast-lower">
                  <div class="d-flex align-items-center justify-content-between">
                    <div>
                      <?php if (isset($_GET['category'])) {
                        $selectedCategoryId = (int)base64_decode($_GET['category']);
                        $selectedCategoryName = $category->getCategoryNameById($selectedCategoryId);
                        $subCategoryList = $subCategory->getAllSubCategoriesInCategoryByOrder($selectedCategoryId);
                        ?>
                      <h5 class="card-title text-primary">
                        <?= $selectedCategoryName ?>
                      </h5>
                      <?php } ?>
                      <h5 class="semi-bold m-t-0">Sub Category</h5>
                    </div>
                    <?php if (isset($_GET['category'])) { ?>
                      <div class="card-controls">
                        <div class="btn-group hidden" id="subCategory-actionConfirmations">
                          <button class="btn btn-link text-danger cancel" onclick="window.location.reload()"> Cancel </button>
                          <form role="form" action="SubCategoryAPI.php" method="post">
                            <input type="text" id="subCat_listing_order" name="listing_order" hidden>
                            <input type="text" id="subCat_active_status" name="update_status" hidden>
                            <input type="text" name="function" id="subCategory_function" hidden>
                            <button class="btn btn-info" type="submit">Confirm</button>
                          </form>
                        </div>
                        <div class="dropdown more-subCat-dropdown-toggle">
                          <button class="btn btn-link" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" aria-label="more sub categories dropdown"> <i data-feather="more-vertical" aria-hidden=true></i> </button>
                          <ul class="dropdown-menu dropdown-menu-right more-subCat-dropdown" role="menu">
                            <li class="addNewSubCategoryAction"

                                data-target='#addCategoriesModal'

                                data-toggle='modal'

                                data-value="<?php if (isset($_GET['category'])) {

                                  echo $_GET['category'];

                                } ?>">
                              <p class="m-t-5 p-t-5 p-b-5 dropdown-item"> <i data-feather="plus-square" aria-hidden=true></i> <span class="p-l-10">Add New</span> </p>
                            </li>
                            <li id="reorderSubCategory">
                              <p class="p-t-5 p-b-5 dropdown-item text-dark"> <i data-feather="move" aria-hidden=true></i> <span class="p-l-10">Reorder List</span> </p>
                            </li>
                            <li id="editSubCategory">
                              <p class="dropdown-item text-dark"> <i data-feather="edit" aria-hidden=true></i> <span class="p-l-10">Edit</span> </p>
                            </li>
                            <li id="printSubCategory">
                              <p class="dropdown-item text-dark"> <i data-feather="printer" aria-hidden=true></i> <span class="p-l-10">Print</span> </p>
                            </li>
                            <li id="disableSubCategory">
                              <p class="m-b-5 p-t-5 p-b-5 dropdown-item text-dark"> <i data-feather="zap-off" aria-hidden=true></i> <span class="p-l-10">Disable Items</span> </p>
                            </li>
                          </ul>
                        </div>
                      </div>
                      <?php } ?>
                  </div>
                </div>
                <div class="card-body m-t-10">
                  <?php if (isset($_GET['category'])) {

                    if (!empty($subCategoryList)) { ?>
                  <div class="dd" id="subCategory_dragger">
                    <ol class="dd-list">
                      <?php
                          for ($subCategoryIndex = 0, $subCategoryIndexMax = count($subCategoryList); $subCategoryIndex < $subCategoryIndexMax; $subCategoryIndex++) {
                            $subCategoryRow = $subCategoryList[$subCategoryIndex];
                            $subCategoryId = $subCategoryRow['id'];
                            $subCatSelect = "";
                            if (isset($_GET['subCat']))
                              $subCatSelect = $subCategoryId === base64_decode($_GET["subCat"]) ? "bg-primary-lighter" : "";

                            ?>
                      <li class="dd-item cursor subCategory_li" data-subcatid="<?= $subCategoryId ?>">
                        <div class="sub-category-handle dd-handle no-border <?= $subCatSelect ?>">
                          <div class="d-flex align-items-center justify-content-between">
                            <div class="dragSubCat btn-dragging m-r-10 hidden"> <i class="pg-icon" aria-hidden="true">drag_handle</i> </div>
                            <div class="flex-grow-1">
                              <div class="thumbnail-wrapper d48 circular b-white b-a b-white m-r-10"> <img width="48" height="48"

                                           src="https://ewr1.vultrobjects.com/sub-categories/<?php echo $subCategoryRow['subCategory_img'] ?>"

                                           onerror="this.onerror=null; this.src='../assets/img/no-image-found.png'"> </div>
                              <h6

                                      class="flex-fill <?= !$subCategoryRow['active'] ? "text-black-50 hint-text" : "text-black" ?>">
                                <?= $subCategoryRow['subCategory_name'] ?>
                              </h6>
                            </div>
                            <span class="editSubCat flex-shrink-1 editSubCategoryAction"

                                        data-target='#updateCategoriesModal'

                                        data-toggle='modal'

                                        data-subcatid="<?= $subCategoryRow['id'] ?>"> <i class="pg-icon" aria-hidden="true">edit</i> </span>
                            <button class="btn btn-info printSubCat flex-shrink-1 printSubCategoryAction"

                                          data-catid="<?= base64_decode($_GET["category"]) ?>"

                                          data-subcatid="<?= $subCategoryId ?>"

                                          data-target='#printPreviewModal'

                                          data-toggle='modal'

                                          onclick="loadPreviewPrintModal(event)"> Print </button>
                            <div class="disableSubCatToggle hidden">
                              <div class="form-check form-check-inline switch switch-lg primary no-margin">
                                <input type="checkbox"

                                             data-subcatid="<?= $subCategoryId ?>"

                                             class="sub-category-isActive-switch"

                                             id="switch-sc-<?= $subCategoryId ?>" <?= $subCategoryRow['active'] ? "checked" : '' ?>>
                                <label for="switch-sc-<?= $subCategoryId ?>"></label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <?php } ?>
                    </ol>
                  </div>
                  <?php } else { ?>
                  <button class="btn btn-link text-black-50 full-width block no-margin addNewSubCategoryAction"

                              data-target='#addCategoriesModal'

                              data-toggle='modal'

                              data-value="<?php if (isset($_GET['category'])) {

                                echo $_GET['category'];

                              } ?>"> + Add Sub-Category </button>
                  <?php }

                  } else { ?>
                  <h6 class="bold text-black-50 hint-text full-height text-center block no-margin"> Select Category</h6>
                  <?php } ?>
                </div>
              </div>
            </div>
            
            <!--important SUB-SUB CATEGORY-->
            
            <div class="col-md-4">
              <div class="card">
                <div class="card-header bg-contrast-lower">
                  <div class="d-flex align-items-center justify-content-between">
                    <div>
                      <?php if (isset($_GET['category'], $_GET['subCat'])) {

                        $selectedSubCategoryId = base64_decode($_GET['subCat']);



                        $selectedSubCategoryName = $subCategory->getSubCategoryNameById($selectedSubCategoryId);

                        $subSubCategoryList = $subSubCategory->getAllSubSubCategoriesInSubCategoryByOrder($selectedSubCategoryId);

                        ?>
                      <h4 class="card-title text-primary">
                        <?= $selectedCategoryName ?>
                        <i

                            data-feather="chevron-right"

                            aria-hidden="true"></i>
                        <?= $selectedSubCategoryName ?>
                      </h4>
                      <h5 class="card-title text-primary"></h5>
                      <?php } ?>
                      <h5 class="semi-bold m-t-0">Sub-Sub Category</h5>
                    </div>
                    <div class="card-controls">
                      <div class="btn-group hidden" id="subSubCategory-actionConfirmations">
                        <button class="btn btn-link text-danger cancel"

                                onclick="window.location.reload()"> Cancel </button>
                        <form role="form" action="SubSubCategoryAPI.php" method="post">
                          <input type="text" id="subSubCat_listing_order"

                                 name="listing_order"

                                 hidden>
                          <input type="text" id="subSubCat_active_status"

                                 name="update_status"

                                 hidden>
                          <input type="text" name="function" id="subSubCategory_function"

                                 hidden>
                          <button class="btn btn-info" type="submit">Confirm</button>
                        </form>
                      </div>
                      <div class="dropdown more-sub-sub-cat-dropdown-toggle">
                        <?php if (isset($_GET['category'], $_GET['subCat'])) { ?>
                          <button class="btn btn-link" type="button" data-toggle="dropdown"

                                  aria-haspopup="true" aria-expanded="false"

                                  aria-label="more sub sub categories dropdown"> <i data-feather="more-vertical" aria-hidden=true></i> </button>
                          <?php } ?>
                        <ul class="dropdown-menu dropdown-menu-right more-sub-sub-cat-dropdown"

                            role="menu">
                          <li id="addNewSubSubCategoryAction"

                              data-target='#addCategoriesModal'

                              data-toggle='modal'

                              data-value="<?php if (isset($_GET['category'], $_GET['subCat'])) {

                                echo $_GET['category'] . "|" . $_GET['subCat'];

                              } ?>">
                            <p class="m-t-5 p-t-5 p-b-5 dropdown-item"> <i data-feather="plus-square" aria-hidden=true></i> <span class="p-l-10">Add New</span> </p>
                          </li>
                          <li id="reorderSubSubCategory">
                            <p class="p-t-5 p-b-5 dropdown-item text-dark"> <i data-feather="move" aria-hidden=true></i> <span class="p-l-10">Reorder List</span> </p>
                          </li>
                          <li id="editSubSubCategory">
                            <p class="dropdown-item text-dark"> <i data-feather="edit" aria-hidden=true></i> <span class="p-l-10">Edit</span> </p>
                          </li>
                          <li id="disableSubSubCategory">
                            <p class="m-b-5 p-t-5 p-b-5 dropdown-item text-dark"> <i data-feather="zap-off" aria-hidden=true></i> <span class="p-l-10">Disable Items</span> </p>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-body m-t-10">
                  <?php if (isset($_GET['category'], $_GET['subCat'])) { ?>
                  <div class="dd" id="subSubCategory_dragger">
                    <ol class="dd-list">
                      <?php



                        if (!empty($subSubCategoryList)) {

                          for ($subSubCategoryIndex = 0,

                               $subSubCategoryIndexMax = count($subSubCategoryList);

                               $subSubCategoryIndex < $subSubCategoryIndexMax;

                               $subSubCategoryIndex++) {



                            $subSubCategoryRow = $subSubCategoryList[$subSubCategoryIndex];

                            $subSubCategoryId = $subSubCategoryRow['id'];



                            ?>
                      <li class="dd-item cursor"

                                data-subsubcatid="<?= $subSubCategoryId ?>">
                        <div class="sub-sub-category-handle dd-handle no-border">
                          <div class="d-flex align-items-center justify-content-between">
                            <div class="dragSubSubCat btn-dragging m-r-10 hidden"> <i class="pg-icon" aria-hidden="true">drag_handle</i> </div>
                            <div class="flex-grow-1">
                              <h6

                                      class="flex-fill <?= !$subSubCategoryRow['active'] ? "text-black-50 hint-text" : "text-black" ?>">
                                <?= $subSubCategoryRow['subSubCategory_name'] ?>
                              </h6>
                            </div>
                            <span class="editSubSubCat flex-shrink-1 editSubSubCategoryAction"

                                        data-target='#updateCategoriesModal'

                                        data-toggle='modal'

                                        data-subsubcatid="<?= $subSubCategoryRow['id'] ?>"> <i class="pg-icon" aria-hidden="true">edit</i> </span>
                            <div class="disableSubSubCatToggle hidden">
                              <div class="form-check form-check-inline switch switch-lg primary no-margin">
                                <input type="checkbox"

                                             data-subsubcatid="<?= $subSubCategoryId ?>"

                                             class="sub-sub-category-isActive-switch"

                                             id="switch-ssc-<?= $subSubCategoryId ?>" <?= $subSubCategoryRow['active'] ? "checked" : "" ?>>
                                <label for="switch-ssc-<?= $subSubCategoryId ?>"></label>
                              </div>
                            </div>
                          </div>
                        </div>
                      </li>
                      <?php }

                        } else { ?>
                      <h6 class="bold text-black-50 no-margin">Nothing</h6>
                      <p class="disabled">Add </p>
                      <?php } ?>
                    </ol>
                  </div>
                  <?php } else { ?>
                  <h6 class="bold text-black-50 hint-text full-height text-center block no-margin"> Select Sub-Category</h6>
                  <?php } ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- END CONTAINER FLUID -->
    
    <div class="modal fade slide-top" id="addCategoriesModal" tabindex="-1" role="dialog"

         aria-labelledby="addCategories" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="addCategories"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-top" id="updateCategoriesModal" tabindex="-1" role="dialog"

         aria-labelledby="updateCategories" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="updateCategories"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-top" id="printPreviewModal" tabindex="-1" role="dialog"

         aria-labelledby="previewPrintTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="previewPrintJob"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
    <div class="modal fade slide-top" id="printCSVPreviewModal" tabindex="-1" role="dialog"

         aria-labelledby="previewPrintCSVTitle" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content-wrapper">
          <div class="modal-content table-block">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"> <i class="pg-close fs-14" aria-hidden="true"></i> </button>
            <div class="modal-body v-align-top">
              <div id="previewPrintCSVJob"></div>
            </div>
          </div>
        </div>
        
        <!-- /.modal-content --> 
        
      </div>
      
      <!-- /.modal-dialog --> 
      
    </div>
  </div>
  
  <!-- END PAGE CONTENT --> 
  
</div>

<!-- END PAGE CONTENT WRAPPER --> 

<script src="js/categoriesAction.js"></script> 
<script src="js/subCategoriesAction.js"></script> 
<script src="js/subSubCategoriesAction.js"></script>
<?php include '../footer.php' ?>
