<?php



$base = "../../";

require_once("../class/SubCategory.php");

require_once("../class/Category.php");

$catId = base64_decode($_REQUEST['categoryId']);



$categories = new Category();



?>
<link href="../../assets/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" media="screen"/>
<script src="../../assets/plugins/select2/js/select2.min.js" type="text/javascript"></script>

<div class="card shadow-none no-margin no-padding">
  <div class="card-body p-l-0 p-r-0">
    <h3>Add Sub Category</h3>
  </div>
</div>
<form id="addNewSubCategory" role="form" action="./SubCategoryAPI.php" method="post">
  <div class="card card-default">
    <div class="card-body">
      <div class="form-group-attached">
        <div class="form-group form-group-default required">
          <label class="hint-text label-sm">Category</label>
          <select class="full-width" data-init-plugin="select2" name="categoryId" id="category_id" required>
            <optgroup label="Active">
            <?php
                $categoryActiveList = $categories->getActiveCategoriesByOrder();
                foreach ($categoryActiveList as $category) {?>
                <option value=<?php echo $category['id'];
                if($category['id'] == $catId){ echo " selected";}?>>
                   <?= $category['category_name'] ?>
                </option>
                <?php } ?>
            </optgroup>
            <optgroup label="Inactive">
            <?php
                 $categoryInactiveList = $categories->getInactiveCategoriesByOrder();
                            foreach ($categoryInactiveList as $category) {?>
            <option value=<?php echo $category['id'];
                                if($category['id'] == $catId) {echo " selected";}?>>
            <?= $category['category_name'] ?>
            </option>
            <?php } ?>
            </optgroup>
          </select>
        </div>
        <div class="form-group form-group-default">
          <label class="label-sm">Sub-Category Name</label>
          <input type="text" class="form-control" name="subCategory_name">
        </div>
        <input value="addSubCategory" name="function" hidden>
        <div class="form-group input-group">
          <div class="input-group-prepend"> <span class="input-group-text info"> <i class="pg-icon p-r-10" aria-hidden="true">picture</i> Sub-Category Image </span> </div>
          <input type="text" class="form-control"  id="subCategoryImageURL" placeholder="image-file-name.jpg/.png/.webp" name="subCategory_img" required>
          <div class="input-group-append">
            <button class="btn btn-primary" type="button" onclick="loadSubCategoryImage()"> <i class="pg-icon" aria-hidden="true">refresh</i> Load </button>
          </div>
        </div>
        <div id="loadSubCategoryImage"> </div>
      </div>
    </div>
  </div>
  <button class="btn btn-lg btn-block btn-complete" type="submit">Add Sub-Category</button>
</form>
<script>
    /*SubCategory Image*/

    const subCatImageDiv = document.getElementById('loadSubCategoryImage');
    const subCatImageInputURL = document.getElementById('subCategoryImageURL');
    function loadSubCategoryImage() {
        loadImage(subCatImageDiv, subCatImageInputURL);
    }
    function loadImage(imageDiv, imageURL) {
        if (imageURL.value != "") {
            let img;
            if (imageDiv.childNodes.length > 1) {
                imageDiv.removeChild(imageDiv.childNodes[1]);
            }
            img = new Image();
            img.className = "img-thumbnail m-b-10";
            img.width = 200;
            img.src = "https://ewr1.vultrobjects.com/sub-categories/" + imageURL.value;
            imageDiv.appendChild(img);
        } else {
            return false;
        }
    }
</script>