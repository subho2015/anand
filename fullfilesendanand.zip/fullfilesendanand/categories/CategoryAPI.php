<?php



$base = "../";



// required headers

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

header("Access-Control-Allow-Methods: GET,POST");



require_once('class/Category.php');

$category = new Category();



$method = $_SERVER['REQUEST_METHOD'];



if (isset($_REQUEST['function'])) {

    $functionName = $_REQUEST['function'];

}



if (isset($_REQUEST['categoryId'])) {

    $categoryId = $_REQUEST['categoryId'];

}



/**

 * CATEGORY

 *  addCategory

 *  updateCategory

 *  editOrderCategory

 *  activateCategory

 *  deactivateCategory

 */



if ($method === 'POST') {

    switch ($functionName) {

        case "addCategory":

            $categoryName = filter_var($_POST['category_name']);

            $categoryImage = filter_var($_POST['cat_img']);



            $categoryId = $category->addCategory($categoryName, $categoryImage);



            if (!empty($categoryId)) {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=success&message=" . urlencode("Category (" . $_POST['category_name'] . ") Added"));

            } else {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=failed&message=" . urlencode("Issue while adding"));

            }

            break;

        case "updateCategory":

            $categoryName = filter_var($_POST['category_name']);

            $categoryImage = filter_var($_POST['cat_img']);



            $updateResult = $category->updateCategory($categoryId, $categoryName, $categoryImage);



            if ($updateResult) {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=success&message=" . urlencode("Category (" . $_POST['category_name'] . ") Updated"));

            } else {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=failed&message=" . urlencode("Issue will updating, try again"));

            }

            break;

        case "editListingOrderCategory":

            $postSetIds = json_decode($_POST['listing_order']);

            foreach ($postSetIds as $key => $value) {

                foreach ($value as $item => $id) {

                    $setIds[] = $id;

                }

            }

            $updateResult = $category->editListingOrderCategory($setIds);

            if ($updateResult) {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=success&message=" . urlencode("Category Listing Order Updated"));

            } else {

                header("Location: " . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=failed&message=" . urlencode("Issue while updating, try again"));

            }

            break;

        case "editActiveStatusCategory":

            $postSetIds = json_decode($_POST['update_status']);



            $updateResult = $category->editActiveStatusCategory($postSetIds);

            if($updateResult){

                header("Location: ". strtok($_SERVER["HTTP_REFERER"], '?')."?result=success&message=".urlencode("Category Listing Order Updated"));

            }else {

                header("Location: ". strtok($_SERVER["HTTP_REFERER"], '?')."?result=failed&message=".urlencode("Issue while updating, try again"));

            }

            break;

        default:

            break;



    }

}

