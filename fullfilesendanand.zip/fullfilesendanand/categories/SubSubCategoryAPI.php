<?php



$base = "../";



// required headers

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

header("Access-Control-Allow-Methods: GET,POST");



require_once('class/Category.php');

require_once('class/SubCategory.php');

require_once('class/SubSubCategory.php');



$category = new Category();

$subCategory = new SubCategory();

$subSubCategory = new SubSubCategory();



$method = $_SERVER['REQUEST_METHOD'];



if (isset($_REQUEST['function'])) {

    $functionName = $_REQUEST['function'];

}else{

    error_log("Fuckers you forget to set which function name");

}



if (isset($_REQUEST['categoryId'])) {

    $categoryId = $_REQUEST['categoryId'];

}



if (isset($_REQUEST['subCategoryId'])) {

    $subCategoryId = $_REQUEST['subCategoryId'];

}



if (isset($_REQUEST['subSubCategoryId'])) {

    $subSubCategoryId = $_REQUEST['subSubCategoryId'];

}

error_log(json_encode($_POST));



/**

 * SUB-SUB CATEGORY

 *  addSubSubCategory

 *  updateSubSubCategory

 *  editSubSubOrderCategory

 *  getSubSubCategoryById

 *  getSubSubCategoryWithSubCatNCatNameById

 *  getAllSubSubCategoriesInSubCategoryByOrder

 *  activateSubSubCategory

 *  deactivateSubSubCategory

 *  getSubSubCategoryNameById

*/



if($method==='POST'){

    switch ($functionName) {

        case "addSubSubCategory":

            $subSubCategoryName = filter_var($_POST['subSubCategory_name']);



            $subSubCategoryId = $subSubCategory->addSubSubCategory($categoryId, $subCategoryId, $subSubCategoryName);



            if (!empty($subCategoryId)) {

                header("Location: " . $_SERVER["HTTP_REFERER"] . "&result=success&message=" . urlencode("Sub-Category (" . $_POST['subCategory_name'] . ") added"));

            } else {

                header("Location: " . $_SERVER["HTTP_REFERER"] . "&result=failed&message=" . urlencode("Issue while adding"));

            }

            break;

        case "updateSubSubCategory":

            $subSubCategoryName = filter_var($_POST['subSubCategory_name']);



            $updateResult = $subSubCategory->updateSubSubCategory($subSubCategoryId, $subSubCategoryName, $categoryId, $subCategoryId);



            if ($updateResult) {

                header("Location: " . $_SERVER["HTTP_REFERER"] . "&result=success&message=" . urlencode("Sub Sub Category (" . $_POST['subSubCategory_name'] . ") Updated"));

            } else {

                header("Location: " . $_SERVER["HTTP_REFERER"] . "&result=failed&message=" . urlencode("Issue while updating, try again"));

            }

            break;

        case "editOrderSubSubCategory":

            $postSetIds = json_decode($_POST['listing_order']);

            foreach($postSetIds as $key => $value) {

                foreach ($value as $item=>$id){

                    $setIds[] = $id;

                }

            }

            $updateResult = $subSubCategory->editOrderSubSubCategory($setIds);

            error_log("Update Result: ".$updateResult);



            if($updateResult){

                header("Location: ". $_SERVER["HTTP_REFERER"]."&result=success&message=".urlencode("Sub-Category Listing Order Updated"));

            }else {

                header("Location: ". $_SERVER["HTTP_REFERER"]."&result=failed&message=".urlencode("Issue while updating, try again"));

            }

            break;

        case "editActiveStatusSubSubCategory":

            $postSetIds = json_decode($_POST['update_status']);



            $updateResult = $subSubCategory->editActiveStatusSubSubCategory($postSetIds);

            if($updateResult){

                header("Location: ". strtok($_SERVER["HTTP_REFERER"], '?')."?result=success&message=".urlencode("Category Listing Order Updated"));

            }else {

                header("Location: ". strtok($_SERVER["HTTP_REFERER"], '?')."?result=failed&message=".urlencode("Issue while updating, try again"));

            }

            break;

        default:

            break;

    }

}

