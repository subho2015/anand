<!-- BEGIN SIDEBAR -->

<!-- BEGIN SIDEBPANEL-->

<nav class="page-sidebar" data-pages="sidebar"> 
  
  <!-- BEGIN SIDEBAR MENU TOP TRAY CONTENT-->
  
  <div class="sidebar-overlay-slide from-top" id="appMenu"> </div>
  
  <!-- END SIDEBAR MENU TOP TRAY CONTENT--> 
  
  <!-- BEGIN SIDEBAR MENU HEADER-->
  
  <div class="sidebar-header"> <img src="<?=$base ?>assets/img/logo.svg" alt="logo" class="brand" data-src="<?=$base ?>assets/img/logo.svg"

             data-src-retina="<?=$base ?>assets/img/logo.svg" width="90%"> </div>
  
  <!-- END SIDEBAR MENU HEADER--> 
  
  <!-- START SIDEBAR MENU -->
  
  <div class="sidebar-menu"> 
    
    <!-- BEGIN SIDEBAR MENU ITEMS-->
    
    <ul class="menu-items">
      <li class="m-t-30"> <a href="<?=$base ?>">Dashboard</a> <span class="icon-thumbnail"><i data-feather="grid" aria-hidden="true"></i></span> </li>
      <li class=""> <a href="javascript:;"> <span class="title">Orders</span> <span class=" arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="package" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?=$base ?>orders">New Orders</a> <span class="icon-thumbnail"><i data-feather="box" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>orders/in_process.php">Processing</a> <span class="icon-thumbnail"><i data-feather="inbox" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>orders/packed.php">Packed</a> <span class="icon-thumbnail"><i data-feather="package" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>orders/shipped.php">Shipped</a> <span class="icon-thumbnail"><i data-feather="truck" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>orders/delivered.php">Delivered</a> <span class="icon-thumbnail"><i data-feather="check-square" aria-hidden="true"></i></span> </li>
        </ul>
      </li>
      <li class=""> <a href="javascript:;"> <span class="title">Products</span> <span class="arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="shopping-bag" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?=$base ?>products/">In-Stock</a> <span class="icon-thumbnail"><i data-feather="database" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>products/outOfStocks.php">Out Of Stocks</a> <span class="icon-thumbnail"><i data-feather="trending-down" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>products/discontinue.php">Discontinue</a> <span class="icon-thumbnail"><i data-feather="archive" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>products/product_varient.php">Product Varient</a> <span class="icon-thumbnail"><i data-feather="archive" aria-hidden="true"></i></span> </li>
        </ul>
      </li>
      <li class=""> <a href="<?=$base ?>categories/"> <span class="title">Categories</span> </a> <span class="icon-thumbnail"><i data-feather="list" aria-hidden="true"></i></span> </li>
      <li class=""> <a href="<?=$base ?>brands/"> <span class="title">Brands</span> </a> <span class="icon-thumbnail"><i data-feather="feather" aria-hidden="true"></i></span> </li>
      <li class=""> <a href="javascript:;"> <span class="title">Programs</span> <span class="arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="star" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?=$base ?>programs/">Active Program</a> <span class="icon-thumbnail"><i data-feather="star" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>programs/inactivePrograms.php">Inactive Programs</a> <span class="icon-thumbnail"><i data-feather="tag" aria-hidden="true"></i></span> </li>
        </ul>
      </li>
      <li class=""> <a href="javascript:;"> <span class="title">Offers</span> <span class="arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="award" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?=$base ?>offers/newArrival.php">New Arrival</a> <span class="icon-thumbnail"><i data-feather="codesandbox" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>offers/weeklySpecial.php">Weekly Special</a> <span class="icon-thumbnail"><i data-feather="percent" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>offers/monthlyFlyer.php">Monthly Flyer</a> <span class="icon-thumbnail"><i data-feather="droplet" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>offers/closeout.php">Closeout</a> <span class="icon-thumbnail"><i data-feather="tag" aria-hidden="true"></i></span> </li>
        </ul>
      </li>
      <li class=""> <a href="javascript:;"> <span class="title">Marketing</span> <span class="arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="share" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?=$base ?>printJob">Print</a> <span class="icon-thumbnail"><i data-feather="printer" aria-hidden="true"></i></span> </li>
          
          <!--              <li class="">--> 
          
          <!--                <a href="-->
          <?//=$base ?>
          <!--">Email<br><span class="fs-10 text-muted">* Work in Progress</span></a>--> 
          
          <!--                <span class="icon-thumbnail"><i data-feather="percent" aria-hidden="true"></i></span>--> 
          
          <!--              </li>-->
          
        </ul>
      </li>
      <li class=""> <a href="javascript:;"> <span class="title">Product Inquiry</span> <span class="arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="paperclip" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?=$base ?>productInquiry/">New</a> <span class="icon-thumbnail"><i data-feather="book-open" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>productInquiry/inProgress.php">In-Progress</a> <span class="icon-thumbnail"><i data-feather="book-open" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>productInquiry/closed.php">Closed</a> <span class="icon-thumbnail"><i data-feather="book" aria-hidden="true"></i></span> </li>
        </ul>
      </li>
      <li class=""> <a href="javascript:;"> <span class="title">Customers</span> <span class="arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="users" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?=$base ?>customers/">New Customers</a> <span class="icon-thumbnail"><i data-feather="user-plus" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>customers/activeCustomers.php">Active Customers</a> <span class="icon-thumbnail"><i data-feather="user-check" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>customers/inactiveCustomers.php">Inactive Customers</a> <span class="icon-thumbnail"><i data-feather="user-minus" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>customers/disabledUsers.php">Disabled Users</a> <span class="icon-thumbnail"><i data-feather="user-x" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>customers/rejectedCustomers.php">Rejected Users<br>
            <span class="fs-10 text-muted">* Only For Super-Admin</span></a> <span class="icon-thumbnail"><i data-feather="user-x" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?=$base ?>customers/unverifiedCustomers.php">Unverified Users<br>
            <span class="fs-10 text-muted">* Only For Super-Admin</span></a> <span class="icon-thumbnail"><i data-feather="user-x" aria-hidden="true"></i></span> </li>
        </ul>
      </li>
      <li class=""> <a href="javascript:;"> <span class="title">Frontend CMS</span> <span class=" arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="layout" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?= $base?>frontendCMS/about.php">About Page</a> <span class="icon-thumbnail"><i data-feather="sun" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?= $base?>frontendCMS/contact.php">Contact Page</a> <span class="icon-thumbnail"><i data-feather="mail" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?= $base?>frontendCMS/faqs.php">FAQs</a> <span class="icon-thumbnail"><i data-feather="help-circle" aria-hidden="true"></i></span> </li>
        </ul>
      </li>
      <li class=""> <a href="javascript:;"> <span class="title">Compliance</span> <span class=" arrow"></span> </a> <span class="icon-thumbnail"><i data-feather="briefcase" aria-hidden="true"></i></span>
        <ul class="sub-menu">
          <li class=""> <a href="<?= $base?>compliance/privacy-policy.php">Privacy Policy</a> <span class="icon-thumbnail"><i data-feather="file-text" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?= $base?>compliance/terms-n-conditions.php">T & C</a> <span class="icon-thumbnail"><i data-feather="file-text" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?= $base?>compliance/shipping-policy.php">Shipping Policy</a> <span class="icon-thumbnail"><i data-feather="file-text" aria-hidden="true"></i></span> </li>
          <li class=""> <a href="<?= $base?>compliance/return-n-refunds.php">Return & Refund</a> <span class="icon-thumbnail"><i data-feather="file-text" aria-hidden="true"></i></span> </li>
        </ul>
      </li>
      <li class=""> <a href="<?=$base ?>staffs/"> <span class="title">Staffs</span> </a> <span class="icon-thumbnail "><i data-feather="user-check" aria-hidden="true"></i></span> </li>
      <li class=""> <a href="#"> <span class="title">Settings</span> </a> <span class="icon-thumbnail "><i data-feather="sliders" aria-hidden="true"></i></span> </li>
    </ul>
    <div class="clearfix"></div>
  </div>
  
  <!-- END SIDEBAR MENU --> 
  
</nav>

<!-- END SIDEBAR -->