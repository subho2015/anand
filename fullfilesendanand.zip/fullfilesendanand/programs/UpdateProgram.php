<?php $base = '../';

$title = 'Update Product';

$formInPage = true ?>

<?php include '../header.php';

require_once '../brands/class/Brands.php';



require_once 'class/Programs.php';



$programs = new Programs;

$brands = new Brands;



if (isset($_REQUEST['program_id'])) {

    $programId = $_REQUEST['program_id'];

    $program = ($programs->getProgramProductDetails($programId))[0];

    ?>



    <!-- START PAGE CONTENT WRAPPER -->

    <div class="page-content-wrapper">
     <?php
$result = $_GET['success'];
$message = $_GET['message'];
if ($message != "") {
	//echo "Test";
    //$orderMessage = $_GET['orderUpdates']['message'];
    $orderMessage = str_replace('+', ' ', $message); // Replace '+' with space
    //echo $orderMessage; // Outputs: Order Packed
} else {
    echo "Order message not found.";
}
if($result == 'success' )
{
	//$ordermessage;
   //   $order2 = str_replace(['(', ')'], '', $order1);
?>
  
  <!-- START PAGE CONTENT -->
  <div class="pgn-wrapper" data-position="top" style="top: 59px; margin:0 0 20px 0;"><div class="pgn push-on-sidebar-open pgn-bar"><div class="alert alert-success"><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button><?php echo $orderMessage;?>&nbsp;Successfully</div></div></div>
    <?php
    }
   ?>

        <!-- START PAGE CONTENT -->

        <div class="content">

            <!-- START JUMBOTRON -->

            <div class="jumbotron no-margin" data-pages="parallax">

                <div class=" container-fluid container-fixed-lg p-t-15">

                    <!-- START BREADCRUMB -->

                    <div class="pull-left">

                        <ol class="breadcrumb p-0">

                            <li class="breadcrumb-item"><a href="/index.php">Hawk</a></li>

                            <li class="breadcrumb-item active"><a href="../programs">Program</a></li>

                        </ol>

                        <!-- END BREADCRUMB -->

                        <h3 class="page-title text-primary">

                            <i class="fa fa-plus-square p-r-10" aria-hidden="true"></i>

                            <?= $program['product_name'] ?>

                        </h3>

                    </div>

                </div>

            </div>

            <!-- END JUMBOTRON -->



            <!-- START CONTAINER FLUID -->

            <div class="container">

                <!-- START card -->

                <div class="row">



                    <div class="col-md-10 offset-1 m-t-25 m-b-50">

                        <form id="addNewProduct" role="form" action="programsAPIs.php" method="post">

                            <div class="card card-default">



                                <div class="card-body">

                                    <div class="form-group-attached">

                                        <div class="row">

                                            <div class="col-md-5">



                                                <div class="form-group form-group-default required">

                                                    <label class="label-lg">Product Name (Item Code)</label>

                                                    <input type="text" class="form-control input-lg" name="product_name"

                                                           value="<?= $program['product_name'] ?>" required>

                                                </div>

                                            </div>

                                            <div class="col-md-3">

                                                <div class="form-group form-group-default">

                                                    <label class="hint-text label-sm">Brands</label>

                                                    <select class="full-width" data-init-plugin="select2"

                                                            name="brand_id">



                                                        <?php

                                                        $brandsList = $brands->generateBrandsList();

                                                        foreach ($brandsList as $brand) {

                                                            ?>

                                                            <option value="<?= $brand['id'] ?>"

                                                                <?php if ($program['brand_id'] === $brand['id']) {

                                                                    echo "selected";

                                                                } ?>>

                                                                <?= $brand['brands_name'] ?></option>



                                                        <?php } ?>



                                                    </select>

                                                </div>

                                            </div>

                                            <div class="col-md-4">

                                                <div class="form-group form-group-default">

                                                    <label class="label-lg">HSN Code</label>

                                                    <input type="text" class="form-control input-lg" name="hsc_code"

                                                           value="<?= $program['hsc_code'] ?>">

                                                </div>

                                            </div>

                                        </div>

                                        <div class="row">

                                            <div class="col-md-3">

                                                <div class="form-group form-group-default">

                                                    <label class="label-sm">Listing Order</label>

                                                    <input type="number" class="form-control" name="listing_order"

                                                           value="<?= $program['listing_order'] ?>">

                                                </div>

                                            </div>



                                            <div class="col-md-3">

                                                <div class="form-group form-group-default">

                                                    <label class="label-sm">Made In</label>

                                                    <input type="text" class="form-control" name="country"

                                                           value="<?= $program['country'] ?>">

                                                </div>

                                            </div>



                                            <div class="col-md-3">

                                                <div class="form-group form-group-default required">

                                                    <label class="label-sm">In-Stock Quantity</label>

                                                    <input type="number" class="form-control" name="stock_qty"

                                                           value="<?= $program['stock_qty'] ?>" required>

                                                </div>

                                            </div>

                                            <div class="col-md-3">

                                                <div class="form-group form-group-default required">

                                                    <label class="label-sm">Min. In-Stock</label>

                                                    <input type="number" class="form-control"

                                                           value="<?= $program['min_stock_req'] ?>"

                                                           name="min_stock_req" required>

                                                </div>

                                            </div>

                                        </div>

                                        <div class="form-group form-group-default p-b-10 required">

                                            <label class="label-sm p-b-10">Full Description</label>

                                            <div class="quill-wrapper">

                                                <input type="text" name="full_description" hidden>

                                                <div id="editor"></div>

                                            </div>

                                        </div>

                                    </div>



                                    <h5 class="m-t-20">Weight Table</h5>

                                    <table class="table table-bordered">

                                        <thead>

                                        <tr>

                                            <th scope="col"></th>

                                            <th scope="col" class="text-center">Width</th>

                                            <th scope="col" class="text-center">Length</th>

                                            <th scope="col" class="text-center">Height</th>

                                            <th scope="col" class="text-center">Weight</th>

                                            <th scope="col" class="text-center">UPC</th>

                                        </tr>

                                        </thead>

                                        <tbody>

                                        <tr>

                                            <input value="editProgramProduct" name="function" hidden>

                                            <input value="<?= $programId ?>" name="programId" hidden>



                                            <th scope="row" class="align-middle">Individual</th>

                                            <td class="padding-10">

                                                <div class="form-group input-group">

                                                    <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control" name="width"

                                                           value="<?= $program['width'] ?>">

                                                    <div class="input-group-append ">

                                                <span class="input-group-text">

                                                    In.</span>

                                                    </div>

                                                </div>

                                            </td>

                                            <td class="padding-10">

                                                <div class="form-group input-group">

                                                    <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control" name="length"

                                                           value="<?= $program['length'] ?>">

                                                    <div class="input-group-append ">

                                                <span class="input-group-text">

                                                    In.</span>

                                                    </div>

                                                </div>

                                            </td>

                                            <td class="padding-10">

                                                <div class="form-group input-group">

                                                    <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control" name="height"

                                                           value="<?= $program['height'] ?>">

                                                    <div class="input-group-append ">

                                                <span class="input-group-text">

                                                    In.</span>

                                                    </div>

                                                </div>

                                            </td>

                                            <td class="padding-10">

                                                <div class="form-group input-group">

                                                    <input type="text" data-a-dec="." data-a-sep=","

                                                           class="autonumeric form-control" name="weight"

                                                           value="<?= $program['weight'] ?>">

                                                    <div class="input-group-append ">

                                                <span class="input-group-text">

                                                    lb.</span>

                                                    </div>

                                                </div>

                                            </td>

                                            <td class="padding-10">

                                                <div class="form-group">

                                                    <input type="text" class="form-control" name="upc"

                                                           value="<?= $program['upc'] ?>">

                                                </div>

                                            </td>

                                        </tr>

                                        </tbody>

                                    </table>



                                    <h5 class="m-t-20">Pricing</h5>

                                    <table class="table table-bordered">

                                        <thead>

                                        <tr>

                                            <th scope="col"></th>

                                            <th scope="col" class="text-center bg-bronze-lighter">Bronze</th>

                                            <th scope="col" class="text-center bg-silver-lighter">Silver</th>

                                            <th scope="col" class="text-center bg-gold-lighter">Gold</th>

                                            <th scope="col" class="text-center bg-platinum-light">Platinum</th>

                                        </tr>

                                        </thead>

                                        <tbody>

                                        <tr>

                                            <th scope="row" class="align-middle">Individual</th>

                                            <td class="padding-10">

                                                <div class="form-group input-group">

                                                    <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control" name="bronze_price"

                                                           value="<?= $program['bronze_price'] ?>">

                                                    <div class="input-group-append ">

                                                <span class="input-group-text">

                                                     per pc.</span>

                                                    </div>

                                                </div>

                                            </td>

                                            <td class="padding-10">

                                                <div class="form-group input-group">

                                                    <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control" name="silver_price"

                                                           value="<?= $program['silver_price'] ?>">

                                                    <div class="input-group-append ">

                                                <span class="input-group-text">

                                                     per pc.</span>

                                                    </div>

                                                </div>

                                            </td>

                                            <td class="padding-10">

                                                <div class="form-group input-group">

                                                    <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control" name="gold_price"

                                                           value="<?= $program['gold_price'] ?>">

                                                    <div class="input-group-append ">

                                                <span class="input-group-text">

                                                     per pc.</span>

                                                    </div>

                                                </div>

                                            </td>

                                            <td class="padding-10">

                                                <div class="form-group input-group">

                                                    <input type="text" data-a-sign="$ "

                                                           class="autonumeric form-control" name="platinum_price"

                                                           value="<?= $program['platinum_price'] ?>">

                                                    <div class="input-group-append ">

                                                <span class="input-group-text">

                                                     per pc.</span>

                                                    </div>

                                                </div>

                                            </td>

                                        </tr>

                                        </tbody>

                                    </table>



                                    <h5 class="m-t-20">Product Image</h5>

                                    <div class="form-group input-group">

                                        <div class="input-group-prepend">

                                    <span class="input-group-text info">

                                         <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                        Featured

                                    </span>

                                        </div>



                                        <input type="text" class="form-control"

                                               id="featuredImageURL"

                                               placeholder="image-file-name.jpg/png/*any" name="featured_image"

                                               value="<?= $program['featured_image'] ?>"

                                               required>

                                        <div class="input-group-append">

                                            <button class="btn btn-primary" type="button" onclick="loadFeaturedImage()">

                                                <i class="pg-icon" aria-hidden="true">refresh</i>

                                                Load

                                            </button>

                                        </div>



                                    </div>

                                    <div id="loadfeaturedImage">

                                    </div>

                                    <div class="row">

                                        <div class="col-md-6">

                                            <div class="row">



                                                <div class="form-group input-group required">

                                                    <div class="input-group-prepend">

                                                    <span class="input-group-text info">

                                                        <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                                        1st

                                                    </span>

                                                    </div>

                                                    <input type="text" id="firstImageURL"

                                                           placeholder="image-file-name.jpg/png/*any" name="first_image"

                                                           value="<?= $program['first_image'] ?>" class="form-control">



                                                    <div class="input-group-append">

                                                        <button class="btn btn-primary" type="button"

                                                                onclick="load1stImage()">

                                                            <i class="pg-icon" aria-hidden="true">refresh</i>

                                                            Load

                                                        </button>

                                                    </div>

                                                </div>

                                                <div id="load1stImage">

                                                </div>

                                            </div>

                                        </div>



                                        <div class="col-md-6">

                                            <div class="form-group input-group required">



                                                <div class="input-group-prepend">

                                                    <span class="input-group-text info">

                                                        <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                                        2nd

                                                    </span>

                                                </div>

                                                <input type="text" id="secondImageURL"

                                                       placeholder="image-file-name.jpg/png/*any" name="second_image"

                                                       value="<?= $program['second_image'] ?>" class="form-control">



                                                <div class="input-group-append">

                                                    <button class="btn btn-primary" type="button"

                                                            onclick="load2ndImage()">

                                                        <i class="pg-icon" aria-hidden="true">refresh</i>

                                                        Load

                                                    </button>

                                                </div>

                                            </div>

                                            <div id="load2ndImage">

                                            </div>

                                        </div>



                                        <div class="col-md-6">

                                            <div class="form-group input-group required">

                                                <div class="input-group-prepend">

                                                    <span class="input-group-text info">

                                                        <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                                        3rd

                                                    </span>

                                                </div>

                                                <input type="text" id="thirdImageURL"

                                                       placeholder="image-file-name.jpg/png/*any" name="third_image"

                                                       value="<?= $program['third_image'] ?>" class="form-control">



                                                <div class="input-group-append">

                                                    <button class="btn btn-primary" type="button"

                                                            onclick="load3rdImage()">

                                                        <i class="pg-icon" aria-hidden="true">refresh</i>

                                                        Load

                                                    </button>

                                                </div>

                                            </div>

                                            <div id="load3rdImage"></div>

                                        </div>



                                        <div class="col-md-6">

                                            <div>

                                                <div class="form-group form-group-default input-group required">

                                                    <div class="input-group-prepend">

                                                    <span class="input-group-text info">

                                                        <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                                        4th

                                                    </span>

                                                    </div>

                                                    <input type="text" id="forthImageURL"

                                                           placeholder="image-file-name.jpg/png/*any" name="forth_image"

                                                           value="<?= $program['forth_image'] ?>" class="form-control">



                                                    <div class="input-group-append">

                                                        <button class="btn btn-primary" type="button"

                                                                onclick="load4thImage()">

                                                            <i class="pg-icon" aria-hidden="true">refresh</i>

                                                            Load

                                                        </button>

                                                    </div>

                                                </div>

                                                <div id="load4thImage">

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>



                            </div>



                            <button class="btn btn-lg btn-block btn-complete" type="submit">Add Program</button>



                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <script>



        var toolbarOptions = [

            ['bold', 'italic', 'underline', 'strike'],        // toggled buttons

            ['blockquote'],



            [{'size': ['small', false, 'large', 'huge']}],  // custom dropdown

            [{'header': [1, 2, 3, 4, 5, 6, false]}],



            [{'list': 'ordered'}, {'list': 'bullet'}],

            [{'script': 'sub'}, {'script': 'super'}],      // superscript/subscript

            [{'indent': '-1'}, {'indent': '+1'}],          // outdent/indent



            [{'font': []}],

            [{'align': []}],



            ['clean']                                         // remove formatting button

        ];



        $(document).ready(function () {

            $('.autonumeric').autoNumeric('init');

            $('#addNewProduct').validate();

            var quill = new Quill('#editor', {

                modules: {

                    toolbar: toolbarOptions

                },

                placeholder: 'Type description...',

                theme: 'snow'

            });

        });



        /*Featured Image*/

        const featuredImageDiv = document.getElementById('loadfeaturedImage');

        const featuredImageInputURL = document.getElementById('featuredImageURL');



        /*1st Image*/

        const _1stImageDiv = document.getElementById('load1stImage');

        const _1stImageInputURL = document.getElementById('firstImageURL');



        /*2nd Image*/

        const _2ndImageDiv = document.getElementById('load2ndImage');

        const _2ndImageInputURL = document.getElementById('secondImageURL');



        /*3rd Image*/

        const _3rdImageDiv = document.getElementById('load3rdImage');

        const _3rdImageInputURL = document.getElementById('thirdImageURL');



        /*4th Image*/

        const _4thImageDiv = document.getElementById('load4thImage');

        const _4thImageInputURL = document.getElementById('forthImageURL');



        function loadImage(imageDiv, imageURL) {

            if (imageURL.value != "") {

                let img;

                if (imageDiv.childNodes.length > 1) {

                    imageDiv.removeChild(imageDiv.childNodes[1]);

                }



                img = new Image();

                img.className = "img-thumbnail m-b-10";

                img.width = 200;

                img.src = "https://ewr1.vultrobjects.com/product-image/" + imageURL.value;

                imageDiv.appendChild(img);

            } else {

                return false;

            }

        }



        function load3rdImage() {

            loadImage(_3rdImageDiv, _3rdImageInputURL);

        }



        function load4thImage() {

            loadImage(_4thImageDiv, _4thImageInputURL);

        }



        function load2ndImage() {

            loadImage(_2ndImageDiv, _2ndImageInputURL);

        }



        function load1stImage() {

            loadImage(_1stImageDiv, _1stImageInputURL);

        }



        function loadFeaturedImage() {

            loadImage(featuredImageDiv, featuredImageInputURL);

        }



    </script>

<?php }

include '../footer.php' ?>

