<?php $base = '../';

$title = '+ New Product';

$formInPage = true ?>

<?php include '../header.php';

require_once '../brands/class/Brands.php';



require_once 'class/Programs.php';



$programs = new Programs;

$brands = new Brands;



?>



<!-- START PAGE CONTENT WRAPPER -->

<div class="page-content-wrapper">

    <!-- START PAGE CONTENT -->

    <div class="content">

        <!-- START JUMBOTRON -->

        <div class="jumbotron no-margin" data-pages="parallax">

            <div class=" container-fluid container-fixed-lg p-t-15">

                <!-- START BREADCRUMB -->

                <div class="pull-left">

                    <ol class="breadcrumb p-0">

                        <li class="breadcrumb-item"><a href="/index.php">Hawk</a></li>

                        <li class="breadcrumb-item active"><a href="/programs">Program</a></li>

                    </ol>

                    <!-- END BREADCRUMB -->

                    <h3 class="page-title text-primary"><i class="fa fa-plus-square p-r-10" aria-hidden="true"></i> New

                        Program</h3>

                </div>

            </div>

        </div>

        <!-- END JUMBOTRON -->



        <!-- START CONTAINER FLUID -->

        <div class="container">

            <!-- START card -->

            <div class="row">



                <div class="col-md-10 offset-1 m-t-25 m-b-50">

                    <form id="createNewProgram" role="form" action="programsAPIs.php" method="post">

                        <div class="card card-default">



                            <div class="card-body">

                                <div class="form-group-attached">

                                    <div class="row">

                                        <div class="col-md-5">



                                            <div class="form-group form-group-default required">

                                                <label class="label-lg">Product Name (Item Code)</label>

                                                <input type="text" class="form-control input-lg" name="product_name"

                                                       required>

                                            </div>

                                        </div>

                                        <div class="col-md-3">

                                            <div class="form-group form-group-default">

                                                <label class="hint-text label-sm">Brands</label>

                                                <select class="full-width" data-init-plugin="select2" name="brand_id">



                                                    <?php

                                                    $brandsList = $brands->generateBrandsList();

                                                    foreach ($brandsList as $brand) {

                                                        ?>

                                                        <option value="<?= $brand['id'] ?>"><?= $brand['brands_name'] ?></option>



                                                    <?php } ?>



                                                </select>

                                            </div>

                                        </div>

                                        <div class="col-md-4">

                                            <div class="form-group form-group-default">

                                                <label class="label-lg">HSN Code</label>

                                                <input type="text" class="form-control input-lg" name="hsc_code">

                                            </div>

                                        </div>

                                    </div>

                                    <div class="row">

                                        <div class="col-md-3">

                                            <div class="form-group form-group-default">

                                                <label class="label-sm">Listing Order</label>

                                                <input type="number" class="form-control" name="listing_order">

                                            </div>

                                        </div>



                                        <div class="col-md-3">

                                            <div class="form-group form-group-default">

                                                <label class="label-sm">Made In</label>

                                                <input type="text" class="form-control" name="country">

                                            </div>

                                        </div>



                                        <div class="col-md-3">

                                            <div class="form-group form-group-default required">

                                                <label class="label-sm">In-Stock Quantity</label>

                                                <input type="number" class="form-control" name="stock_qty" required>

                                            </div>

                                        </div>

                                        <input value="addProgramProduct" name="function" hidden>

                                        <div class="col-md-3">

                                            <div class="form-group form-group-default required">

                                                <label class="label-sm">Min. In-Stock</label>

                                                <input type="number" class="form-control" value="12"

                                                       name="min_stock_req" required>

                                            </div>

                                        </div>

                                    </div>

                                    <div class="form-group form-group-default p-b-10 required">

                                        <label class="label-sm p-b-10">Full Description</label>

                                        <div class="quill-wrapper">
                                        <textarea id="full_description" name="full_description" rows="4" cols="50"></textarea>

                                            <!--<input type="text" name="full_description" hidden>-->
                                            
                                            <!--<div id="editor"></div>-->

                                        </div>

                                    </div>

                                </div>



                                <h5 class="m-t-20">Weight Table</h5>

                                <table class="table table-bordered">

                                    <thead>

                                    <tr>

                                        <th scope="col"></th>

                                        <th scope="col" class="text-center">Width</th>

                                        <th scope="col" class="text-center">Length</th>

                                        <th scope="col" class="text-center">Height</th>

                                        <th scope="col" class="text-center">Weight</th>

                                        <th scope="col" class="text-center">UPC</th>

                                    </tr>

                                    </thead>

                                    <tbody>

                                    <tr>

                                        <th scope="row" class="align-middle">Individual</th>

                                        <td class="padding-10">

                                            <div class="form-group input-group">

                                                <input type="text" data-a-dec="." data-a-sep=","

                                                       class="autonumeric form-control" name="width">

                                                <div class="input-group-append ">

                                                <span class="input-group-text">

                                                    In.</span>

                                                </div>

                                            </div>

                                        </td>

                                        <td class="padding-10">

                                            <div class="form-group input-group">

                                                <input type="text" data-a-dec="." data-a-sep=","

                                                       class="autonumeric form-control" name="length">

                                                <div class="input-group-append ">

                                                <span class="input-group-text">

                                                    In.</span>

                                                </div>

                                            </div>

                                        </td>

                                        <td class="padding-10">

                                            <div class="form-group input-group">

                                                <input type="text" data-a-dec="." data-a-sep=","

                                                       class="autonumeric form-control" name="height">

                                                <div class="input-group-append ">

                                                <span class="input-group-text">

                                                    In.</span>

                                                </div>

                                            </div>

                                        </td>

                                        <td class="padding-10">

                                            <div class="form-group input-group">

                                                <input type="text" data-a-dec="." data-a-sep=","

                                                       class="autonumeric form-control" name="weight">

                                                <div class="input-group-append ">

                                                <span class="input-group-text">

                                                    lb.</span>

                                                </div>

                                            </div>

                                        </td>

                                        <td class="padding-10">

                                            <div class="form-group">

                                                <input type="text" class="form-control" name="upc">

                                            </div>

                                        </td>

                                    </tr>

                                    </tbody>

                                </table>



                                <h5 class="m-t-20">Pricing</h5>

                                <table class="table table-bordered">

                                    <thead>

                                    <tr>

                                        <th scope="col"></th>

                                        <th scope="col" class="text-center bg-bronze-lighter">Bronze</th>

                                        <th scope="col" class="text-center bg-silver-lighter">Silver</th>

                                        <th scope="col" class="text-center bg-gold-lighter">Gold</th>

                                        <th scope="col" class="text-center bg-platinum-light">Platinum</th>

                                    </tr>

                                    </thead>

                                    <tbody>

                                    <tr>

                                        <th scope="row" class="align-middle">Individual</th>

                                        <td class="padding-10">

                                            <div class="form-group input-group">

                                                <input type="text" data-a-sign="$ "

                                                       class="autonumeric form-control" name="bronze_price">

                                                <div class="input-group-append ">

                                                <span class="input-group-text">

                                                     per pc.</span>

                                                </div>

                                            </div>

                                        </td>

                                        <td class="padding-10">

                                            <div class="form-group input-group">

                                                <input type="text" data-a-sign="$ "

                                                       class="autonumeric form-control" name="silver_price">

                                                <div class="input-group-append ">

                                                <span class="input-group-text">

                                                     per pc.</span>

                                                </div>

                                            </div>

                                        </td>

                                        <td class="padding-10">

                                            <div class="form-group input-group">

                                                <input type="text" data-a-sign="$ "

                                                       class="autonumeric form-control" name="gold_price">

                                                <div class="input-group-append ">

                                                <span class="input-group-text">

                                                     per pc.</span>

                                                </div>

                                            </div>

                                        </td>

                                        <td class="padding-10">

                                            <div class="form-group input-group">

                                                <input type="text" data-a-sign="$ "

                                                       class="autonumeric form-control" name="platinum_price">

                                                <div class="input-group-append ">

                                                <span class="input-group-text">

                                                     per pc.</span>

                                                </div>

                                            </div>

                                        </td>



                                    </tr>

                                    </tbody>

                                </table>



                                <h5 class="m-t-20">Product Image</h5>

                                <div class="form-group input-group">

                                    <div class="input-group-prepend">

                                    <span class="input-group-text info">

                                         <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                        Featured

                                    </span>

                                    </div>



                                    <input type="text" class="form-control"

                                           id="featuredImageURL"

                                           placeholder="image-file-name.jpg/png/*any" name="featured_image"

                                           required>

                                    <div class="input-group-append">

                                        <button class="btn btn-primary" type="button" onclick="loadFeaturedImage()">

                                            <i class="pg-icon" aria-hidden="true">refresh</i>

                                            Load

                                        </button>

                                    </div>



                                </div>

                                <div id="loadfeaturedImage">

                                </div>

                                <div class="row">

                                    <div class="col-md-6">

                                        <div class="row">



                                            <div class="form-group input-group required">

                                                <div class="input-group-prepend">

                                                    <span class="input-group-text info">

                                                        <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                                        1st

                                                    </span>

                                                </div>

                                                <input type="text" id="firstImageURL"

                                                       placeholder="image-file-name.jpg/png/*any" name="first_image" class="form-control">



                                                <div class="input-group-append">

                                                    <button class="btn btn-primary" type="button"

                                                            onclick="load1stImage()">

                                                        <i class="pg-icon" aria-hidden="true">refresh</i>

                                                        Load

                                                    </button>

                                                </div>

                                            </div>

                                            <div id="load1stImage">

                                            </div>

                                        </div>

                                    </div>



                                    <div class="col-md-6">

                                        <div class="form-group input-group required">



                                            <div class="input-group-prepend">

                                                    <span class="input-group-text info">

                                                        <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                                        2nd

                                                    </span>

                                            </div>

                                            <input type="text" id="secondImageURL"

                                                   placeholder="image-file-name.jpg/png/*any" name="second_image" class="form-control">



                                            <div class="input-group-append">

                                                <button class="btn btn-primary" type="button" onclick="load2ndImage()">

                                                    <i class="pg-icon" aria-hidden="true">refresh</i>

                                                    Load

                                                </button>

                                            </div>

                                        </div>

                                        <div id="load2ndImage">

                                        </div>

                                    </div>



                                    <div class="col-md-6">

                                        <div class="form-group input-group required">

                                            <div class="input-group-prepend">

                                                    <span class="input-group-text info">

                                                        <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                                        3rd

                                                    </span>

                                            </div>

                                            <input type="text" id="thirdImageURL"

                                                   placeholder="image-file-name.jpg/png/*any" name="third_image" class="form-control">



                                            <div class="input-group-append">

                                                <button class="btn btn-primary" type="button"

                                                        onclick="load3rdImage()">

                                                    <i class="pg-icon" aria-hidden="true">refresh</i>

                                                    Load

                                                </button>

                                            </div>

                                        </div>

                                        <div id="load3rdImage"></div>

                                    </div>



                                    <div class="col-md-6">

                                        <div>

                                            <div class="form-group form-group-default input-group required">

                                                <div class="input-group-prepend">

                                                    <span class="input-group-text info">

                                                        <i class="pg-icon p-r-10" aria-hidden="true">picture</i>

                                                        4th

                                                    </span>

                                                </div>

                                                <input type="text" id="forthImageURL"

                                                       placeholder="image-file-name.jpg/png/*any" name="forth_image" class="form-control">



                                                <div class="input-group-append">

                                                    <button class="btn btn-primary" type="button"

                                                            onclick="load4thImage()">

                                                        <i class="pg-icon" aria-hidden="true">refresh</i>

                                                        Load

                                                    </button>

                                                </div>

                                            </div>

                                            <div id="load4thImage">

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>



                        </div>



                        <button class="btn btn-lg btn-block btn-complete" type="submit">Add Program</button>



                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

<script>



    var toolbarOptions = [

        ['bold', 'italic', 'underline', 'strike'],        // toggled buttons

        ['blockquote'],



        [{'size': ['small', false, 'large', 'huge']}],  // custom dropdown

        [{'header': [1, 2, 3, 4, 5, 6, false]}],



        [{'list': 'ordered'}, {'list': 'bullet'}],

        [{'script': 'sub'}, {'script': 'super'}],      // superscript/subscript

        [{'indent': '-1'}, {'indent': '+1'}],          // outdent/indent



        [{'font': []}],

        [{'align': []}],



        ['clean']                                         // remove formatting button

    ];



    $(document).ready(function () {

        $('.autonumeric').autoNumeric('init');

        $('#createNewProgram').validate();

        var quill = new Quill('#editor', {

            modules: {

                toolbar: toolbarOptions

            },

            placeholder: 'Type description...',

            theme: 'snow'

        });

    });



    /*Featured Image*/

    const featuredImageDiv = document.getElementById('loadfeaturedImage');

    const featuredImageInputURL = document.getElementById('featuredImageURL');



    /*1st Image*/

    const _1stImageDiv = document.getElementById('load1stImage');

    const _1stImageInputURL = document.getElementById('firstImageURL');



    /*2nd Image*/

    const _2ndImageDiv = document.getElementById('load2ndImage');

    const _2ndImageInputURL = document.getElementById('secondImageURL');



    /*3rd Image*/

    const _3rdImageDiv = document.getElementById('load3rdImage');

    const _3rdImageInputURL = document.getElementById('thirdImageURL');



    /*4th Image*/

    const _4thImageDiv = document.getElementById('load4thImage');

    const _4thImageInputURL = document.getElementById('forthImageURL');



    function loadImage(imageDiv, imageURL) {

        if (imageURL.value != "") {

            let img;

            if (imageDiv.childNodes.length > 1) {

                imageDiv.removeChild(imageDiv.childNodes[1]);

            }



            img = new Image();

            img.className = "img-thumbnail m-b-10";

            img.width = 200;

            img.src = "https://ewr1.vultrobjects.com/product-image/" + imageURL.value;

            imageDiv.appendChild(img);

        } else {

            return false;

        }

    }



    function load3rdImage() {

        loadImage(_3rdImageDiv, _3rdImageInputURL);

    }



    function load4thImage() {

        loadImage(_4thImageDiv, _4thImageInputURL);

    }



    function load2ndImage() {

        loadImage(_2ndImageDiv, _2ndImageInputURL);

    }



    function load1stImage() {

        loadImage(_1stImageDiv, _1stImageInputURL);

    }



    function loadFeaturedImage() {

        loadImage(featuredImageDiv, featuredImageInputURL);

    }



</script>

<?php include '../footer.php' ?>

