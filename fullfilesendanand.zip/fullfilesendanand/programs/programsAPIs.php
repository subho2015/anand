<?php

$base = "../";



// required headers

header("Access-Control-Allow-Origin: *");

header("Content-Type: application/json; charset=UTF-8");

header("Access-Control-Allow-Methods: GET,POST");



require_once('class/Programs.php');



$programs = new Programs;



$method = $_SERVER['REQUEST_METHOD'];



if (isset($_REQUEST['function'])) {

    $functionName = $_REQUEST['function'];

}



if(isset($_REQUEST['programId'])){

    $programId = (int)$_REQUEST['programId'];

}



if ($method === 'POST') {

    if ($functionName == "addProgramProduct") {

        $basicRequestData = [];

        $doubleFields = ["width", "length", "height", "weight", "bronze_price", "silver_price", "gold_price", "platinum_price"];

        $basicFormKey = ["product_name", "brand_id", "hsc_code", "country",

            "listing_order", "stock_qty", "min_stock_req", "full_description",

            "width", "length", "height", "weight", "upc",

            "bronze_price", "silver_price", "gold_price", "platinum_price",

            "featured_image", "first_image", "second_image", "third_image", "forth_image"];



        //Important field's position or index position

        /*echo "<pre>";
print_r($basicFormKey);
echo "</pre>";*/

        foreach ($basicFormKey as $formField) {

            $postValue = $_POST[$formField] ?? null;

            if(in_array($formField, $doubleFields)){

                $postValue = str_replace(["$ ", ","], "", $postValue);

                $postValue = (double) $postValue;

            }
           //echo $_POST[$formField];


            $postValue = empty($postValue) ? null : htmlspecialchars($postValue);

            $basicRequestData[$formField] = $postValue;
		}
//echo $_POST['full_description'];
        echo "<pre>";
print_r($basicRequestData);

echo "</pre>";


        $programId = $programs->addProgramProduct($basicRequestData);

          if (!$programId) {
    die("Error adding program product: " . print_r($basicRequestData, true));
}

        if (!empty($programId)) {

            $result = "success";

            $message = "Program (" . $_POST['product_name'] . ") Created";

        } else {

            $result = "failed";

            $message = "Program not added properly";

        }



        header('Location:' . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=" . $result . "&message=" . urlencode($message));



    } elseif($functionName == "disableProgramProduct") {

        $deactivationResult = $programs->disableProgramProduct($programId);

        if ($deactivationResult >= 1) {

            $result = "Success";

            $message = "Program has been disabled";

            http_response_code(200);

            echo $result;

        } elseif ($deactivationResult == 0) {

            $result = "Warning";

            $message = "Nothing to change";

            http_response_code(304);

            echo $result;

        } else {

            $result = "Failed";

            $message = "Error in deactivation";

            http_response_code(409);

            echo $result;

        }

        error_log("Disable Program => ".$result);

    } elseif($functionName == "enableProgramProduct") {

        $activationResult= $programs->enableProgramProduct($programId);

        if ($activationResult >= 1) {

            $result = "Success";

            $message = "Product is live in website";

            http_response_code(200);

            echo $result;

        } elseif ($activationResult == 0) {

            $result = "Warning";

            $message = "Nothing to change";

            http_response_code(304);

            echo $result;

        } else {

            $result = "Failed";

            $message = "Error in activation";

            http_response_code(409);

            echo $result;

        }

        error_log("Enable Products => ".$result);

    } elseif($functionName == "editProgramProduct") {



        $basicRequestData = [];

        $doubleFields = ["width", "length", "height", "weight",

            "bronze_price", "silver_price", "gold_price", "platinum_price"];



        $basicFormKey = ["product_name", "brand_id", "hsc_code", "country",

            "listing_order", "stock_qty", "min_stock_req", "full_description",

            "width", "length", "height", "weight", "upc",

            "bronze_price", "silver_price", "gold_price", "platinum_price", 

            "featured_image", "first_image", "second_image", "third_image", "forth_image"];



        //Important field's position or index position



        foreach ($basicFormKey as $formField) {

            $postValue = $_POST[$formField] ?? null;

            if(in_array($formField, $doubleFields)){

                $postValue = str_replace(["$ ", ","], "", $postValue);

                $postValue = (double) $postValue;

            }



            $postValue = empty($postValue) ? null : htmlspecialchars($postValue);

            $basicRequestData[$formField] = $postValue;



        }



        $programs->editProgramProduct($programId, $basicRequestData);



        if (!empty($programId)) {

            $result = "success";

            $message = "Program (" . $_POST['product_name'] . ") Created";

        } else {

            $result = "failed";

            $message = "Program not added properly";

        }



        header('Location:' . strtok($_SERVER["HTTP_REFERER"], '?') . "?result=" . $result . "&message=" . urlencode($message));



    }else {

        echo "Not a functions";

    }



} else {  /*GET*/

    echo "Not a valid method";

}





