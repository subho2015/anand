import React from "react";

function Offer()
{
    return(
        <div id="presentaion">
           <div className="pr-heading">
               <h1>A BIG <span>OFFER</span> FOR THIS SUMMER</h1>
               <p className="details">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
               <div className="pr-btns"><a href="#" className="pr-btn">JOIN US</a></div>
           </div>
        </div>
    )
}

export default Offer;